# Index comparison: measured results

Commit `7db8f11c0d311642d8b41bd598416694a860ad58`. Run status: **complete_with_errors**. Started 2026-09-21T07:00:11Z; completed 2026-09-21T09:51:45Z.

32,768 timed observations, 3,266 successful exact result-multiset checks, **6 recorded errors**, and **4 explicitly unmeasured configurations** after maintenance failures. A correctness check is separate from EXPLAIN timing; the suite does not mistake an aggregate's output row count for a proof of correctness. An operation timeout is a failed attempt, not a successful duration; dependent checks are skipped and identified below.

**Build failures:** 5 recorded failed index builds. Statements have a 60-second limit. A failed index is omitted from the remaining portfolio and is not retried in subsequent build rounds; the family remains explicitly partial. Query results for that family use its surviving indexes or a planner fallback. They are **not measurements of the missing index**. See the completeness column and individual-index status below. Resume history and any earlier fatal attempt are preserved in metadata.

Hardware: **AMD Ryzen 7 5700X3D 8-Core Processor**, 16 logical CPUs, 23.47 GiB visible RAM. Server: `PostgreSQL 20devel on x86_64-pc-linux-gnu, compiled by gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0, 64-bit`. Platform: `Linux-5.15.167.4-microsoft-standard-WSL2-x86_64-with-glibc2.39`. See [metadata.json](metadata.json) for compiler flags, all server settings, seed, and run arguments. Shared buffers are 512 MB; normal work_mem is 64 MB and maintenance_work_mem is 512 MB. Parallel query and JIT are disabled to isolate access paths; index builds use the recorded maintenance-worker setting. Durability is enabled. Autovacuum is disabled; vacuum and visibility transitions are explicit.

This is a synthetic, single-machine comparison, inspired by the presentation of the [Biscuit benchmark](https://biscuit.readthedocs.io/en/latest/benchmark.html). It measures this extension's integer, array, and full-text workloads, not Biscuit's wildcard workload. The data and workload SQL are in [queries.json](queries.json); generation and execution are in the [runner](../../comprehensive/run.py).

## Interpretation and fairness

Every scalar family attempts the same eight single-column indexes on a freshly generated heap; exceptions are explicitly partial portfolios as described above. `btree_tuned` additionally receives a composite `(c200,c20,c2)` index and a covering `(c200) INCLUDE (id,payload)` index; its larger portfolio is charged in build time, bytes, and maintenance. Scalar GIN and GiST use the official `btree_gin` and `btree_gist` operator classes. GIN fastupdate is on; BRIN uses 32-page ranges. Roaring uses extension defaults. `roaring_bitmap` reuses the roaring portfolio with count pushdown disabled.

Document comparisons use native GIN, GiST, and roaring text-search support. GIN and roaring also index text arrays. **GiST has no text[] containment opclass here**, so its array queries are explicitly a fallback with no array index. Hash cannot accelerate ordering/ranges, and roaring scalar indexes do not provide ordered/range access. Their measured query plans are retained rather than pretending that these operations are supported. SP-GiST's built-in spatial/radix operator classes do not provide an equivalent integer, text[] containment, or tsvector portfolio, so SP-GiST is outside this workload. This suite does not claim coverage of geometric, vector, JSON, wildcard, or arbitrary extension indexes. See PostgreSQL's [index types](https://www.postgresql.org/docs/current/indexes-types.html), [btree_gin](https://www.postgresql.org/docs/current/btree-gin.html), [btree_gist](https://www.postgresql.org/docs/current/btree-gist.html), and [text-search indexes](https://www.postgresql.org/docs/current/textsearch-indexes.html).

`default` uses normal planner preferences. `prefer_index` disables sequential scans as a diagnostic; it is not a production tuning recommendation and does not guarantee use of an index. The access column and raw plans identify the actual route. A fallback is a query execution result, not a successful measurement of the named index algorithm.

Each query is verified against a forced sequential-scan result, warmed independently, and measured in randomized complete rounds within a portfolio. Families are shuffled with a fixed seed. Families run sequentially; there is no interleaved cross-family crossover trial. Warm means no deliberate cache eviction, **not a guarantee that the working set fits shared buffers**. `shared_buffers_cold` restarts the dedicated server before each measured query; the OS page cache remains warm, and planning can warm metadata pages before execution. No claim about cold physical-disk performance is made.

`clean` follows VACUUM FREEZE. `dirty_clustered_5pct` updates the first 5% of rows' non-indexed payload; `dirty_scattered` additionally updates every hundredth row. Names describe mutations, not an assumed visibility percentage; [operations.jsonl](operations.jsonl) records measured all-visible and heap-page counts. `low_work_mem` uses 64 kB and records lossy bitmap/temp-block evidence in [samples.jsonl](samples.jsonl). The normal setting is 64 MB. Maintenance is measured once per portfolio after these visibility mutations, with a checkpoint before each operation; WAL includes full-page images and index WAL. Build repeats are recorded separately. Insert batches contain 1% of initial rows; indexed updates affect the first 1%, and deletes use `id % 100 = 1`.

Read latency is server EXPLAIN ANALYZE execution time with per-node timing off, including EXPLAIN instrumentation but excluding planning and result transfer. Planning time and full buffer/WAL plans are retained in [samples.jsonl](samples.jsonl) and [plans.jsonl.gz](plans.jsonl.gz). Medians, interpolated p95, sample CV, and a seeded 2,000-resample percentile bootstrap 95% CI of the median are shown. With few samples, especially cold samples, intervals and p95 are descriptive and imprecise. Speedups divide matching sequential-scan medians by the variant median; they are not cross-workload averages. Sub-millisecond ratios are especially sensitive to timer resolution and instrumentation overhead. Timeout/error observations remain errors and are excluded from latency summaries, never converted to zero.

Concurrency measures closed-loop SELECTs through Python threads and synchronous libpq, including client dispatch, result transfer, and decoding. It can become client-bound for very fast counts; it is not a maximum server-throughput claim. The separate [growth/churn/write supplement](../2026-09-21-stress/REPORT.md) covers empty-index growth, changing-key churn, prepared statements, fully dirty low-memory counts, and short concurrent-write bursts. Crash recovery, replication, filesystem cache eviction, repeated maintenance trials, variable GIN pending-list settings, and tuning sweeps remain outside these runs. The benchmark is exhaustive over its published matrix, not every PostgreSQL workload.

Storage columns labeled Heap MiB use `pg_table_size`, including auxiliary forks and any TOAST storage; portfolio bytes use `pg_indexes_size`. Individual-index bytes use `pg_relation_size` (main fork). MiB means 1,048,576 bytes. Consult the [results guide](../../COMPARISON.md) for selected comparisons and their practical limits.

## Size and build cost

| Suite | Rows | Family | Heap MiB | Indexes MiB | Median build seconds | Build rounds | Completeness / omitted indexes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| documents | 200000 | gin | 52.05 | 6.86 | 0.341 | 3 | complete |
| documents | 200000 | gist | 52.05 | 13.86 | 3.395 | 3 | complete |
| documents | 200000 | roaring | 52.05 | 9.03 | 1.575 | 3 | complete |
| documents | 200000 | seq | 52.05 | 0.00 | 0.000 | 0 | complete |
| scalar | 1000000 | brin | 150.57 | 0.44 | 0.454 | 3 | complete |
| scalar | 1000000 | btree | 150.57 | 65.64 | 1.695 | 3 | complete |
| scalar | 1000000 | btree_tuned | 150.57 | 180.08 | 2.677 | 3 | complete |
| scalar | 1000000 | gin | 150.57 | 60.26 | 2.281 | 3 | complete |
| scalar | 1000000 | gist | 150.57 | 155.14 | 5.210 | 3 | complete |
| scalar | 1000000 | hash | 150.57 | 250.21 | — | 3 | partial: ix_c2, ix_skew |
| scalar | 1000000 | roaring | 150.57 | 72.71 | 6.707 | 3 | complete |
| scalar | 1000000 | seq | 150.57 | 0.00 | 0.000 | 0 | complete |
| scalar | 5000000 | brin | 751.73 | 0.94 | 2.143 | 3 | complete |
| scalar | 5000000 | btree | 751.73 | 289.46 | 8.924 | 3 | complete |
| scalar | 5000000 | btree_tuned | 751.73 | 862.22 | 13.577 | 3 | complete |
| scalar | 5000000 | gin | 751.73 | 164.78 | 8.120 | 3 | complete |
| scalar | 5000000 | gist | 751.73 | 774.73 | 29.395 | 3 | complete |
| scalar | 5000000 | hash | 751.73 | 967.59 | — | 3 | partial: ix_c2, ix_c20, ix_skew |
| scalar | 5000000 | roaring | 751.73 | 215.02 | 30.139 | 3 | complete |
| scalar | 5000000 | seq | 751.73 | 0.00 | 0.000 | 0 | complete |

## Every individual index

| Suite | Rows | Family | Index | MiB | Median attempt ms | Min–max attempt ms | Median WAL MiB | Attempts | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| documents | 200000 | gin | ix_grp | 0.484 | 26.259 | 26.159–26.325 | 0.381 | 3 | built |
| documents | 200000 | gin | ix_tags | 2.070 | 103.244 | 100.400–113.906 | 1.360 | 3 | built |
| documents | 200000 | gin | ix_tsv | 4.305 | 211.395 | 202.423–212.477 | 2.686 | 3 | built |
| documents | 200000 | gist | ix_grp | 3.867 | 138.518 | 127.398–150.991 | 3.932 | 3 | built |
| documents | 200000 | gist | ix_tsv | 9.992 | 3267.475 | 3229.153–3303.481 | 8.637 | 3 | built |
| documents | 200000 | roaring | ix_grp | 0.977 | 103.175 | 99.346–104.755 | 0.494 | 3 | built |
| documents | 200000 | roaring | ix_tags | 2.750 | 464.289 | 449.133–507.096 | 2.299 | 3 | built |
| documents | 200000 | roaring | ix_tsv | 5.305 | 1011.081 | 928.344–1132.358 | 4.705 | 3 | built |
| scalar | 1000000 | brin | ix_c1m | 0.031 | 58.041 | 50.632–61.622 | 0.138 | 3 | built |
| scalar | 1000000 | brin | ix_c2 | 0.031 | 54.154 | 50.997–54.806 | 0.136 | 3 | built |
| scalar | 1000000 | brin | ix_c20 | 0.031 | 56.114 | 49.065–59.923 | 0.136 | 3 | built |
| scalar | 1000000 | brin | ix_c200 | 0.031 | 54.434 | 53.161–57.599 | 0.137 | 3 | built |
| scalar | 1000000 | brin | ix_c20k | 0.031 | 54.314 | 49.217–54.791 | 0.137 | 3 | built |
| scalar | 1000000 | brin | ix_clustered | 0.031 | 59.000 | 49.353–60.316 | 0.139 | 3 | built |
| scalar | 1000000 | brin | ix_nullable | 0.031 | 55.346 | 53.090–65.168 | 0.138 | 3 | built |
| scalar | 1000000 | brin | ix_skew | 0.031 | 59.715 | 51.788–60.690 | 0.138 | 3 | built |
| scalar | 1000000 | btree | ix_c1m | 18.812 | 237.025 | 236.162–246.281 | 17.067 | 3 | built |
| scalar | 1000000 | btree | ix_c2 | 6.633 | 213.038 | 201.906–216.497 | 6.042 | 3 | built |
| scalar | 1000000 | btree | ix_c20 | 6.641 | 235.729 | 224.866–238.201 | 6.043 | 3 | built |
| scalar | 1000000 | btree | ix_c200 | 6.719 | 223.245 | 220.496–232.827 | 6.046 | 3 | built |
| scalar | 1000000 | btree | ix_c20k | 6.805 | 205.491 | 202.315–210.273 | 6.322 | 3 | built |
| scalar | 1000000 | btree | ix_clustered | 6.656 | 169.003 | 161.586–177.787 | 6.040 | 3 | built |
| scalar | 1000000 | btree | ix_nullable | 6.719 | 227.014 | 219.197–227.830 | 6.043 | 3 | built |
| scalar | 1000000 | btree | ix_skew | 6.656 | 192.023 | 177.791–201.029 | 6.046 | 3 | built |
| scalar | 1000000 | btree_tuned | ix_c1m | 18.812 | 244.812 | 233.349–247.110 | 17.069 | 3 | built |
| scalar | 1000000 | btree_tuned | ix_c2 | 6.633 | 200.856 | 194.915–202.319 | 6.041 | 3 | built |
| scalar | 1000000 | btree_tuned | ix_c20 | 6.641 | 234.427 | 234.376–245.940 | 6.040 | 3 | built |
| scalar | 1000000 | btree_tuned | ix_c200 | 6.719 | 223.530 | 216.739–228.278 | 6.044 | 3 | built |
| scalar | 1000000 | btree_tuned | ix_c20k | 6.805 | 201.827 | 200.345–203.389 | 6.324 | 3 | built |
| scalar | 1000000 | btree_tuned | ix_clustered | 6.656 | 171.250 | 166.799–183.110 | 6.042 | 3 | built |
| scalar | 1000000 | btree_tuned | ix_composite | 6.867 | 316.851 | 289.725–319.031 | 6.212 | 3 | built |
| scalar | 1000000 | btree_tuned | ix_covering | 107.570 | 654.645 | 608.471–680.701 | 97.171 | 3 | built |
| scalar | 1000000 | btree_tuned | ix_nullable | 6.719 | 227.296 | 220.425–242.590 | 6.046 | 3 | built |
| scalar | 1000000 | btree_tuned | ix_skew | 6.656 | 193.105 | 188.638–206.919 | 6.048 | 3 | built |
| scalar | 1000000 | gin | ix_c1m | 38.195 | 1324.001 | 1242.589–1429.081 | 19.484 | 3 | built |
| scalar | 1000000 | gin | ix_c2 | 1.094 | 94.509 | 90.531–101.753 | 1.107 | 3 | built |
| scalar | 1000000 | gin | ix_c20 | 1.578 | 108.244 | 106.774–118.369 | 1.417 | 3 | built |
| scalar | 1000000 | gin | ix_c200 | 4.703 | 143.971 | 139.664–147.281 | 2.067 | 3 | built |
| scalar | 1000000 | gin | ix_c20k | 6.734 | 251.221 | 241.397–254.854 | 3.584 | 3 | built |
| scalar | 1000000 | gin | ix_clustered | 1.578 | 107.576 | 103.692–116.761 | 1.083 | 3 | built |
| scalar | 1000000 | gin | ix_nullable | 4.836 | 132.690 | 125.855–143.408 | 2.028 | 3 | built |
| scalar | 1000000 | gin | ix_skew | 1.539 | 115.999 | 115.161–119.605 | 1.302 | 3 | built |
| scalar | 1000000 | gist | ix_c1m | 19.273 | 681.489 | 647.254–699.128 | 19.378 | 3 | built |
| scalar | 1000000 | gist | ix_c2 | 19.273 | 645.699 | 613.575–673.775 | 19.381 | 3 | built |
| scalar | 1000000 | gist | ix_c20 | 19.273 | 723.542 | 692.470–737.262 | 19.380 | 3 | built |
| scalar | 1000000 | gist | ix_c200 | 19.273 | 736.698 | 716.937–746.824 | 19.381 | 3 | built |
| scalar | 1000000 | gist | ix_c20k | 19.273 | 693.214 | 684.361–719.014 | 19.382 | 3 | built |
| scalar | 1000000 | gist | ix_clustered | 19.273 | 402.432 | 392.349–407.735 | 19.382 | 3 | built |
| scalar | 1000000 | gist | ix_nullable | 20.227 | 725.826 | 720.732–753.239 | 19.387 | 3 | built |
| scalar | 1000000 | gist | ix_skew | 19.273 | 649.385 | 624.976–663.581 | 19.378 | 3 | built |
| scalar | 1000000 | hash | ix_c1m | 31.992 | 1134.230 | 1131.644–1136.623 | 69.300 | 3 | built |
| scalar | 1000000 | hash | ix_c2 | — | 60009.319 | 60009.319–60009.319 | 62.831 | 1 | FAILED / omitted |
| scalar | 1000000 | hash | ix_c20 | 47.141 | 11007.265 | 10632.956–11121.125 | 69.450 | 3 | built |
| scalar | 1000000 | hash | ix_c200 | 46.688 | 2194.799 | 2081.336–2208.324 | 69.446 | 3 | built |
| scalar | 1000000 | hash | ix_c20k | 32.945 | 1064.009 | 1059.542–1144.112 | 69.312 | 3 | built |
| scalar | 1000000 | hash | ix_clustered | 46.766 | 1338.528 | 1327.333–1398.575 | 69.445 | 3 | built |
| scalar | 1000000 | hash | ix_nullable | 44.680 | 1876.150 | 1874.099–1916.755 | 62.541 | 3 | built |
| scalar | 1000000 | hash | ix_skew | — | 59371.844 | 59371.844–59371.844 | 49.399 | 1 | FAILED / omitted |
| scalar | 1000000 | roaring | ix_c1m | 47.703 | 2538.423 | 2458.940–2566.276 | 75.843 | 3 | built |
| scalar | 1000000 | roaring | ix_c2 | 2.867 | 509.850 | 488.269–550.520 | 2.025 | 3 | built |
| scalar | 1000000 | roaring | ix_c20 | 2.664 | 676.939 | 644.467–685.843 | 2.107 | 3 | built |
| scalar | 1000000 | roaring | ix_c200 | 4.188 | 700.939 | 657.394–726.918 | 2.919 | 3 | built |
| scalar | 1000000 | roaring | ix_c20k | 8.492 | 691.514 | 689.394–692.189 | 8.087 | 3 | built |
| scalar | 1000000 | roaring | ix_clustered | 1.062 | 339.506 | 335.044–339.579 | 0.184 | 3 | built |
| scalar | 1000000 | roaring | ix_nullable | 4.406 | 717.772 | 703.334–725.216 | 2.927 | 3 | built |
| scalar | 1000000 | roaring | ix_skew | 1.328 | 565.652 | 559.990–565.939 | 1.177 | 3 | built |
| scalar | 5000000 | brin | ix_c1m | 0.094 | 269.345 | 265.756–272.320 | 0.403 | 3 | built |
| scalar | 5000000 | brin | ix_c2 | 0.094 | 272.544 | 249.358–276.943 | 0.406 | 3 | built |
| scalar | 5000000 | brin | ix_c20 | 0.094 | 258.895 | 257.708–259.941 | 0.401 | 3 | built |
| scalar | 5000000 | brin | ix_c200 | 0.094 | 264.089 | 257.689–265.208 | 0.402 | 3 | built |
| scalar | 5000000 | brin | ix_c20k | 0.094 | 268.217 | 265.054–271.004 | 0.403 | 3 | built |
| scalar | 5000000 | brin | ix_clustered | 0.094 | 269.149 | 266.953–276.040 | 0.404 | 3 | built |
| scalar | 5000000 | brin | ix_nullable | 0.094 | 273.846 | 269.587–280.163 | 0.405 | 3 | built |
| scalar | 5000000 | brin | ix_skew | 0.094 | 271.593 | 267.655–272.464 | 0.404 | 3 | built |
| scalar | 5000000 | btree | ix_c1m | 56.258 | 1171.972 | 1125.548–1190.369 | 51.030 | 3 | built |
| scalar | 5000000 | btree | ix_c2 | 33.062 | 1066.342 | 1012.519–1078.123 | 29.933 | 3 | built |
| scalar | 5000000 | btree | ix_c20 | 33.070 | 1268.218 | 1238.580–1281.172 | 29.931 | 3 | built |
| scalar | 5000000 | btree | ix_c200 | 33.148 | 1238.124 | 1231.743–1258.740 | 29.935 | 3 | built |
| scalar | 5000000 | btree | ix_c20k | 34.383 | 1114.367 | 1049.449–1130.644 | 30.084 | 3 | built |
| scalar | 5000000 | btree | ix_clustered | 33.172 | 846.243 | 799.156–853.131 | 29.937 | 3 | built |
| scalar | 5000000 | btree | ix_nullable | 33.148 | 1250.933 | 1190.000–1291.809 | 29.934 | 3 | built |
| scalar | 5000000 | btree | ix_skew | 33.219 | 953.645 | 938.091–968.579 | 29.944 | 3 | built |
| scalar | 5000000 | btree_tuned | ix_c1m | 56.258 | 1094.422 | 1083.924–1135.695 | 51.033 | 3 | built |
| scalar | 5000000 | btree_tuned | ix_c2 | 33.062 | 1011.988 | 990.602–1072.864 | 29.935 | 3 | built |
| scalar | 5000000 | btree_tuned | ix_c20 | 33.070 | 1212.955 | 1206.581–1230.019 | 29.934 | 3 | built |
| scalar | 5000000 | btree_tuned | ix_c200 | 33.148 | 1168.342 | 1156.146–1218.152 | 29.937 | 3 | built |
| scalar | 5000000 | btree_tuned | ix_c20k | 34.383 | 1071.276 | 1046.275–1108.705 | 30.086 | 3 | built |
| scalar | 5000000 | btree_tuned | ix_clustered | 33.172 | 844.014 | 841.625–844.615 | 29.935 | 3 | built |
| scalar | 5000000 | btree_tuned | ix_composite | 34.977 | 1634.450 | 1632.763–1659.838 | 30.538 | 3 | built |
| scalar | 5000000 | btree_tuned | ix_covering | 537.781 | 3310.429 | 3267.912–3538.841 | 485.563 | 3 | built |
| scalar | 5000000 | btree_tuned | ix_nullable | 33.148 | 1190.600 | 1183.219–1201.539 | 29.936 | 3 | built |
| scalar | 5000000 | btree_tuned | ix_skew | 33.219 | 936.530 | 924.701–955.152 | 29.941 | 3 | built |
| scalar | 5000000 | gin | ix_c1m | 87.367 | 3742.658 | 3721.064–3763.478 | 44.596 | 3 | built |
| scalar | 5000000 | gin | ix_c2 | 5.297 | 437.519 | 428.890–448.119 | 5.224 | 3 | built |
| scalar | 5000000 | gin | ix_c20 | 7.047 | 517.727 | 508.069–524.772 | 6.800 | 3 | built |
| scalar | 5000000 | gin | ix_c200 | 12.516 | 608.978 | 603.784–612.038 | 10.006 | 3 | built |
| scalar | 5000000 | gin | ix_c20k | 26.281 | 1059.908 | 1043.522–1083.303 | 15.406 | 3 | built |
| scalar | 5000000 | gin | ix_clustered | 7.828 | 536.879 | 514.517–543.024 | 5.141 | 3 | built |
| scalar | 5000000 | gin | ix_nullable | 11.562 | 613.202 | 585.943–637.615 | 9.772 | 3 | built |
| scalar | 5000000 | gin | ix_skew | 6.883 | 564.983 | 544.673–571.675 | 6.091 | 3 | built |
| scalar | 5000000 | gist | ix_c1m | 96.242 | 4088.041 | 4045.048–4102.650 | 96.598 | 3 | built |
| scalar | 5000000 | gist | ix_c2 | 96.242 | 3373.072 | 3297.564–3487.593 | 96.596 | 3 | built |
| scalar | 5000000 | gist | ix_c20 | 96.242 | 4155.000 | 4140.634–4180.492 | 96.596 | 3 | built |
| scalar | 5000000 | gist | ix_c200 | 96.242 | 4224.763 | 4180.625–4260.325 | 96.597 | 3 | built |
| scalar | 5000000 | gist | ix_c20k | 96.242 | 4202.597 | 4195.452–4230.396 | 96.597 | 3 | built |
| scalar | 5000000 | gist | ix_clustered | 96.242 | 2032.460 | 2023.156–2034.350 | 96.594 | 3 | built |
| scalar | 5000000 | gist | ix_nullable | 101.039 | 4110.709 | 4066.684–4144.833 | 96.640 | 3 | built |
| scalar | 5000000 | gist | ix_skew | 96.242 | 3233.514 | 3224.969–3258.842 | 96.595 | 3 | built |
| scalar | 5000000 | hash | ix_c1m | 129.484 | 6271.624 | 6050.305–6403.480 | 345.922 | 3 | built |
| scalar | 5000000 | hash | ix_c2 | — | 57988.639 | 57988.639–57988.639 | 55.493 | 1 | FAILED / omitted |
| scalar | 5000000 | hash | ix_c20 | — | 59987.549 | 59987.549–59987.549 | 137.527 | 1 | FAILED / omitted |
| scalar | 5000000 | hash | ix_c200 | 223.242 | 46240.380 | 46134.940–48986.700 | 346.843 | 3 | built |
| scalar | 5000000 | hash | ix_c20k | 177.898 | 6101.111 | 6049.075–6146.038 | 346.399 | 3 | built |
| scalar | 5000000 | hash | ix_clustered | 223.328 | 17057.807 | 17055.638–17080.793 | 346.842 | 3 | built |
| scalar | 5000000 | hash | ix_nullable | 213.641 | 40848.509 | 40512.786–41610.935 | 312.390 | 3 | built |
| scalar | 5000000 | hash | ix_skew | — | 60024.864 | 60024.864–60024.864 | 44.367 | 1 | FAILED / omitted |
| scalar | 5000000 | roaring | ix_c1m | 115.930 | 6454.062 | 6448.233–6690.801 | 139.216 | 3 | built |
| scalar | 5000000 | roaring | ix_c2 | 12.242 | 2512.556 | 2496.572–2651.673 | 9.804 | 3 | built |
| scalar | 5000000 | roaring | ix_c20 | 10.820 | 4012.907 | 3954.824–4056.822 | 10.194 | 3 | built |
| scalar | 5000000 | roaring | ix_c200 | 15.164 | 4043.127 | 3921.983–4139.541 | 14.144 | 3 | built |
| scalar | 5000000 | roaring | ix_c20k | 37.023 | 3744.667 | 3551.139–3755.720 | 31.270 | 3 | built |
| scalar | 5000000 | roaring | ix_clustered | 1.109 | 1655.771 | 1617.014–1678.861 | 0.499 | 3 | built |
| scalar | 5000000 | roaring | ix_nullable | 16.156 | 4326.873 | 4218.052–4433.542 | 14.179 | 3 | built |
| scalar | 5000000 | roaring | ix_skew | 6.578 | 3184.280 | 3070.871–3219.954 | 5.150 | 3 | built |

## Measured visibility

| Suite | Rows | Family | State | Heap pages | All-visible pages | All-visible % |
| --- | --- | --- | --- | --- | --- | --- |
| scalar | 1000000 | roaring | clean | 19264 | 19231 | 99.83 |
| scalar | 1000000 | roaring | dirty_clustered_5pct | 20082 | 18268 | 90.97 |
| scalar | 1000000 | roaring | dirty_scattered | 20082 | 8769 | 43.67 |
| scalar | 1000000 | brin | clean | 19264 | 19231 | 99.83 |
| scalar | 1000000 | brin | dirty_clustered_5pct | 20082 | 18268 | 90.97 |
| scalar | 1000000 | brin | dirty_scattered | 20082 | 8769 | 43.67 |
| scalar | 1000000 | seq | clean | 19264 | 19231 | 99.83 |
| scalar | 1000000 | seq | dirty_clustered_5pct | 20082 | 18268 | 90.97 |
| scalar | 1000000 | seq | dirty_scattered | 20082 | 8769 | 43.67 |
| scalar | 1000000 | btree_tuned | clean | 19264 | 19231 | 99.83 |
| scalar | 1000000 | btree_tuned | dirty_clustered_5pct | 20082 | 18268 | 90.97 |
| scalar | 1000000 | btree_tuned | dirty_scattered | 20082 | 8769 | 43.67 |
| scalar | 1000000 | gist | clean | 19264 | 19231 | 99.83 |
| scalar | 1000000 | gist | dirty_clustered_5pct | 20082 | 18268 | 90.97 |
| scalar | 1000000 | gist | dirty_scattered | 20082 | 8769 | 43.67 |
| scalar | 1000000 | hash | clean | 19264 | 19231 | 99.83 |
| scalar | 1000000 | hash | dirty_clustered_5pct | 20082 | 18268 | 90.97 |
| scalar | 1000000 | hash | dirty_scattered | 20082 | 8769 | 43.67 |
| scalar | 1000000 | btree | clean | 19264 | 19231 | 99.83 |
| scalar | 1000000 | btree | dirty_clustered_5pct | 20082 | 18268 | 90.97 |
| scalar | 1000000 | btree | dirty_scattered | 20082 | 8769 | 43.67 |
| scalar | 1000000 | gin | clean | 19264 | 19231 | 99.83 |
| scalar | 1000000 | gin | dirty_clustered_5pct | 20082 | 18268 | 90.97 |
| scalar | 1000000 | gin | dirty_scattered | 20082 | 8769 | 43.67 |
| scalar | 5000000 | brin | clean | 96192 | 96154 | 99.96 |
| scalar | 5000000 | brin | dirty_clustered_5pct | 100407 | 91345 | 90.97 |
| scalar | 5000000 | brin | dirty_scattered | 100407 | 43846 | 43.67 |
| scalar | 5000000 | roaring | clean | 96192 | 96154 | 99.96 |
| scalar | 5000000 | roaring | dirty_clustered_5pct | 100407 | 91345 | 90.97 |
| scalar | 5000000 | roaring | dirty_scattered | 100407 | 43846 | 43.67 |
| scalar | 5000000 | seq | clean | 96192 | 96154 | 99.96 |
| scalar | 5000000 | seq | dirty_clustered_5pct | 100407 | 91345 | 90.97 |
| scalar | 5000000 | seq | dirty_scattered | 100407 | 43846 | 43.67 |
| scalar | 5000000 | btree_tuned | clean | 96192 | 96154 | 99.96 |
| scalar | 5000000 | btree_tuned | dirty_clustered_5pct | 100407 | 91345 | 90.97 |
| scalar | 5000000 | btree_tuned | dirty_scattered | 100407 | 43846 | 43.67 |
| scalar | 5000000 | hash | clean | 96192 | 96154 | 99.96 |
| scalar | 5000000 | hash | dirty_clustered_5pct | 100407 | 91345 | 90.97 |
| scalar | 5000000 | hash | dirty_scattered | 100407 | 43846 | 43.67 |
| scalar | 5000000 | gin | clean | 96192 | 96154 | 99.96 |
| scalar | 5000000 | gin | dirty_clustered_5pct | 100407 | 91345 | 90.97 |
| scalar | 5000000 | gin | dirty_scattered | 100407 | 43846 | 43.67 |
| scalar | 5000000 | btree | clean | 96192 | 96154 | 99.96 |
| scalar | 5000000 | btree | dirty_clustered_5pct | 100407 | 91345 | 90.97 |
| scalar | 5000000 | btree | dirty_scattered | 100407 | 43846 | 43.67 |
| scalar | 5000000 | gist | clean | 96192 | 96154 | 99.96 |
| scalar | 5000000 | gist | dirty_clustered_5pct | 100407 | 91345 | 90.97 |
| scalar | 5000000 | gist | dirty_scattered | 100407 | 43846 | 43.67 |
| documents | 200000 | roaring | clean | 6656 | 6628 | 99.58 |
| documents | 200000 | gin | clean | 6656 | 6628 | 99.58 |
| documents | 200000 | gist | clean | 6656 | 6628 | 99.58 |
| documents | 200000 | seq | clean | 6656 | 6628 | 99.58 |

## Selected plots

![Scalar portfolio size, 1,000,000 rows (lower is smaller)](size-1000000.svg)

![eq_c2_0, 1,000,000 clean rows, default planner (lower is faster)](eq_c2_0-1000000.svg)

![eq_c200_17, 1,000,000 clean rows, default planner (lower is faster)](eq_c200_17-1000000.svg)

![and3, 1,000,000 clean rows, default planner (lower is faster)](and3-1000000.svg)

![group_c200, 1,000,000 clean rows, default planner (lower is faster)](group_c200-1000000.svg)

![range_random, 1,000,000 clean rows, default planner (lower is faster)](range_random-1000000.svg)

![fetch_medium, 1,000,000 clean rows, default planner (lower is faster)](fetch_medium-1000000.svg)

![Scalar portfolio size, 5,000,000 rows (lower is smaller)](size-5000000.svg)

![eq_c2_0, 5,000,000 clean rows, default planner (lower is faster)](eq_c2_0-5000000.svg)

![eq_c200_17, 5,000,000 clean rows, default planner (lower is faster)](eq_c200_17-5000000.svg)

![and3, 5,000,000 clean rows, default planner (lower is faster)](and3-5000000.svg)

![group_c200, 5,000,000 clean rows, default planner (lower is faster)](group_c200-5000000.svg)

![range_random, 5,000,000 clean rows, default planner (lower is faster)](range_random-5000000.svg)

![fetch_medium, 5,000,000 clean rows, default planner (lower is faster)](fetch_medium-5000000.svg)


## Maintenance (single observations)

| Rows | Family | Operation | Elapsed attempt ms | WAL MiB | Indexes MiB after | Status |
| --- | --- | --- | --- | --- | --- | --- |
| 1000000 | roaring | insert | 570.828 | 90.547 | 85.227 | ok |
| 1000000 | roaring | indexed_update | 702.732 | 112.299 | 88.055 | ok |
| 1000000 | roaring | delete | 137.647 | 72.981 | 88.055 | ok |
| 1000000 | roaring | vacuum | 1140.706 | 316.493 | 88.055 | ok |
| 1000000 | roaring | reindex | 6744.794 | 94.871 | 72.828 | ok |
| 1000000 | brin | insert | 24.646 | 1.548 | 0.438 | ok |
| 1000000 | brin | indexed_update | 85.103 | 4.768 | 0.438 | ok |
| 1000000 | brin | delete | 141.625 | 72.983 | 0.438 | ok |
| 1000000 | brin | vacuum | 291.739 | 76.758 | 0.438 | ok |
| 1000000 | brin | reindex | 388.897 | 0.621 | 0.438 | ok |
| 1000000 | seq | insert | 19.175 | 1.548 | 0.000 | ok |
| 1000000 | seq | indexed_update | 70.952 | 4.768 | 0.000 | ok |
| 1000000 | seq | delete | 142.459 | 72.983 | 0.000 | ok |
| 1000000 | seq | vacuum | 228.833 | 76.046 | 0.000 | ok |
| 1000000 | seq | reindex | 2.440 | 0.024 | 0.000 | ok |
| 1000000 | btree_tuned | insert | 252.447 | 46.032 | 197.508 | ok |
| 1000000 | btree_tuned | indexed_update | 668.229 | 56.402 | 201.094 | ok |
| 1000000 | btree_tuned | delete | 143.901 | 72.911 | 201.094 | ok |
| 1000000 | btree_tuned | vacuum | 704.067 | 225.021 | 201.094 | ok |
| 1000000 | btree_tuned | reindex | 2682.699 | 162.379 | 180.133 | ok |
| 1000000 | gist | insert | 439.463 | 59.906 | 295.656 | ok |
| 1000000 | gist | indexed_update | 450.487 | 63.894 | 297.234 | ok |
| 1000000 | gist | delete | 129.297 | 72.981 | 297.234 | ok |
| 1000000 | gist | vacuum | 566.135 | 229.667 | 297.234 | ok |
| 1000000 | gist | reindex | 5534.512 | 154.464 | 155.078 | ok |
| 1000000 | hash (partial) | insert | 352.796 | 35.511 | 254.523 | ok |
| 1000000 | hash (partial) | indexed_update | 418.821 | 38.994 | 255.609 | ok |
| 1000000 | hash (partial) | delete | 136.988 | 72.981 | 255.609 | ok |
| 1000000 | hash (partial) | vacuum | 671.351 | 195.867 | 255.609 | ok |
| 1000000 | hash (partial) | reindex | 20652.927 | 409.084 | 250.344 | ok |
| 1000000 | btree | insert | 169.300 | 35.461 | 70.445 | ok |
| 1000000 | btree | indexed_update | 488.182 | 40.482 | 71.773 | ok |
| 1000000 | btree | delete | 141.194 | 72.981 | 71.773 | ok |
| 1000000 | btree | vacuum | 380.279 | 137.032 | 71.773 | ok |
| 1000000 | btree | reindex | 1768.748 | 59.146 | 65.703 | ok |
| 1000000 | gin | insert | 84.162 | 13.839 | 68.617 | ok |
| 1000000 | gin | indexed_update | 131.221 | 17.083 | 70.180 | ok |
| 1000000 | gin | delete | 136.830 | 72.981 | 70.180 | ok |
| 1000000 | gin | vacuum | 616.514 | 144.858 | 70.867 | ok |
| 1000000 | gin | reindex | 2738.146 | 31.544 | 60.281 | ok |
| 5000000 | brin | insert | 109.087 | 7.704 | 0.938 | ok |
| 5000000 | brin | indexed_update | 482.789 | 23.721 | 0.938 | ok |
| 5000000 | brin | delete | 852.607 | 364.913 | 0.938 | ok |
| 5000000 | brin | vacuum | 2493.769 | 383.099 | 0.938 | ok |
| 5000000 | brin | reindex | 3433.245 | 2.786 | 0.938 | ok |
| 5000000 | roaring | insert | 2869.842 | 434.996 | 333.891 | ok |
| 5000000 | roaring | indexed_update | 4677.845 | 512.967 | 362.594 | ok |
| 5000000 | roaring | delete | 994.566 | 364.903 | 362.594 | ok |
| 5000000 | roaring | vacuum | 7370.095 | 1189.409 | 362.852 | ok |
| 5000000 | roaring | reindex | 35041.542 | 224.632 | 216.656 | ok |
| 5000000 | seq | insert | 74.386 | 7.704 | 0.000 | ok |
| 5000000 | seq | indexed_update | 419.476 | 23.714 | 0.000 | ok |
| 5000000 | seq | delete | 889.705 | 364.899 | 0.000 | ok |
| 5000000 | seq | vacuum | 1846.265 | 379.995 | 0.000 | ok |
| 5000000 | seq | reindex | 2.360 | 0.021 | 0.000 | ok |
| 5000000 | btree_tuned | insert | 1162.542 | 173.082 | 930.516 | ok |
| 5000000 | btree_tuned | indexed_update | 2608.111 | 213.442 | 944.555 | ok |
| 5000000 | btree_tuned | delete | 1212.319 | 364.544 | 944.555 | ok |
| 5000000 | btree_tuned | vacuum | 5399.960 | 1085.416 | 944.555 | ok |
| 5000000 | btree_tuned | reindex | 16636.283 | 776.109 | 862.102 | ok |
| 5000000 | hash (partial) | insert | 2751.234 | 167.031 | 1115.234 | ok |
| 5000000 | hash (partial) | indexed_update | 3385.219 | 183.726 | 1119.648 | ok |
| 5000000 | hash (partial) | delete | 951.592 | 364.903 | 1119.648 | ok |
| 5000000 | hash (partial) | vacuum | 4245.252 | 877.026 | 1119.648 | ok |
| 5000000 | hash (partial) | reindex | 58909.488 | 778.260 | — | error |
| 5000000 | gin | insert | 365.817 | 69.077 | 199.711 | ok |
| 5000000 | gin | indexed_update | 985.148 | 85.129 | 199.711 | ok |
| 5000000 | gin | delete | 1121.616 | 364.903 | 199.711 | ok |
| 5000000 | gin | vacuum | 3843.292 | 580.152 | 199.711 | ok |
| 5000000 | gin | reindex | 13741.230 | 102.648 | 164.938 | ok |
| 5000000 | btree | insert | 825.098 | 127.176 | 303.531 | ok |
| 5000000 | btree | indexed_update | 1965.691 | 151.588 | 308.039 | ok |
| 5000000 | btree | delete | 958.776 | 364.903 | 308.039 | ok |
| 5000000 | btree | vacuum | 3600.494 | 648.342 | 308.039 | ok |
| 5000000 | btree | reindex | 11547.122 | 260.198 | 289.406 | ok |
| 5000000 | gist | insert | 2512.095 | 256.228 | 1489.523 | ok |
| 5000000 | gist | indexed_update | 2948.165 | 275.460 | 1500.539 | ok |
| 5000000 | gist | delete | 1030.454 | 364.903 | 1500.539 | ok |
| 5000000 | gist | vacuum | 4694.892 | 1143.081 | 1500.539 | ok |
| 5000000 | gist | reindex | 38502.772 | 772.183 | 774.602 | ok |

## Concurrent reads

| Rows | Variant | Clients | Query | Transactions/s | Median ms | p95 ms | Duration s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1000000 | roaring | 1 | and2 | 1954.8 | 0.503 | 0.590 | 5.00 |
| 1000000 | roaring | 4 | and2 | 7408.4 | 0.520 | 0.677 | 5.00 |
| 1000000 | roaring | 8 | and2 | 3543.1 | 2.482 | 4.004 | 5.00 |
| 1000000 | roaring_bitmap | 1 | and2 | 311.7 | 3.133 | 3.699 | 5.00 |
| 1000000 | roaring_bitmap | 4 | and2 | 1230.1 | 3.116 | 3.994 | 5.00 |
| 1000000 | roaring_bitmap | 8 | and2 | 2030.2 | 3.870 | 4.881 | 5.00 |
| 1000000 | brin | 1 | and2 | 13.8 | 71.325 | 83.065 | 5.02 |
| 1000000 | brin | 4 | and2 | 53.5 | 74.422 | 81.833 | 5.07 |
| 1000000 | brin | 8 | and2 | 89.7 | 87.902 | 100.217 | 5.08 |
| 1000000 | seq | 1 | and2 | 16.1 | 61.178 | 81.344 | 5.04 |
| 1000000 | seq | 4 | and2 | 81.0 | 48.997 | 52.626 | 5.04 |
| 1000000 | seq | 8 | and2 | 139.6 | 56.625 | 64.196 | 5.04 |
| 1000000 | btree_tuned | 1 | and2 | 2788.8 | 0.351 | 0.407 | 5.00 |
| 1000000 | btree_tuned | 4 | and2 | 10121.4 | 0.370 | 0.523 | 5.00 |
| 1000000 | btree_tuned | 8 | and2 | 2949.5 | 2.661 | 4.048 | 5.00 |
| 1000000 | gist | 1 | and2 | 309.3 | 3.130 | 3.721 | 5.00 |
| 1000000 | gist | 4 | and2 | 1209.4 | 3.156 | 4.106 | 5.00 |
| 1000000 | gist | 8 | and2 | 2002.2 | 3.949 | 4.919 | 5.00 |
| 1000000 | hash (partial) | 1 | and2 | 313.8 | 3.085 | 3.668 | 5.00 |
| 1000000 | hash (partial) | 4 | and2 | 1222.4 | 3.115 | 4.087 | 5.00 |
| 1000000 | hash (partial) | 8 | and2 | 2107.4 | 3.720 | 4.654 | 5.00 |
| 1000000 | btree | 1 | and2 | 337.0 | 2.924 | 3.250 | 5.00 |
| 1000000 | btree | 4 | and2 | 1286.7 | 2.954 | 3.926 | 5.00 |
| 1000000 | btree | 8 | and2 | 2192.8 | 3.594 | 4.463 | 5.00 |
| 1000000 | gin | 1 | and2 | 27.8 | 35.578 | 40.304 | 5.03 |
| 1000000 | gin | 4 | and2 | 107.1 | 36.985 | 41.097 | 5.03 |
| 1000000 | gin | 8 | and2 | 182.3 | 43.395 | 49.908 | 5.04 |
| 5000000 | brin | 1 | and2 | 2.4 | 410.117 | 417.695 | 5.34 |
| 5000000 | brin | 4 | and2 | 11.3 | 342.043 | 412.422 | 5.30 |
| 5000000 | brin | 8 | and2 | 21.8 | 354.562 | 429.607 | 5.14 |
| 5000000 | roaring | 1 | and2 | 569.5 | 1.714 | 2.023 | 5.00 |
| 5000000 | roaring | 4 | and2 | 2227.5 | 1.718 | 2.225 | 5.00 |
| 5000000 | roaring | 8 | and2 | 3923.3 | 2.037 | 2.451 | 5.00 |
| 5000000 | roaring_bitmap | 1 | and2 | 26.6 | 36.856 | 41.420 | 5.00 |
| 5000000 | roaring_bitmap | 4 | and2 | 96.6 | 41.158 | 44.772 | 5.01 |
| 5000000 | roaring_bitmap | 8 | and2 | 165.9 | 48.135 | 51.492 | 5.01 |
| 5000000 | seq | 1 | and2 | 2.5 | 395.547 | 410.456 | 5.16 |
| 5000000 | seq | 4 | and2 | 11.5 | 341.060 | 394.535 | 5.24 |
| 5000000 | seq | 8 | and2 | 22.6 | 336.556 | 400.462 | 5.30 |
| 5000000 | btree_tuned | 1 | and2 | 1069.8 | 0.920 | 0.993 | 5.00 |
| 5000000 | btree_tuned | 4 | and2 | 3980.0 | 0.968 | 1.260 | 5.00 |
| 5000000 | btree_tuned | 8 | and2 | 6293.7 | 1.191 | 1.653 | 5.00 |
| 5000000 | hash (partial) | 1 | and2 | 65.8 | 14.868 | 17.169 | 5.02 |
| 5000000 | hash (partial) | 4 | and2 | 246.5 | 15.970 | 18.336 | 5.01 |
| 5000000 | hash (partial) | 8 | and2 | 425.7 | 18.710 | 21.208 | 5.02 |
| 5000000 | gin | 1 | and2 | 5.8 | 172.097 | 182.210 | 5.00 |
| 5000000 | gin | 4 | and2 | 22.0 | 182.091 | 190.513 | 5.10 |
| 5000000 | gin | 8 | and2 | 37.4 | 210.981 | 225.348 | 5.13 |
| 5000000 | btree | 1 | and2 | 68.8 | 14.271 | 16.418 | 5.00 |
| 5000000 | btree | 4 | and2 | 267.9 | 14.621 | 16.919 | 5.01 |
| 5000000 | btree | 8 | and2 | 465.4 | 17.111 | 19.534 | 5.01 |
| 5000000 | gist | 1 | and2 | 68.7 | 14.185 | 16.493 | 5.01 |
| 5000000 | gist | 4 | and2 | 256.0 | 15.329 | 17.608 | 5.02 |
| 5000000 | gist | 8 | and2 | 445.4 | 17.807 | 20.351 | 5.02 |

## Every query and configuration

| Suite | Rows | State | Planner | work_mem | Query | Variant | n | Execution median ms | 95% CI ms | p95 ms | CV | Speedup vs seq | Access | Planning median ms | Plan+execution median ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| documents | 200000 | clean | default | 64MB | array_and | gin | 10 | 0.855 | 0.826–0.894 | 0.956 | 6.3% | 38.40 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 0.908 |
| documents | 200000 | clean | default | 64MB | array_and | gist | 10 | 31.604 | 30.720–33.302 | 34.592 | 4.9% | 1.04 | Seq Scan (fallback) | 0.051 | 31.656 |
| documents | 200000 | clean | default | 64MB | array_and | roaring | 10 | 0.103 | 0.102–0.103 | 0.106 | 1.7% | 318.95 | RoaringCount | 0.074 | 0.178 |
| documents | 200000 | clean | default | 64MB | array_and | roaring_bitmap | 10 | 0.177 | 0.175–0.197 | 0.206 | 7.3% | 185.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 0.229 |
| documents | 200000 | clean | default | 64MB | array_and | seq | 10 | 32.852 | 31.079–37.601 | 40.161 | 10.9% | 1.00 | Seq Scan | 0.048 | 32.906 |
| documents | 200000 | clean | default | 64MB | array_common | gin | 10 | 3.729 | 3.686–3.880 | 3.909 | 2.6% | 8.28 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 3.780 |
| documents | 200000 | clean | default | 64MB | array_common | gist | 10 | 30.994 | 30.579–32.257 | 33.464 | 3.7% | 1.00 | Seq Scan (fallback) | 0.050 | 31.046 |
| documents | 200000 | clean | default | 64MB | array_common | roaring | 10 | 0.023 | 0.022–0.024 | 0.025 | 4.5% | 1342.74 | RoaringCount | 0.072 | 0.096 |
| documents | 200000 | clean | default | 64MB | array_common | roaring_bitmap | 10 | 3.276 | 3.238–3.438 | 3.490 | 3.1% | 9.43 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 3.328 |
| documents | 200000 | clean | default | 64MB | array_common | seq | 10 | 30.883 | 30.460–31.463 | 35.964 | 7.9% | 1.00 | Seq Scan | 0.046 | 30.937 |
| documents | 200000 | clean | default | 64MB | array_contained | gin | 10 | 10.540 | 10.239–10.740 | 10.838 | 2.7% | 3.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 10.603 |
| documents | 200000 | clean | default | 64MB | array_contained | gist | 10 | 32.678 | 32.164–34.148 | 36.845 | 5.8% | 0.99 | Seq Scan (fallback) | 0.063 | 32.758 |
| documents | 200000 | clean | default | 64MB | array_contained | roaring | 10 | 58.443 | 55.977–59.122 | 61.801 | 4.6% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 58.504 |
| documents | 200000 | clean | default | 64MB | array_contained | roaring_bitmap | 10 | 59.519 | 58.011–61.544 | 62.404 | 4.0% | 0.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 59.584 |
| documents | 200000 | clean | default | 64MB | array_contained | seq | 10 | 32.407 | 31.349–33.776 | 35.092 | 4.5% | 1.00 | Seq Scan | 0.061 | 32.466 |
| documents | 200000 | clean | default | 64MB | array_empty | gin | 10 | 27.907 | 27.243–28.587 | 28.878 | 2.5% | 1.02 | Seq Scan (fallback) | 0.051 | 27.959 |
| documents | 200000 | clean | default | 64MB | array_empty | gist | 10 | 28.250 | 27.706–29.791 | 34.385 | 10.7% | 1.01 | Seq Scan (fallback) | 0.049 | 28.299 |
| documents | 200000 | clean | default | 64MB | array_empty | roaring | 10 | 28.941 | 28.224–30.986 | 33.114 | 7.0% | 0.99 | Seq Scan (fallback) | 0.051 | 28.992 |
| documents | 200000 | clean | default | 64MB | array_empty | roaring_bitmap | 10 | 28.520 | 27.835–29.513 | 30.814 | 4.3% | 1.00 | Seq Scan (fallback) | 0.050 | 28.575 |
| documents | 200000 | clean | default | 64MB | array_empty | seq | 10 | 28.515 | 27.594–32.050 | 36.224 | 11.4% | 1.00 | Seq Scan | 0.045 | 28.561 |
| documents | 200000 | clean | default | 64MB | array_fetch | gin | 10 | 4.158 | 4.012–4.661 | 5.230 | 11.1% | 7.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 4.214 |
| documents | 200000 | clean | default | 64MB | array_fetch | gist | 10 | 31.439 | 30.957–32.128 | 35.151 | 6.3% | 1.01 | Seq Scan (fallback) | 0.052 | 31.491 |
| documents | 200000 | clean | default | 64MB | array_fetch | roaring | 10 | 3.686 | 3.609–3.763 | 4.150 | 6.9% | 8.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 3.740 |
| documents | 200000 | clean | default | 64MB | array_fetch | roaring_bitmap | 10 | 3.667 | 3.588–3.743 | 3.931 | 4.2% | 8.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 3.723 |
| documents | 200000 | clean | default | 64MB | array_fetch | seq | 10 | 31.861 | 30.813–34.006 | 35.590 | 6.0% | 1.00 | Seq Scan | 0.049 | 31.913 |
| documents | 200000 | clean | default | 64MB | array_group | gin | 10 | 7.871 | 7.596–8.067 | 8.154 | 3.2% | 5.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 7.934 |
| documents | 200000 | clean | default | 64MB | array_group | gist | 10 | 42.367 | 41.318–46.123 | 51.098 | 8.9% | 1.02 | Seq Scan (fallback) | 0.061 | 42.429 |
| documents | 200000 | clean | default | 64MB | array_group | roaring | 10 | 4.397 | 4.314–4.494 | 4.519 | 2.1% | 9.80 | RoaringCount | 0.086 | 4.486 |
| documents | 200000 | clean | default | 64MB | array_group | roaring_bitmap | 10 | 6.715 | 6.584–6.971 | 7.522 | 5.7% | 6.42 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 6.780 |
| documents | 200000 | clean | default | 64MB | array_group | seq | 10 | 43.108 | 41.041–46.819 | 48.593 | 7.3% | 1.00 | Seq Scan | 0.058 | 43.166 |
| documents | 200000 | clean | default | 64MB | array_is_null | gin | 10 | 8.907 | 8.546–10.212 | 11.368 | 13.2% | 1.02 | Seq Scan (fallback) | 0.022 | 8.929 |
| documents | 200000 | clean | default | 64MB | array_is_null | gist | 10 | 10.056 | 9.500–10.502 | 10.733 | 6.8% | 0.90 | Seq Scan (fallback) | 0.023 | 10.079 |
| documents | 200000 | clean | default | 64MB | array_is_null | roaring | 10 | 1.126 | 1.073–1.297 | 1.352 | 10.3% | 8.04 | Bitmap Heap Scan, Bitmap Index Scan | 0.025 | 1.154 |
| documents | 200000 | clean | default | 64MB | array_is_null | roaring_bitmap | 10 | 1.107 | 1.054–1.127 | 1.157 | 3.7% | 8.18 | Bitmap Heap Scan, Bitmap Index Scan | 0.025 | 1.131 |
| documents | 200000 | clean | default | 64MB | array_is_null | seq | 10 | 9.055 | 8.680–9.759 | 10.342 | 7.3% | 1.00 | Seq Scan | 0.018 | 9.073 |
| documents | 200000 | clean | default | 64MB | array_null_element | gin | 10 | 0.043 | 0.042–0.043 | 0.043 | 2.0% | 732.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 0.096 |
| documents | 200000 | clean | default | 64MB | array_null_element | gist | 10 | 31.091 | 30.713–31.966 | 33.970 | 4.7% | 1.01 | Seq Scan (fallback) | 0.049 | 31.142 |
| documents | 200000 | clean | default | 64MB | array_null_element | roaring | 10 | 54.957 | 54.283–57.287 | 61.955 | 5.8% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 55.009 |
| documents | 200000 | clean | default | 64MB | array_null_element | roaring_bitmap | 10 | 55.617 | 53.572–59.309 | 63.275 | 7.2% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 55.667 |
| documents | 200000 | clean | default | 64MB | array_null_element | seq | 10 | 31.497 | 30.483–33.684 | 35.171 | 6.4% | 1.00 | Seq Scan | 0.046 | 31.543 |
| documents | 200000 | clean | default | 64MB | array_or | gin | 10 | 6.415 | 6.357–6.543 | 6.785 | 2.8% | 7.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 6.468 |
| documents | 200000 | clean | default | 64MB | array_or | gist | 10 | 46.260 | 45.856–52.823 | 54.397 | 7.9% | 1.05 | Seq Scan (fallback) | 0.051 | 46.312 |
| documents | 200000 | clean | default | 64MB | array_or | roaring | 10 | 0.227 | 0.220–0.246 | 0.259 | 7.5% | 214.58 | RoaringCount | 0.076 | 0.308 |
| documents | 200000 | clean | default | 64MB | array_or | roaring_bitmap | 10 | 5.242 | 5.075–5.433 | 5.607 | 4.5% | 9.27 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 5.293 |
| documents | 200000 | clean | default | 64MB | array_or | seq | 10 | 48.602 | 46.077–50.471 | 52.411 | 5.4% | 1.00 | Seq Scan | 0.047 | 48.650 |
| documents | 200000 | clean | default | 64MB | array_rare | gin | 10 | 0.074 | 0.073–0.076 | 0.089 | 10.8% | 413.24 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 0.127 |
| documents | 200000 | clean | default | 64MB | array_rare | gist | 10 | 30.792 | 29.980–32.333 | 33.191 | 4.2% | 0.99 | Seq Scan (fallback) | 0.051 | 30.844 |
| documents | 200000 | clean | default | 64MB | array_rare | roaring | 10 | 0.015 | 0.013–0.016 | 0.016 | 9.6% | 2038.63 | RoaringCount | 0.079 | 0.094 |
| documents | 200000 | clean | default | 64MB | array_rare | roaring_bitmap | 10 | 0.076 | 0.073–0.081 | 0.084 | 5.9% | 399.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 0.133 |
| documents | 200000 | clean | default | 64MB | array_rare | seq | 10 | 30.580 | 29.529–34.462 | 37.830 | 10.3% | 1.00 | Seq Scan | 0.046 | 30.625 |
| documents | 200000 | clean | default | 64MB | ts_and | gin | 10 | 0.952 | 0.938–0.975 | 0.995 | 2.7% | 25.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 0.998 |
| documents | 200000 | clean | default | 64MB | ts_and | gist | 10 | 9.128 | 9.031–9.402 | 9.752 | 3.3% | 2.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 9.174 |
| documents | 200000 | clean | default | 64MB | ts_and | roaring | 10 | 0.102 | 0.100–0.104 | 0.125 | 12.3% | 238.56 | RoaringCount | 0.064 | 0.165 |
| documents | 200000 | clean | default | 64MB | ts_and | roaring_bitmap | 10 | 0.180 | 0.173–0.193 | 0.221 | 11.3% | 135.19 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 0.237 |
| documents | 200000 | clean | default | 64MB | ts_and | seq | 10 | 24.334 | 23.145–26.748 | 28.884 | 10.0% | 1.00 | Seq Scan | 0.041 | 24.378 |
| documents | 200000 | clean | default | 64MB | ts_common | gin | 10 | 28.312 | 27.511–29.596 | 32.859 | 7.6% | 1.00 | Seq Scan (fallback) | 0.044 | 28.362 |
| documents | 200000 | clean | default | 64MB | ts_common | gist | 10 | 28.268 | 27.867–30.294 | 35.143 | 10.7% | 1.00 | Seq Scan (fallback) | 0.043 | 28.310 |
| documents | 200000 | clean | default | 64MB | ts_common | roaring | 10 | 0.029 | 0.028–0.031 | 0.033 | 7.7% | 991.23 | RoaringCount | 0.064 | 0.093 |
| documents | 200000 | clean | default | 64MB | ts_common | roaring_bitmap | 10 | 28.060 | 27.227–29.512 | 32.891 | 9.0% | 1.01 | Seq Scan (fallback) | 0.046 | 28.104 |
| documents | 200000 | clean | default | 64MB | ts_common | seq | 10 | 28.250 | 27.181–29.013 | 31.113 | 5.9% | 1.00 | Seq Scan | 0.038 | 28.288 |
| documents | 200000 | clean | default | 64MB | ts_fetch | gin | 10 | 4.029 | 3.998–4.123 | 4.242 | 2.4% | 5.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 4.080 |
| documents | 200000 | clean | default | 64MB | ts_fetch | gist | 10 | 13.389 | 12.581–14.627 | 16.635 | 11.3% | 1.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 13.439 |
| documents | 200000 | clean | default | 64MB | ts_fetch | roaring | 10 | 3.712 | 3.639–3.886 | 4.214 | 6.5% | 6.13 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 3.761 |
| documents | 200000 | clean | default | 64MB | ts_fetch | roaring_bitmap | 10 | 3.673 | 3.597–3.788 | 3.975 | 4.5% | 6.19 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 3.720 |
| documents | 200000 | clean | default | 64MB | ts_fetch | seq | 10 | 22.736 | 22.253–23.358 | 26.174 | 8.1% | 1.00 | Seq Scan | 0.042 | 22.778 |
| documents | 200000 | clean | default | 64MB | ts_group | gin | 10 | 0.980 | 0.953–1.013 | 1.040 | 3.8% | 26.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 1.034 |
| documents | 200000 | clean | default | 64MB | ts_group | gist | 10 | 9.140 | 9.047–9.282 | 9.735 | 3.5% | 2.86 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 9.194 |
| documents | 200000 | clean | default | 64MB | ts_group | roaring | 10 | 1.628 | 1.536–1.688 | 1.736 | 6.2% | 16.08 | RoaringCount | 0.074 | 1.719 |
| documents | 200000 | clean | default | 64MB | ts_group | roaring_bitmap | 10 | 0.195 | 0.189–0.204 | 0.219 | 7.4% | 134.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 0.249 |
| documents | 200000 | clean | default | 64MB | ts_group | seq | 10 | 26.172 | 23.493–28.359 | 29.010 | 9.5% | 1.00 | Seq Scan | 0.047 | 26.227 |
| documents | 200000 | clean | default | 64MB | ts_not | gin | 10 | 36.383 | 34.959–39.300 | 42.838 | 9.1% | 0.96 | Seq Scan (fallback) | 0.045 | 36.428 |
| documents | 200000 | clean | default | 64MB | ts_not | gist | 10 | 35.203 | 33.803–35.952 | 37.523 | 4.3% | 0.99 | Seq Scan (fallback) | 0.045 | 35.246 |
| documents | 200000 | clean | default | 64MB | ts_not | roaring | 10 | 34.946 | 33.775–36.628 | 40.404 | 8.0% | 1.00 | Seq Scan (fallback) | 0.046 | 34.989 |
| documents | 200000 | clean | default | 64MB | ts_not | roaring_bitmap | 10 | 35.410 | 34.476–37.947 | 40.646 | 7.0% | 0.99 | Seq Scan (fallback) | 0.042 | 35.452 |
| documents | 200000 | clean | default | 64MB | ts_not | seq | 10 | 35.008 | 33.616–36.429 | 37.715 | 4.9% | 1.00 | Seq Scan | 0.038 | 35.052 |
| documents | 200000 | clean | default | 64MB | ts_or | gin | 10 | 6.753 | 6.613–6.805 | 6.875 | 1.7% | 5.43 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 6.798 |
| documents | 200000 | clean | default | 64MB | ts_or | gist | 10 | 22.367 | 22.094–23.218 | 24.167 | 3.7% | 1.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 22.416 |
| documents | 200000 | clean | default | 64MB | ts_or | roaring | 10 | 0.223 | 0.221–0.227 | 0.241 | 4.0% | 164.56 | RoaringCount | 0.066 | 0.290 |
| documents | 200000 | clean | default | 64MB | ts_or | roaring_bitmap | 10 | 5.199 | 5.069–5.459 | 5.515 | 4.0% | 7.06 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 5.242 |
| documents | 200000 | clean | default | 64MB | ts_or | seq | 10 | 36.697 | 35.341–42.406 | 42.634 | 8.4% | 1.00 | Seq Scan | 0.038 | 36.737 |
| documents | 200000 | clean | default | 64MB | ts_phrase | gin | 10 | 6.765 | 6.589–7.499 | 8.269 | 9.5% | 4.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 6.809 |
| documents | 200000 | clean | default | 64MB | ts_phrase | gist | 10 | 16.723 | 16.649–17.562 | 20.703 | 11.3% | 1.86 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 16.776 |
| documents | 200000 | clean | default | 64MB | ts_phrase | roaring | 10 | 68.028 | 64.792–74.723 | 75.906 | 6.8% | 0.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 68.073 |
| documents | 200000 | clean | default | 64MB | ts_phrase | roaring_bitmap | 10 | 68.684 | 66.198–70.495 | 72.653 | 4.2% | 0.45 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 68.726 |
| documents | 200000 | clean | default | 64MB | ts_phrase | seq | 10 | 31.119 | 30.060–32.229 | 33.360 | 4.5% | 1.00 | Seq Scan | 0.038 | 31.160 |
| documents | 200000 | clean | default | 64MB | ts_prefix | gin | 10 | 1.572 | 1.539–1.625 | 1.746 | 5.4% | 15.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 1.620 |
| documents | 200000 | clean | default | 64MB | ts_prefix | gist | 10 | 42.712 | 42.111–43.454 | 43.622 | 2.5% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 42.757 |
| documents | 200000 | clean | default | 64MB | ts_prefix | roaring | 10 | 59.537 | 58.031–62.099 | 66.860 | 5.8% | 0.40 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 59.582 |
| documents | 200000 | clean | default | 64MB | ts_prefix | roaring_bitmap | 10 | 60.775 | 58.723–63.207 | 64.815 | 4.7% | 0.39 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 60.819 |
| documents | 200000 | clean | default | 64MB | ts_prefix | seq | 10 | 23.608 | 23.317–24.433 | 27.210 | 7.6% | 1.00 | Seq Scan | 0.040 | 23.651 |
| documents | 200000 | clean | default | 64MB | ts_rare | gin | 10 | 0.035 | 0.035–0.036 | 0.037 | 3.0% | 604.33 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 0.081 |
| documents | 200000 | clean | default | 64MB | ts_rare | gist | 10 | 1.755 | 1.662–1.789 | 1.814 | 3.8% | 12.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 1.804 |
| documents | 200000 | clean | default | 64MB | ts_rare | roaring | 10 | 0.011 | 0.010–0.014 | 0.032 | 70.5% | 1839.26 | RoaringCount | 0.062 | 0.075 |
| documents | 200000 | clean | default | 64MB | ts_rare | roaring_bitmap | 10 | 0.036 | 0.035–0.039 | 0.044 | 12.0% | 587.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.080 |
| documents | 200000 | clean | default | 64MB | ts_rare | seq | 10 | 21.151 | 20.941–21.898 | 22.910 | 3.9% | 1.00 | Seq Scan | 0.037 | 21.195 |
| documents | 200000 | clean | default | 64MB | ts_tree | gin | 10 | 3.415 | 3.355–3.495 | 3.519 | 2.2% | 9.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 3.461 |
| documents | 200000 | clean | default | 64MB | ts_tree | gist | 10 | 13.128 | 12.867–13.473 | 14.406 | 5.2% | 2.35 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 13.173 |
| documents | 200000 | clean | default | 64MB | ts_tree | roaring | 10 | 0.439 | 0.425–0.462 | 0.464 | 4.1% | 70.25 | RoaringCount | 0.073 | 0.519 |
| documents | 200000 | clean | default | 64MB | ts_tree | roaring_bitmap | 10 | 0.698 | 0.672–0.718 | 0.729 | 3.4% | 44.17 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.742 |
| documents | 200000 | clean | default | 64MB | ts_tree | seq | 10 | 30.806 | 29.806–32.009 | 34.185 | 5.5% | 1.00 | Seq Scan | 0.038 | 30.843 |
| documents | 200000 | clean | default | 64MB | ts_weight | gin | 10 | 4.889 | 4.662–4.968 | 5.167 | 4.1% | 4.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 4.944 |
| documents | 200000 | clean | default | 64MB | ts_weight | gist | 10 | 13.006 | 12.606–13.246 | 13.529 | 3.4% | 1.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 13.062 |
| documents | 200000 | clean | default | 64MB | ts_weight | roaring | 10 | 58.755 | 56.843–64.389 | 69.852 | 8.6% | 0.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 58.796 |
| documents | 200000 | clean | default | 64MB | ts_weight | roaring_bitmap | 10 | 61.133 | 57.129–62.050 | 64.107 | 4.9% | 0.36 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 61.178 |
| documents | 200000 | clean | default | 64MB | ts_weight | seq | 10 | 22.095 | 21.698–22.956 | 23.888 | 4.4% | 1.00 | Seq Scan | 0.037 | 22.132 |
| documents | 200000 | clean | prefer_index | 64MB | array_and | gin | 10 | 0.859 | 0.850–0.873 | 0.908 | 3.1% | 37.00 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 0.917 |
| documents | 200000 | clean | prefer_index | 64MB | array_and | gist | 10 | 31.057 | 30.548–32.510 | 35.102 | 6.1% | 1.02 | Seq Scan (fallback) | 0.050 | 31.108 |
| documents | 200000 | clean | prefer_index | 64MB | array_and | roaring | 10 | 0.103 | 0.101–0.106 | 0.112 | 4.9% | 306.87 | RoaringCount | 0.074 | 0.179 |
| documents | 200000 | clean | prefer_index | 64MB | array_and | roaring_bitmap | 10 | 0.189 | 0.171–0.200 | 0.207 | 8.0% | 168.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 0.244 |
| documents | 200000 | clean | prefer_index | 64MB | array_and | seq | 10 | 31.761 | 30.692–33.366 | 34.574 | 5.1% | 1.00 | Seq Scan | 0.046 | 31.813 |
| documents | 200000 | clean | prefer_index | 64MB | array_common | gin | 10 | 3.833 | 3.755–3.961 | 3.996 | 2.8% | 8.17 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 3.910 |
| documents | 200000 | clean | prefer_index | 64MB | array_common | gist | 10 | 31.394 | 30.902–32.054 | 33.542 | 3.5% | 1.00 | Seq Scan (fallback) | 0.050 | 31.442 |
| documents | 200000 | clean | prefer_index | 64MB | array_common | roaring | 10 | 0.023 | 0.022–0.026 | 0.042 | 37.3% | 1362.52 | RoaringCount | 0.073 | 0.097 |
| documents | 200000 | clean | prefer_index | 64MB | array_common | roaring_bitmap | 10 | 3.266 | 3.222–3.372 | 3.543 | 4.3% | 9.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 3.320 |
| documents | 200000 | clean | prefer_index | 64MB | array_common | seq | 10 | 31.338 | 30.800–32.514 | 34.109 | 4.5% | 1.00 | Seq Scan | 0.048 | 31.401 |
| documents | 200000 | clean | prefer_index | 64MB | array_contained | gin | 10 | 10.750 | 10.254–12.380 | 14.139 | 13.5% | 3.06 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 10.816 |
| documents | 200000 | clean | prefer_index | 64MB | array_contained | gist | 10 | 31.949 | 31.522–33.288 | 34.840 | 4.2% | 1.03 | Seq Scan (fallback) | 0.063 | 32.017 |
| documents | 200000 | clean | prefer_index | 64MB | array_contained | roaring | 10 | 58.911 | 55.730–61.901 | 64.134 | 5.7% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 58.979 |
| documents | 200000 | clean | prefer_index | 64MB | array_contained | roaring_bitmap | 10 | 58.871 | 56.218–62.452 | 67.600 | 8.0% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 58.944 |
| documents | 200000 | clean | prefer_index | 64MB | array_contained | seq | 10 | 32.853 | 31.648–34.808 | 40.280 | 11.0% | 1.00 | Seq Scan | 0.065 | 32.913 |
| documents | 200000 | clean | prefer_index | 64MB | array_empty | gin | 10 | 44.413 | 43.673–45.020 | 45.369 | 2.3% | 0.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 44.465 |
| documents | 200000 | clean | prefer_index | 64MB | array_empty | gist | 10 | 28.813 | 28.047–30.639 | 30.970 | 4.2% | 1.00 | Seq Scan (fallback) | 0.050 | 28.861 |
| documents | 200000 | clean | prefer_index | 64MB | array_empty | roaring | 10 | 54.002 | 53.150–57.263 | 62.118 | 7.4% | 0.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 54.054 |
| documents | 200000 | clean | prefer_index | 64MB | array_empty | roaring_bitmap | 10 | 53.572 | 51.671–56.146 | 57.658 | 4.6% | 0.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 53.620 |
| documents | 200000 | clean | prefer_index | 64MB | array_empty | seq | 10 | 28.901 | 27.713–29.866 | 31.173 | 4.9% | 1.00 | Seq Scan | 0.044 | 28.946 |
| documents | 200000 | clean | prefer_index | 64MB | array_fetch | gin | 10 | 4.152 | 4.071–4.294 | 4.960 | 10.2% | 7.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 4.207 |
| documents | 200000 | clean | prefer_index | 64MB | array_fetch | gist | 10 | 31.656 | 31.122–32.870 | 34.735 | 4.6% | 0.99 | Seq Scan (fallback) | 0.054 | 31.709 |
| documents | 200000 | clean | prefer_index | 64MB | array_fetch | roaring | 10 | 3.704 | 3.617–4.576 | 5.726 | 21.0% | 8.49 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 3.761 |
| documents | 200000 | clean | prefer_index | 64MB | array_fetch | roaring_bitmap | 10 | 3.662 | 3.620–3.710 | 3.813 | 2.2% | 8.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 3.718 |
| documents | 200000 | clean | prefer_index | 64MB | array_fetch | seq | 10 | 31.456 | 30.725–33.640 | 36.752 | 7.4% | 1.00 | Seq Scan | 0.051 | 31.510 |
| documents | 200000 | clean | prefer_index | 64MB | array_group | gin | 10 | 7.913 | 7.714–8.865 | 10.482 | 13.6% | 5.43 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 7.973 |
| documents | 200000 | clean | prefer_index | 64MB | array_group | gist | 10 | 43.181 | 41.573–44.585 | 48.159 | 5.8% | 0.99 | Seq Scan (fallback) | 0.061 | 43.246 |
| documents | 200000 | clean | prefer_index | 64MB | array_group | roaring | 10 | 4.369 | 4.353–4.522 | 4.697 | 3.3% | 9.83 | RoaringCount | 0.085 | 4.456 |
| documents | 200000 | clean | prefer_index | 64MB | array_group | roaring_bitmap | 10 | 6.788 | 6.682–7.163 | 7.494 | 5.2% | 6.32 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 6.853 |
| documents | 200000 | clean | prefer_index | 64MB | array_group | seq | 10 | 42.930 | 42.082–45.203 | 48.947 | 6.5% | 1.00 | Seq Scan | 0.057 | 42.987 |
| documents | 200000 | clean | prefer_index | 64MB | array_is_null | gin | 10 | 9.547 | 8.724–10.655 | 11.031 | 11.2% | 0.94 | Seq Scan (fallback) | 0.022 | 9.569 |
| documents | 200000 | clean | prefer_index | 64MB | array_is_null | gist | 10 | 9.540 | 9.175–10.032 | 12.208 | 12.7% | 0.94 | Seq Scan (fallback) | 0.023 | 9.564 |
| documents | 200000 | clean | prefer_index | 64MB | array_is_null | roaring | 10 | 1.101 | 1.081–1.185 | 1.297 | 8.4% | 8.13 | Bitmap Heap Scan, Bitmap Index Scan | 0.029 | 1.128 |
| documents | 200000 | clean | prefer_index | 64MB | array_is_null | roaring_bitmap | 10 | 1.083 | 1.055–1.121 | 1.153 | 3.7% | 8.26 | Bitmap Heap Scan, Bitmap Index Scan | 0.025 | 1.107 |
| documents | 200000 | clean | prefer_index | 64MB | array_is_null | seq | 10 | 8.947 | 8.894–9.434 | 9.795 | 4.3% | 1.00 | Seq Scan | 0.020 | 8.969 |
| documents | 200000 | clean | prefer_index | 64MB | array_null_element | gin | 10 | 0.043 | 0.042–0.045 | 0.045 | 3.1% | 709.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 0.098 |
| documents | 200000 | clean | prefer_index | 64MB | array_null_element | gist | 10 | 31.233 | 30.211–32.716 | 33.394 | 4.1% | 0.99 | Seq Scan (fallback) | 0.049 | 31.280 |
| documents | 200000 | clean | prefer_index | 64MB | array_null_element | roaring | 10 | 54.986 | 53.231–59.451 | 61.395 | 6.0% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 55.042 |
| documents | 200000 | clean | prefer_index | 64MB | array_null_element | roaring_bitmap | 10 | 56.081 | 55.481–58.647 | 62.222 | 4.9% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 56.131 |
| documents | 200000 | clean | prefer_index | 64MB | array_null_element | seq | 10 | 30.866 | 30.424–34.472 | 39.625 | 12.9% | 1.00 | Seq Scan | 0.045 | 30.917 |
| documents | 200000 | clean | prefer_index | 64MB | array_or | gin | 10 | 6.462 | 6.313–6.644 | 6.910 | 3.8% | 7.36 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 6.521 |
| documents | 200000 | clean | prefer_index | 64MB | array_or | gist | 10 | 46.111 | 45.793–49.613 | 51.852 | 5.3% | 1.03 | Seq Scan (fallback) | 0.052 | 46.162 |
| documents | 200000 | clean | prefer_index | 64MB | array_or | roaring | 10 | 0.229 | 0.220–0.249 | 0.266 | 8.4% | 207.64 | RoaringCount | 0.075 | 0.313 |
| documents | 200000 | clean | prefer_index | 64MB | array_or | roaring_bitmap | 10 | 5.053 | 5.008–5.497 | 6.976 | 16.7% | 9.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.055 | 5.108 |
| documents | 200000 | clean | prefer_index | 64MB | array_or | seq | 10 | 47.550 | 46.001–49.105 | 50.529 | 4.1% | 1.00 | Seq Scan | 0.048 | 47.599 |
| documents | 200000 | clean | prefer_index | 64MB | array_rare | gin | 10 | 0.075 | 0.073–0.079 | 0.083 | 5.6% | 406.87 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 0.129 |
| documents | 200000 | clean | prefer_index | 64MB | array_rare | gist | 10 | 31.397 | 30.455–32.705 | 34.180 | 4.7% | 0.97 | Seq Scan (fallback) | 0.052 | 31.448 |
| documents | 200000 | clean | prefer_index | 64MB | array_rare | roaring | 10 | 0.014 | 0.013–0.015 | 0.016 | 6.5% | 2179.68 | RoaringCount | 0.074 | 0.088 |
| documents | 200000 | clean | prefer_index | 64MB | array_rare | roaring_bitmap | 10 | 0.073 | 0.071–0.086 | 0.103 | 16.8% | 418.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 0.126 |
| documents | 200000 | clean | prefer_index | 64MB | array_rare | seq | 10 | 30.516 | 29.912–31.231 | 34.751 | 7.6% | 1.00 | Seq Scan | 0.047 | 30.574 |
| documents | 200000 | clean | prefer_index | 64MB | ts_and | gin | 10 | 0.972 | 0.956–1.025 | 1.078 | 5.3% | 23.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 1.018 |
| documents | 200000 | clean | prefer_index | 64MB | ts_and | gist | 10 | 9.104 | 8.989–9.466 | 9.676 | 3.2% | 2.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 9.148 |
| documents | 200000 | clean | prefer_index | 64MB | ts_and | roaring | 10 | 0.106 | 0.103–0.114 | 0.118 | 8.9% | 219.90 | RoaringCount | 0.066 | 0.175 |
| documents | 200000 | clean | prefer_index | 64MB | ts_and | roaring_bitmap | 10 | 0.179 | 0.172–0.190 | 0.205 | 8.8% | 130.22 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 0.223 |
| documents | 200000 | clean | prefer_index | 64MB | ts_and | seq | 10 | 23.309 | 22.462–23.935 | 25.783 | 6.4% | 1.00 | Seq Scan | 0.037 | 23.346 |
| documents | 200000 | clean | prefer_index | 64MB | ts_common | gin | 10 | 28.240 | 27.679–28.763 | 29.310 | 2.4% | 0.99 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 28.284 |
| documents | 200000 | clean | prefer_index | 64MB | ts_common | gist | 10 | 48.091 | 46.330–52.137 | 54.856 | 7.4% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 48.136 |
| documents | 200000 | clean | prefer_index | 64MB | ts_common | roaring | 10 | 0.030 | 0.028–0.036 | 0.047 | 23.2% | 927.68 | RoaringCount | 0.072 | 0.106 |
| documents | 200000 | clean | prefer_index | 64MB | ts_common | roaring_bitmap | 10 | 18.613 | 18.142–19.183 | 19.748 | 3.6% | 1.50 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 18.653 |
| documents | 200000 | clean | prefer_index | 64MB | ts_common | seq | 10 | 27.831 | 27.251–28.151 | 32.173 | 7.5% | 1.00 | Seq Scan | 0.038 | 27.870 |
| documents | 200000 | clean | prefer_index | 64MB | ts_fetch | gin | 10 | 4.120 | 4.021–4.204 | 4.317 | 3.0% | 5.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 4.170 |
| documents | 200000 | clean | prefer_index | 64MB | ts_fetch | gist | 10 | 13.062 | 12.780–13.611 | 14.099 | 4.2% | 1.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 13.109 |
| documents | 200000 | clean | prefer_index | 64MB | ts_fetch | roaring | 10 | 3.806 | 3.706–3.918 | 4.191 | 5.5% | 5.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 3.856 |
| documents | 200000 | clean | prefer_index | 64MB | ts_fetch | roaring_bitmap | 10 | 3.638 | 3.553–3.681 | 3.705 | 1.9% | 6.19 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 3.686 |
| documents | 200000 | clean | prefer_index | 64MB | ts_fetch | seq | 10 | 22.534 | 22.106–23.274 | 26.923 | 10.1% | 1.00 | Seq Scan | 0.041 | 22.574 |
| documents | 200000 | clean | prefer_index | 64MB | ts_group | gin | 10 | 0.959 | 0.939–0.976 | 0.989 | 2.4% | 24.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 1.011 |
| documents | 200000 | clean | prefer_index | 64MB | ts_group | gist | 10 | 9.325 | 9.056–9.509 | 10.001 | 4.0% | 2.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 9.398 |
| documents | 200000 | clean | prefer_index | 64MB | ts_group | roaring | 10 | 1.636 | 1.610–1.737 | 1.750 | 3.7% | 14.53 | RoaringCount | 0.075 | 1.716 |
| documents | 200000 | clean | prefer_index | 64MB | ts_group | roaring_bitmap | 10 | 0.193 | 0.190–0.198 | 0.200 | 2.6% | 123.20 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 0.248 |
| documents | 200000 | clean | prefer_index | 64MB | ts_group | seq | 10 | 23.777 | 23.250–25.163 | 26.725 | 5.8% | 1.00 | Seq Scan | 0.050 | 23.827 |
| documents | 200000 | clean | prefer_index | 64MB | ts_not | gin | 10 | 32.642 | 32.436–34.157 | 36.512 | 5.8% | 1.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 32.687 |
| documents | 200000 | clean | prefer_index | 64MB | ts_not | gist | 10 | 62.427 | 58.241–65.812 | 69.409 | 7.2% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 62.471 |
| documents | 200000 | clean | prefer_index | 64MB | ts_not | roaring | 10 | 70.934 | 69.230–74.393 | 76.228 | 4.3% | 0.49 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 70.987 |
| documents | 200000 | clean | prefer_index | 64MB | ts_not | roaring_bitmap | 10 | 71.972 | 70.349–72.552 | 73.264 | 1.7% | 0.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 72.013 |
| documents | 200000 | clean | prefer_index | 64MB | ts_not | seq | 10 | 34.903 | 33.574–37.480 | 40.526 | 7.6% | 1.00 | Seq Scan | 0.038 | 34.942 |
| documents | 200000 | clean | prefer_index | 64MB | ts_or | gin | 10 | 6.938 | 6.664–7.138 | 7.351 | 4.0% | 5.13 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 6.994 |
| documents | 200000 | clean | prefer_index | 64MB | ts_or | gist | 10 | 22.677 | 21.784–23.310 | 23.770 | 3.8% | 1.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 22.727 |
| documents | 200000 | clean | prefer_index | 64MB | ts_or | roaring | 10 | 0.225 | 0.222–0.236 | 0.248 | 4.8% | 158.15 | RoaringCount | 0.067 | 0.297 |
| documents | 200000 | clean | prefer_index | 64MB | ts_or | roaring_bitmap | 10 | 5.252 | 5.081–5.450 | 6.985 | 17.2% | 6.77 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 5.298 |
| documents | 200000 | clean | prefer_index | 64MB | ts_or | seq | 10 | 35.584 | 35.078–40.863 | 42.229 | 8.3% | 1.00 | Seq Scan | 0.038 | 35.621 |
| documents | 200000 | clean | prefer_index | 64MB | ts_phrase | gin | 10 | 6.737 | 6.572–6.830 | 7.106 | 3.5% | 4.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 6.789 |
| documents | 200000 | clean | prefer_index | 64MB | ts_phrase | gist | 10 | 16.675 | 16.334–16.977 | 21.004 | 14.0% | 1.88 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 16.721 |
| documents | 200000 | clean | prefer_index | 64MB | ts_phrase | roaring | 10 | 69.507 | 66.993–70.834 | 72.939 | 4.0% | 0.45 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 69.552 |
| documents | 200000 | clean | prefer_index | 64MB | ts_phrase | roaring_bitmap | 10 | 67.998 | 65.229–70.812 | 74.453 | 5.5% | 0.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 68.042 |
| documents | 200000 | clean | prefer_index | 64MB | ts_phrase | seq | 10 | 31.301 | 30.030–31.794 | 32.186 | 2.8% | 1.00 | Seq Scan | 0.039 | 31.340 |
| documents | 200000 | clean | prefer_index | 64MB | ts_prefix | gin | 10 | 1.586 | 1.562–1.619 | 1.655 | 3.2% | 14.77 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 1.634 |
| documents | 200000 | clean | prefer_index | 64MB | ts_prefix | gist | 10 | 41.799 | 41.438–45.215 | 49.577 | 8.1% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 41.846 |
| documents | 200000 | clean | prefer_index | 64MB | ts_prefix | roaring | 10 | 60.975 | 57.526–62.359 | 67.026 | 6.5% | 0.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 61.020 |
| documents | 200000 | clean | prefer_index | 64MB | ts_prefix | roaring_bitmap | 10 | 61.410 | 57.287–64.561 | 66.624 | 6.6% | 0.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 61.454 |
| documents | 200000 | clean | prefer_index | 64MB | ts_prefix | seq | 10 | 23.416 | 22.758–25.415 | 28.709 | 10.0% | 1.00 | Seq Scan | 0.039 | 23.456 |
| documents | 200000 | clean | prefer_index | 64MB | ts_rare | gin | 10 | 0.034 | 0.034–0.037 | 0.040 | 6.7% | 631.18 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 0.080 |
| documents | 200000 | clean | prefer_index | 64MB | ts_rare | gist | 10 | 1.729 | 1.694–1.801 | 1.912 | 5.3% | 12.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 1.774 |
| documents | 200000 | clean | prefer_index | 64MB | ts_rare | roaring | 10 | 0.012 | 0.012–0.013 | 0.015 | 9.3% | 1788.33 | RoaringCount | 0.064 | 0.076 |
| documents | 200000 | clean | prefer_index | 64MB | ts_rare | roaring_bitmap | 10 | 0.036 | 0.035–0.038 | 0.048 | 16.8% | 596.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.080 |
| documents | 200000 | clean | prefer_index | 64MB | ts_rare | seq | 10 | 21.460 | 21.012–22.542 | 24.569 | 6.7% | 1.00 | Seq Scan | 0.038 | 21.505 |
| documents | 200000 | clean | prefer_index | 64MB | ts_tree | gin | 10 | 3.383 | 3.363–3.464 | 3.478 | 1.6% | 9.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 3.429 |
| documents | 200000 | clean | prefer_index | 64MB | ts_tree | gist | 10 | 13.067 | 12.923–13.418 | 14.935 | 7.4% | 2.37 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 13.117 |
| documents | 200000 | clean | prefer_index | 64MB | ts_tree | roaring | 10 | 0.448 | 0.438–0.461 | 0.498 | 6.2% | 69.24 | RoaringCount | 0.067 | 0.516 |
| documents | 200000 | clean | prefer_index | 64MB | ts_tree | roaring_bitmap | 10 | 0.697 | 0.676–0.727 | 0.746 | 4.3% | 44.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 0.750 |
| documents | 200000 | clean | prefer_index | 64MB | ts_tree | seq | 10 | 30.986 | 30.212–33.843 | 34.941 | 6.5% | 1.00 | Seq Scan | 0.040 | 31.024 |
| documents | 200000 | clean | prefer_index | 64MB | ts_weight | gin | 10 | 4.793 | 4.752–4.874 | 5.960 | 12.8% | 4.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 4.839 |
| documents | 200000 | clean | prefer_index | 64MB | ts_weight | gist | 10 | 13.105 | 12.594–13.530 | 15.864 | 11.3% | 1.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 13.149 |
| documents | 200000 | clean | prefer_index | 64MB | ts_weight | roaring | 10 | 60.191 | 57.235–63.502 | 65.055 | 5.3% | 0.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 60.239 |
| documents | 200000 | clean | prefer_index | 64MB | ts_weight | roaring_bitmap | 10 | 59.361 | 58.895–63.118 | 70.852 | 8.6% | 0.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 59.404 |
| documents | 200000 | clean | prefer_index | 64MB | ts_weight | seq | 10 | 22.614 | 22.193–23.082 | 23.953 | 3.4% | 1.00 | Seq Scan | 0.038 | 22.652 |
| scalar | 1000000 | after_maintenance | default | 64MB | and2 | brin | 10 | 48.892 | 47.105–49.572 | 50.678 | 3.2% | 0.99 | Seq Scan (fallback) | 0.057 | 48.947 |
| scalar | 1000000 | after_maintenance | default | 64MB | and2 | btree | 10 | 3.468 | 3.103–3.681 | 3.978 | 13.4% | 14.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 3.522 |
| scalar | 1000000 | after_maintenance | default | 64MB | and2 | btree_tuned | 10 | 0.190 | 0.188–0.202 | 0.283 | 22.8% | 256.01 | Index Only Scan | 0.048 | 0.239 |
| scalar | 1000000 | after_maintenance | default | 64MB | and2 | gin | 10 | 33.107 | 32.479–34.191 | 37.945 | 7.0% | 1.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 33.182 |
| scalar | 1000000 | after_maintenance | default | 64MB | and2 | gist | 10 | 3.577 | 3.177–3.726 | 3.747 | 10.8% | 13.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.623 |
| scalar | 1000000 | after_maintenance | default | 64MB | and2 | hash (partial) | 10 | 3.146 | 2.773–3.414 | 3.547 | 11.1% | 15.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.199 |
| scalar | 1000000 | after_maintenance | default | 64MB | and2 | roaring | 10 | 0.337 | 0.322–0.350 | 0.359 | 4.5% | 144.34 | RoaringCount | 0.045 | 0.381 |
| scalar | 1000000 | after_maintenance | default | 64MB | and2 | roaring_bitmap | 10 | 6.873 | 6.529–7.203 | 7.430 | 5.9% | 7.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 6.945 |
| scalar | 1000000 | after_maintenance | default | 64MB | and2 | seq | 10 | 48.642 | 46.870–50.094 | 52.043 | 4.4% | 1.00 | Seq Scan | 0.036 | 48.676 |
| scalar | 1000000 | after_maintenance | default | 64MB | eq_c200_17 | brin | 10 | 51.188 | 48.273–53.542 | 56.119 | 6.7% | 1.00 | Seq Scan (fallback) | 0.058 | 51.245 |
| scalar | 1000000 | after_maintenance | default | 64MB | eq_c200_17 | btree | 10 | 0.351 | 0.323–0.372 | 0.383 | 7.4% | 145.47 | Index Only Scan | 0.037 | 0.396 |
| scalar | 1000000 | after_maintenance | default | 64MB | eq_c200_17 | btree_tuned | 10 | 0.366 | 0.353–0.402 | 0.471 | 12.9% | 139.52 | Index Only Scan | 0.042 | 0.406 |
| scalar | 1000000 | after_maintenance | default | 64MB | eq_c200_17 | gin | 10 | 3.298 | 3.183–3.396 | 3.494 | 4.5% | 15.50 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 3.346 |
| scalar | 1000000 | after_maintenance | default | 64MB | eq_c200_17 | gist | 10 | 0.745 | 0.726–0.791 | 0.809 | 4.8% | 68.63 | Index Only Scan | 0.036 | 0.782 |
| scalar | 1000000 | after_maintenance | default | 64MB | eq_c200_17 | hash (partial) | 10 | 3.320 | 2.913–3.615 | 3.915 | 13.0% | 15.40 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 3.372 |
| scalar | 1000000 | after_maintenance | default | 64MB | eq_c200_17 | roaring | 10 | 0.029 | 0.028–0.031 | 0.036 | 13.0% | 1763.21 | RoaringCount | 0.038 | 0.067 |
| scalar | 1000000 | after_maintenance | default | 64MB | eq_c200_17 | roaring_bitmap | 10 | 2.870 | 2.751–3.097 | 3.500 | 10.2% | 17.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 2.909 |
| scalar | 1000000 | after_maintenance | default | 64MB | eq_c200_17 | seq | 10 | 51.133 | 48.356–55.702 | 57.548 | 8.2% | 1.00 | Seq Scan | 0.030 | 51.165 |
| scalar | 1000000 | after_maintenance | default | 64MB | group_c200 | brin | 10 | 159.237 | 153.659–164.812 | 167.197 | 4.2% | 1.00 | Seq Scan (fallback) | 0.045 | 159.288 |
| scalar | 1000000 | after_maintenance | default | 64MB | group_c200 | btree | 10 | 83.727 | 82.127–87.155 | 98.008 | 9.1% | 1.89 | Index Only Scan | 0.040 | 83.769 |
| scalar | 1000000 | after_maintenance | default | 64MB | group_c200 | btree_tuned | 10 | 84.692 | 83.155–86.767 | 90.200 | 3.8% | 1.87 | Index Only Scan | 0.044 | 84.736 |
| scalar | 1000000 | after_maintenance | default | 64MB | group_c200 | gin | 10 | 157.465 | 156.115–159.810 | 165.142 | 2.6% | 1.01 | Seq Scan (fallback) | 0.039 | 157.510 |
| scalar | 1000000 | after_maintenance | default | 64MB | group_c200 | gist | 10 | 197.238 | 195.729–200.756 | 205.272 | 2.0% | 0.80 | Index Only Scan | 0.035 | 197.273 |
| scalar | 1000000 | after_maintenance | default | 64MB | group_c200 | hash (partial) | 10 | 156.319 | 154.899–157.804 | 162.420 | 2.3% | 1.01 | Seq Scan (fallback) | 0.037 | 156.358 |
| scalar | 1000000 | after_maintenance | default | 64MB | group_c200 | roaring | 10 | 4.104 | 4.012–4.567 | 5.435 | 13.7% | 38.62 | RoaringCount | 0.034 | 4.138 |
| scalar | 1000000 | after_maintenance | default | 64MB | group_c200 | roaring_bitmap | 10 | 158.396 | 155.798–163.096 | 165.335 | 2.7% | 1.00 | Seq Scan (fallback) | 0.035 | 158.430 |
| scalar | 1000000 | after_maintenance | default | 64MB | group_c200 | seq | 10 | 158.485 | 154.889–163.601 | 164.800 | 3.0% | 1.00 | Seq Scan | 0.030 | 158.516 |
| scalar | 1000000 | after_maintenance | default | 64MB | is_null | brin | 10 | 62.211 | 58.711–62.809 | 64.202 | 4.1% | 0.96 | Seq Scan (fallback) | 0.049 | 62.255 |
| scalar | 1000000 | after_maintenance | default | 64MB | is_null | btree | 10 | 6.851 | 6.681–7.039 | 7.239 | 3.3% | 8.75 | Index Only Scan | 0.032 | 6.882 |
| scalar | 1000000 | after_maintenance | default | 64MB | is_null | btree_tuned | 10 | 6.707 | 6.503–7.126 | 7.418 | 5.4% | 8.94 | Index Only Scan | 0.036 | 6.751 |
| scalar | 1000000 | after_maintenance | default | 64MB | is_null | gin | 10 | 59.737 | 59.147–61.873 | 64.206 | 3.4% | 1.00 | Seq Scan (fallback) | 0.038 | 59.790 |
| scalar | 1000000 | after_maintenance | default | 64MB | is_null | gist | 10 | 16.721 | 16.684–17.465 | 19.151 | 6.6% | 3.59 | Index Only Scan | 0.030 | 16.749 |
| scalar | 1000000 | after_maintenance | default | 64MB | is_null | hash (partial) | 10 | 59.759 | 57.459–63.902 | 68.237 | 7.3% | 1.00 | Seq Scan (fallback) | 0.035 | 59.800 |
| scalar | 1000000 | after_maintenance | default | 64MB | is_null | roaring | 10 | 0.100 | 0.096–0.108 | 0.134 | 16.1% | 602.80 | RoaringCount | 0.033 | 0.133 |
| scalar | 1000000 | after_maintenance | default | 64MB | is_null | roaring_bitmap | 10 | 25.894 | 24.718–27.544 | 28.637 | 8.4% | 2.32 | Bitmap Heap Scan, Bitmap Index Scan | 0.031 | 25.924 |
| scalar | 1000000 | after_maintenance | default | 64MB | is_null | seq | 10 | 59.979 | 55.942–62.257 | 65.459 | 6.6% | 1.00 | Seq Scan | 0.024 | 60.007 |
| scalar | 1000000 | clean | default | 64MB | and2 | brin | 10 | 74.036 | 69.988–78.271 | 82.395 | 6.7% | 0.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 74.102 |
| scalar | 1000000 | clean | default | 64MB | and2 | btree | 10 | 3.235 | 2.801–3.949 | 4.348 | 19.0% | 15.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.278 |
| scalar | 1000000 | clean | default | 64MB | and2 | btree_tuned | 10 | 0.194 | 0.191–0.204 | 0.224 | 6.9% | 252.63 | Index Only Scan | 0.049 | 0.244 |
| scalar | 1000000 | clean | default | 64MB | and2 | gin | 10 | 34.367 | 33.276–36.183 | 38.184 | 5.7% | 1.43 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 34.423 |
| scalar | 1000000 | clean | default | 64MB | and2 | gist | 10 | 3.944 | 3.528–4.248 | 4.369 | 10.1% | 12.43 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.987 |
| scalar | 1000000 | clean | default | 64MB | and2 | hash (partial) | 10 | 3.184 | 2.853–3.694 | 3.871 | 13.1% | 15.39 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.231 |
| scalar | 1000000 | clean | default | 64MB | and2 | roaring | 10 | 0.345 | 0.341–0.361 | 0.372 | 3.8% | 142.06 | RoaringCount | 0.045 | 0.393 |
| scalar | 1000000 | clean | default | 64MB | and2 | roaring_bitmap | 10 | 2.896 | 2.748–3.188 | 3.265 | 8.6% | 16.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 2.952 |
| scalar | 1000000 | clean | default | 64MB | and2 | seq | 10 | 49.011 | 47.076–49.438 | 51.644 | 4.2% | 1.00 | Seq Scan | 0.042 | 49.053 |
| scalar | 1000000 | clean | default | 64MB | and3 | brin | 10 | 71.752 | 71.154–73.894 | 81.027 | 6.3% | 0.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 71.816 |
| scalar | 1000000 | clean | default | 64MB | and3 | btree | 10 | 2.755 | 2.654–2.878 | 2.994 | 5.5% | 17.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 2.804 |
| scalar | 1000000 | clean | default | 64MB | and3 | btree_tuned | 10 | 0.029 | 0.028–0.043 | 0.059 | 37.3% | 1647.22 | Index Only Scan | 0.052 | 0.082 |
| scalar | 1000000 | clean | default | 64MB | and3 | gin | 10 | 5.205 | 5.110–5.284 | 5.366 | 2.1% | 9.18 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 5.284 |
| scalar | 1000000 | clean | default | 64MB | and3 | gist | 10 | 3.880 | 3.818–4.146 | 4.447 | 6.5% | 12.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 3.941 |
| scalar | 1000000 | clean | default | 64MB | and3 | hash (partial) | 10 | 3.098 | 3.017–3.241 | 3.495 | 6.6% | 15.42 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 3.154 |
| scalar | 1000000 | clean | default | 64MB | and3 | roaring | 10 | 0.261 | 0.258–0.265 | 0.284 | 5.0% | 183.02 | RoaringCount | 0.052 | 0.311 |
| scalar | 1000000 | clean | default | 64MB | and3 | roaring_bitmap | 10 | 3.663 | 3.577–3.773 | 3.970 | 5.4% | 13.04 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 3.720 |
| scalar | 1000000 | clean | default | 64MB | and3 | seq | 10 | 47.770 | 45.946–51.861 | 53.829 | 7.0% | 1.00 | Seq Scan | 0.042 | 47.805 |
| scalar | 1000000 | clean | default | 64MB | count_distinct | brin | 10 | 73.152 | 68.898–77.292 | 82.294 | 7.2% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 73.215 |
| scalar | 1000000 | clean | default | 64MB | count_distinct | btree | 10 | 3.976 | 3.517–4.578 | 5.146 | 17.6% | 12.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 4.021 |
| scalar | 1000000 | clean | default | 64MB | count_distinct | btree_tuned | 10 | 4.557 | 3.269–4.994 | 5.090 | 19.1% | 11.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 4.614 |
| scalar | 1000000 | clean | default | 64MB | count_distinct | gin | 10 | 4.249 | 3.856–5.383 | 6.146 | 20.4% | 11.95 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 4.309 |
| scalar | 1000000 | clean | default | 64MB | count_distinct | gist | 10 | 4.688 | 3.855–5.010 | 5.448 | 17.2% | 10.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 4.731 |
| scalar | 1000000 | clean | default | 64MB | count_distinct | hash (partial) | 10 | 3.777 | 3.445–4.230 | 5.112 | 17.9% | 13.45 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.822 |
| scalar | 1000000 | clean | default | 64MB | count_distinct | roaring | 10 | 4.038 | 3.547–4.433 | 4.596 | 11.4% | 12.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 4.082 |
| scalar | 1000000 | clean | default | 64MB | count_distinct | roaring_bitmap | 10 | 3.619 | 3.313–3.791 | 4.207 | 11.8% | 14.04 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.683 |
| scalar | 1000000 | clean | default | 64MB | count_distinct | seq | 10 | 50.796 | 49.656–52.582 | 54.375 | 4.7% | 1.00 | Seq Scan | 0.042 | 50.839 |
| scalar | 1000000 | clean | default | 64MB | eq_absent | brin | 10 | 0.081 | 0.078–0.087 | 0.096 | 8.9% | 593.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 0.128 |
| scalar | 1000000 | clean | default | 64MB | eq_absent | btree | 10 | 0.016 | 0.016–0.017 | 0.018 | 5.1% | 2987.75 | Index Only Scan | 0.035 | 0.052 |
| scalar | 1000000 | clean | default | 64MB | eq_absent | btree_tuned | 10 | 0.017 | 0.016–0.018 | 0.023 | 18.7% | 2812.00 | Index Only Scan | 0.041 | 0.058 |
| scalar | 1000000 | clean | default | 64MB | eq_absent | gin | 10 | 0.018 | 0.017–0.019 | 0.023 | 13.5% | 2655.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 0.057 |
| scalar | 1000000 | clean | default | 64MB | eq_absent | gist | 10 | 0.016 | 0.015–0.017 | 0.018 | 8.0% | 2987.75 | Index Only Scan | 0.036 | 0.052 |
| scalar | 1000000 | clean | default | 64MB | eq_absent | hash (partial) | 10 | 0.017 | 0.015–0.021 | 0.023 | 16.9% | 2897.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 0.050 |
| scalar | 1000000 | clean | default | 64MB | eq_absent | roaring | 10 | 0.008 | 0.007–0.008 | 0.009 | 11.8% | 5975.50 | RoaringCount | 0.039 | 0.046 |
| scalar | 1000000 | clean | default | 64MB | eq_absent | roaring_bitmap | 10 | 0.017 | 0.016–0.018 | 0.020 | 9.2% | 2897.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 0.054 |
| scalar | 1000000 | clean | default | 64MB | eq_absent | seq | 10 | 47.804 | 46.355–49.726 | 50.474 | 4.0% | 1.00 | Seq Scan | 0.034 | 47.843 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_12345 | brin | 10 | 50.320 | 48.821–53.248 | 57.050 | 7.0% | 1.03 | Seq Scan (fallback) | 0.046 | 50.364 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_12345 | btree | 10 | 0.019 | 0.018–0.022 | 0.022 | 8.8% | 2664.49 | Index Only Scan | 0.036 | 0.056 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_12345 | btree_tuned | 10 | 0.020 | 0.019–0.021 | 0.022 | 5.3% | 2597.88 | Index Only Scan | 0.037 | 0.057 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_12345 | gin | 10 | 0.027 | 0.026–0.029 | 0.033 | 11.2% | 1924.35 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 0.066 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_12345 | gist | 10 | 0.039 | 0.038–0.049 | 0.063 | 24.0% | 1332.24 | Index Only Scan | 0.035 | 0.075 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_12345 | hash (partial) | 10 | 0.023 | 0.020–0.025 | 0.032 | 21.1% | 2259.02 | Index Scan | 0.036 | 0.059 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_12345 | roaring | 10 | 0.011 | 0.010–0.012 | 0.012 | 6.6% | 4723.41 | RoaringCount | 0.036 | 0.048 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_12345 | roaring_bitmap | 10 | 0.023 | 0.021–0.026 | 0.030 | 14.6% | 2259.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 0.057 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_12345 | seq | 10 | 51.958 | 50.528–55.657 | 58.142 | 6.0% | 1.00 | Seq Scan | 0.033 | 51.993 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_765432 | brin | 10 | 50.399 | 48.779–54.769 | 55.778 | 6.1% | 1.03 | Seq Scan (fallback) | 0.054 | 50.457 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_765432 | btree | 10 | 0.018 | 0.018–0.019 | 0.020 | 5.3% | 2809.70 | Index Only Scan | 0.036 | 0.055 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_765432 | btree_tuned | 10 | 0.018 | 0.017–0.019 | 0.020 | 8.5% | 2809.70 | Index Only Scan | 0.039 | 0.057 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_765432 | gin | 10 | 0.021 | 0.020–0.025 | 0.031 | 19.1% | 2475.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 0.059 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_765432 | gist | 10 | 0.032 | 0.029–0.033 | 0.043 | 20.1% | 1650.14 | Index Only Scan | 0.034 | 0.065 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_765432 | hash (partial) | 10 | 0.019 | 0.017–0.021 | 0.021 | 9.6% | 2735.76 | Index Scan | 0.035 | 0.054 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_765432 | roaring | 10 | 0.008 | 0.008–0.009 | 0.010 | 11.5% | 6497.44 | RoaringCount | 0.037 | 0.045 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_765432 | roaring_bitmap | 10 | 0.018 | 0.017–0.022 | 0.024 | 15.7% | 2887.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 0.053 |
| scalar | 1000000 | clean | default | 64MB | eq_c1m_765432 | seq | 10 | 51.980 | 50.062–52.687 | 58.345 | 6.9% | 1.00 | Seq Scan | 0.029 | 52.011 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_103 | brin | 10 | 72.784 | 70.007–74.762 | 80.279 | 5.8% | 0.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 72.844 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_103 | btree | 10 | 0.322 | 0.311–0.337 | 0.371 | 8.1% | 153.55 | Index Only Scan | 0.036 | 0.360 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_103 | btree_tuned | 10 | 0.320 | 0.311–0.331 | 0.336 | 3.3% | 154.27 | Index Only Scan | 0.040 | 0.366 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_103 | gin | 10 | 3.856 | 3.498–4.317 | 4.521 | 12.9% | 12.80 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 3.917 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_103 | gist | 10 | 0.713 | 0.701–0.744 | 0.810 | 6.2% | 69.24 | Index Only Scan | 0.036 | 0.747 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_103 | hash (partial) | 10 | 3.579 | 3.343–3.847 | 4.004 | 7.6% | 13.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 3.615 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_103 | roaring | 10 | 0.029 | 0.028–0.035 | 0.043 | 19.1% | 1702.24 | RoaringCount | 0.046 | 0.077 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_103 | roaring_bitmap | 10 | 3.365 | 3.132–3.754 | 3.759 | 10.2% | 14.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 3.404 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_103 | seq | 10 | 49.365 | 47.816–52.572 | 54.523 | 5.4% | 1.00 | Seq Scan | 0.033 | 49.394 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_17 | brin | 10 | 75.964 | 73.551–79.056 | 82.635 | 6.0% | 0.63 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 76.043 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_17 | btree | 10 | 0.332 | 0.320–0.360 | 0.384 | 7.8% | 144.96 | Index Only Scan | 0.037 | 0.380 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_17 | btree_tuned | 10 | 0.330 | 0.327–0.348 | 0.379 | 6.6% | 145.62 | Index Only Scan | 0.041 | 0.376 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_17 | gin | 10 | 3.147 | 2.906–3.985 | 4.035 | 15.8% | 15.27 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 3.181 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_17 | gist | 10 | 0.749 | 0.726–0.777 | 0.790 | 3.7% | 64.16 | Index Only Scan | 0.039 | 0.792 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_17 | hash (partial) | 10 | 3.450 | 3.174–3.646 | 3.767 | 9.5% | 13.93 | Bitmap Heap Scan, Bitmap Index Scan | 0.033 | 3.496 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_17 | roaring | 10 | 0.028 | 0.027–0.029 | 0.031 | 5.2% | 1716.27 | RoaringCount | 0.038 | 0.067 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_17 | roaring_bitmap | 10 | 3.112 | 2.631–3.248 | 3.542 | 12.4% | 15.44 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 3.149 |
| scalar | 1000000 | clean | default | 64MB | eq_c200_17 | seq | 10 | 48.056 | 46.572–52.630 | 57.218 | 9.0% | 1.00 | Seq Scan | 0.035 | 48.094 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_17 | brin | 10 | 74.599 | 72.401–77.840 | 80.623 | 4.9% | 0.63 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 74.640 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_17 | btree | 10 | 3.111 | 3.058–3.266 | 3.669 | 8.1% | 15.14 | Index Only Scan | 0.036 | 3.147 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_17 | btree_tuned | 10 | 3.039 | 3.011–3.165 | 3.322 | 4.4% | 15.50 | Index Only Scan | 0.041 | 3.080 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_17 | gin | 10 | 19.895 | 19.811–20.484 | 21.366 | 3.2% | 2.37 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 19.947 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_17 | gist | 10 | 7.050 | 6.797–7.496 | 7.958 | 6.7% | 6.68 | Index Only Scan | 0.050 | 7.101 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_17 | hash (partial) | 10 | 19.766 | 18.930–21.502 | 22.531 | 8.0% | 2.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 19.799 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_17 | roaring | 10 | 0.062 | 0.061–0.064 | 0.065 | 2.0% | 753.86 | RoaringCount | 0.038 | 0.100 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_17 | roaring_bitmap | 10 | 18.540 | 17.942–19.970 | 21.072 | 7.1% | 2.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 18.575 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_17 | seq | 10 | 47.117 | 46.828–49.452 | 53.627 | 6.2% | 1.00 | Seq Scan | 0.035 | 47.154 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_3 | brin | 10 | 75.297 | 71.947–76.395 | 80.462 | 5.1% | 0.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 75.345 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_3 | btree | 10 | 3.146 | 3.051–3.429 | 3.653 | 7.4% | 15.92 | Index Only Scan | 0.036 | 3.178 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_3 | btree_tuned | 10 | 3.063 | 3.017–3.171 | 3.322 | 3.9% | 16.35 | Index Only Scan | 0.041 | 3.104 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_3 | gin | 10 | 19.474 | 18.980–20.786 | 22.619 | 7.7% | 2.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 19.512 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_3 | gist | 10 | 7.079 | 6.810–7.371 | 7.995 | 6.8% | 7.08 | Index Only Scan | 0.047 | 7.131 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_3 | hash (partial) | 10 | 19.862 | 19.548–20.448 | 21.155 | 6.1% | 2.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 19.892 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_3 | roaring | 10 | 0.062 | 0.061–0.063 | 0.064 | 2.1% | 808.02 | RoaringCount | 0.038 | 0.100 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_3 | roaring_bitmap | 10 | 18.463 | 18.067–19.459 | 20.720 | 6.1% | 2.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 18.508 |
| scalar | 1000000 | clean | default | 64MB | eq_c20_3 | seq | 10 | 50.097 | 49.599–51.236 | 52.704 | 4.1% | 1.00 | Seq Scan | 0.032 | 50.129 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_123 | brin | 10 | 72.263 | 70.597–78.696 | 80.479 | 6.2% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 72.322 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_123 | btree | 10 | 0.021 | 0.020–0.022 | 0.022 | 5.0% | 2373.17 | Index Only Scan | 0.036 | 0.057 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_123 | btree_tuned | 10 | 0.022 | 0.020–0.030 | 0.046 | 42.0% | 2265.30 | Index Only Scan | 0.038 | 0.061 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_123 | gin | 10 | 0.056 | 0.052–0.063 | 0.067 | 11.7% | 889.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 0.094 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_123 | gist | 10 | 0.045 | 0.043–0.052 | 0.064 | 18.4% | 1095.31 | Index Only Scan | 0.051 | 0.097 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_123 | hash (partial) | 10 | 0.054 | 0.051–0.063 | 0.065 | 12.1% | 922.90 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 0.086 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_123 | roaring | 10 | 0.013 | 0.012–0.013 | 0.022 | 39.9% | 3986.92 | RoaringCount | 0.039 | 0.052 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_123 | roaring_bitmap | 10 | 0.054 | 0.052–0.058 | 0.062 | 8.7% | 914.43 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 0.092 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_123 | seq | 10 | 49.837 | 47.962–51.984 | 54.182 | 5.1% | 1.00 | Seq Scan | 0.038 | 49.888 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_12345 | brin | 10 | 72.263 | 70.584–76.047 | 81.905 | 7.0% | 0.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 72.324 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_12345 | btree | 10 | 0.022 | 0.021–0.023 | 0.023 | 4.7% | 2316.27 | Index Only Scan | 0.036 | 0.057 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_12345 | btree_tuned | 10 | 0.023 | 0.021–0.025 | 0.026 | 8.3% | 2215.57 | Index Only Scan | 0.038 | 0.061 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_12345 | gin | 10 | 0.066 | 0.059–0.079 | 0.090 | 18.8% | 772.09 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 0.116 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_12345 | gist | 10 | 0.043 | 0.042–0.048 | 0.050 | 7.5% | 1171.45 | Index Only Scan | 0.036 | 0.079 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_12345 | hash (partial) | 10 | 0.054 | 0.051–0.062 | 0.067 | 12.0% | 943.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 0.086 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_12345 | roaring | 10 | 0.013 | 0.012–0.013 | 0.014 | 7.5% | 4076.64 | RoaringCount | 0.039 | 0.052 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_12345 | roaring_bitmap | 10 | 0.058 | 0.052–0.065 | 0.074 | 16.0% | 871.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 0.100 |
| scalar | 1000000 | clean | default | 64MB | eq_c20k_12345 | seq | 10 | 50.958 | 48.723–53.398 | 58.215 | 7.3% | 1.00 | Seq Scan | 0.029 | 50.992 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_0 | brin | 10 | 67.819 | 64.669–70.277 | 71.127 | 4.5% | 1.01 | Seq Scan (fallback) | 0.051 | 67.880 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_0 | btree | 10 | 33.862 | 31.456–36.523 | 40.096 | 10.6% | 2.03 | Index Only Scan | 0.035 | 33.914 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_0 | btree_tuned | 10 | 30.785 | 30.141–34.334 | 38.481 | 10.3% | 2.23 | Index Only Scan | 0.040 | 30.822 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_0 | gin | 10 | 93.802 | 90.484–96.223 | 98.413 | 4.0% | 0.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 93.839 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_0 | gist | 10 | 72.101 | 70.320–74.166 | 76.095 | 3.6% | 0.95 | Index Only Scan | 0.036 | 72.137 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_0 | hash (partial) | 10 | 69.787 | 65.716–70.367 | 73.173 | 4.8% | 0.98 | Seq Scan (fallback) | 0.032 | 69.815 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_0 | roaring | 10 | 0.411 | 0.402–0.437 | 0.461 | 6.3% | 166.74 | RoaringCount | 0.039 | 0.466 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_0 | roaring_bitmap | 10 | 66.156 | 64.768–66.927 | 68.374 | 2.5% | 1.04 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 66.197 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_0 | seq | 10 | 68.613 | 67.023–71.033 | 72.804 | 4.0% | 1.00 | Seq Scan | 0.036 | 68.653 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_1 | brin | 10 | 65.692 | 62.714–68.344 | 72.882 | 6.2% | 1.00 | Seq Scan (fallback) | 0.049 | 65.771 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_1 | btree | 10 | 32.069 | 31.466–33.495 | 35.196 | 5.0% | 2.05 | Index Only Scan | 0.037 | 32.102 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_1 | btree_tuned | 10 | 31.309 | 30.311–32.327 | 32.968 | 3.5% | 2.10 | Index Only Scan | 0.040 | 31.347 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_1 | gin | 10 | 94.200 | 90.091–96.331 | 99.027 | 4.1% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 94.240 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_1 | gist | 10 | 77.157 | 71.623–78.827 | 80.601 | 5.1% | 0.85 | Index Only Scan | 0.036 | 77.198 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_1 | hash (partial) | 10 | 65.977 | 64.608–69.989 | 72.922 | 5.1% | 1.00 | Seq Scan (fallback) | 0.038 | 66.020 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_1 | roaring | 10 | 0.413 | 0.401–0.451 | 0.501 | 9.5% | 159.03 | RoaringCount | 0.037 | 0.454 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_1 | roaring_bitmap | 10 | 65.947 | 64.512–68.260 | 69.370 | 3.3% | 1.00 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 65.989 |
| scalar | 1000000 | clean | default | 64MB | eq_c2_1 | seq | 10 | 65.678 | 63.813–69.648 | 71.215 | 4.7% | 1.00 | Seq Scan | 0.032 | 65.715 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_103 | brin | 10 | 0.740 | 0.730–0.748 | 0.814 | 5.6% | 70.24 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 0.788 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_103 | btree | 10 | 0.322 | 0.316–0.343 | 0.417 | 13.5% | 161.67 | Index Only Scan | 0.036 | 0.367 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_103 | btree_tuned | 10 | 0.320 | 0.314–0.331 | 0.356 | 5.7% | 162.68 | Index Only Scan | 0.039 | 0.359 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_103 | gin | 10 | 0.690 | 0.677–0.742 | 0.864 | 11.3% | 75.33 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 0.748 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_103 | gist | 10 | 0.724 | 0.706–0.888 | 1.670 | 53.3% | 71.74 | Index Only Scan | 0.037 | 0.760 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_103 | hash (partial) | 10 | 0.669 | 0.660–0.685 | 0.709 | 3.2% | 77.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.033 | 0.722 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_103 | roaring | 10 | 0.011 | 0.011–0.013 | 0.016 | 16.7% | 4519.78 | RoaringCount | 0.040 | 0.051 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_103 | roaring_bitmap | 10 | 0.437 | 0.419–0.467 | 0.530 | 10.1% | 118.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 0.474 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_103 | seq | 10 | 51.977 | 51.247–55.556 | 58.387 | 5.8% | 1.00 | Seq Scan | 0.032 | 52.027 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_17 | brin | 10 | 0.749 | 0.733–0.765 | 0.806 | 5.4% | 69.99 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 0.802 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_17 | btree | 10 | 0.320 | 0.315–0.329 | 0.340 | 3.4% | 163.82 | Index Only Scan | 0.036 | 0.358 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_17 | btree_tuned | 10 | 0.324 | 0.314–0.375 | 0.415 | 12.5% | 161.80 | Index Only Scan | 0.040 | 0.381 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_17 | gin | 10 | 0.683 | 0.667–0.701 | 0.770 | 7.0% | 76.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 0.744 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_17 | gist | 10 | 0.752 | 0.736–0.783 | 0.817 | 4.6% | 69.76 | Index Only Scan | 0.036 | 0.790 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_17 | hash (partial) | 10 | 0.696 | 0.662–0.708 | 0.712 | 3.5% | 75.27 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 0.738 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_17 | roaring | 10 | 0.011 | 0.011–0.013 | 0.015 | 12.8% | 4765.73 | RoaringCount | 0.040 | 0.051 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_17 | roaring_bitmap | 10 | 0.443 | 0.433–0.455 | 0.461 | 3.1% | 118.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 0.489 |
| scalar | 1000000 | clean | default | 64MB | eq_clustered_17 | seq | 10 | 52.423 | 50.992–57.815 | 59.067 | 6.6% | 1.00 | Seq Scan | 0.034 | 52.454 |
| scalar | 1000000 | clean | default | 64MB | eq_nullable_17 | brin | 10 | 56.684 | 54.657–59.183 | 59.625 | 4.4% | 0.98 | Seq Scan (fallback) | 0.052 | 56.735 |
| scalar | 1000000 | clean | default | 64MB | eq_nullable_17 | btree | 10 | 0.296 | 0.295–0.306 | 0.322 | 3.7% | 188.16 | Index Only Scan | 0.036 | 0.331 |
| scalar | 1000000 | clean | default | 64MB | eq_nullable_17 | btree_tuned | 10 | 0.301 | 0.295–0.308 | 0.317 | 2.9% | 184.73 | Index Only Scan | 0.038 | 0.342 |
| scalar | 1000000 | clean | default | 64MB | eq_nullable_17 | gin | 10 | 3.379 | 3.231–3.555 | 4.864 | 23.2% | 16.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 3.432 |
| scalar | 1000000 | clean | default | 64MB | eq_nullable_17 | gist | 10 | 0.700 | 0.662–0.783 | 1.177 | 31.3% | 79.62 | Index Only Scan | 0.040 | 0.753 |
| scalar | 1000000 | clean | default | 64MB | eq_nullable_17 | hash (partial) | 10 | 3.264 | 3.102–3.578 | 4.017 | 12.3% | 17.06 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 3.300 |
| scalar | 1000000 | clean | default | 64MB | eq_nullable_17 | roaring | 10 | 0.029 | 0.028–0.030 | 0.047 | 31.6% | 1954.26 | RoaringCount | 0.037 | 0.065 |
| scalar | 1000000 | clean | default | 64MB | eq_nullable_17 | roaring_bitmap | 10 | 3.348 | 3.221–3.450 | 3.495 | 3.9% | 16.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.393 |
| scalar | 1000000 | clean | default | 64MB | eq_nullable_17 | seq | 10 | 55.697 | 53.263–58.224 | 62.032 | 6.1% | 1.00 | Seq Scan | 0.031 | 55.731 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_0 | brin | 10 | 82.159 | 79.970–87.890 | 92.795 | 6.3% | 1.06 | Seq Scan (fallback) | 0.049 | 82.210 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_0 | btree | 10 | 58.014 | 55.722–59.874 | 63.519 | 5.6% | 1.50 | Index Only Scan | 0.036 | 58.053 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_0 | btree_tuned | 10 | 58.544 | 56.404–59.543 | 61.090 | 3.7% | 1.49 | Index Only Scan | 0.036 | 58.619 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_0 | gin | 10 | 86.660 | 84.201–89.256 | 90.935 | 4.2% | 1.01 | Seq Scan (fallback) | 0.041 | 86.697 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_0 | gist | 10 | 128.693 | 126.531–130.454 | 131.598 | 1.7% | 0.68 | Index Only Scan | 0.036 | 128.732 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_0 | hash (partial) | 10 | 84.034 | 81.214–89.303 | 92.500 | 5.4% | 1.04 | Seq Scan (fallback) | 0.046 | 84.090 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_0 | roaring | 10 | 0.155 | 0.154–0.161 | 0.234 | 25.0% | 560.54 | RoaringCount | 0.038 | 0.194 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_0 | roaring_bitmap | 10 | 83.351 | 82.187–85.567 | 87.085 | 3.0% | 1.05 | Seq Scan (fallback) | 0.035 | 83.401 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_0 | seq | 10 | 87.165 | 85.912–89.167 | 91.053 | 3.3% | 1.00 | Seq Scan | 0.030 | 87.198 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_17 | brin | 10 | 80.399 | 76.904–83.549 | 84.823 | 4.7% | 0.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 80.451 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_17 | btree | 10 | 0.026 | 0.024–0.028 | 0.032 | 12.4% | 2095.23 | Index Only Scan | 0.037 | 0.064 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_17 | btree_tuned | 10 | 0.026 | 0.025–0.028 | 0.029 | 6.5% | 2095.23 | Index Only Scan | 0.039 | 0.065 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_17 | gin | 10 | 0.104 | 0.097–0.116 | 0.144 | 18.5% | 526.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 0.146 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_17 | gist | 10 | 0.055 | 0.054–0.059 | 0.150 | 72.7% | 990.47 | Index Only Scan | 0.036 | 0.092 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_17 | hash (partial) | 10 | 54.135 | 52.811–59.136 | 61.699 | 6.8% | 1.01 | Seq Scan (fallback) | 0.031 | 54.181 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_17 | roaring | 10 | 0.016 | 0.014–0.016 | 0.016 | 6.2% | 3404.75 | RoaringCount | 0.037 | 0.052 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_17 | roaring_bitmap | 10 | 0.105 | 0.100–0.115 | 0.148 | 19.7% | 518.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 0.142 |
| scalar | 1000000 | clean | default | 64MB | eq_skew_17 | seq | 10 | 54.476 | 52.935–58.550 | 59.245 | 5.3% | 1.00 | Seq Scan | 0.033 | 54.511 |
| scalar | 1000000 | clean | default | 64MB | fetch_clustered | brin | 10 | 0.846 | 0.830–0.869 | 1.071 | 14.2% | 62.90 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 0.896 |
| scalar | 1000000 | clean | default | 64MB | fetch_clustered | btree | 10 | 0.678 | 0.660–0.787 | 1.022 | 20.5% | 78.48 | Index Scan | 0.041 | 0.732 |
| scalar | 1000000 | clean | default | 64MB | fetch_clustered | btree_tuned | 10 | 0.677 | 0.647–0.707 | 0.723 | 4.8% | 78.65 | Index Scan | 0.042 | 0.719 |
| scalar | 1000000 | clean | default | 64MB | fetch_clustered | gin | 10 | 0.854 | 0.835–1.110 | 1.185 | 15.7% | 62.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 0.913 |
| scalar | 1000000 | clean | default | 64MB | fetch_clustered | gist | 10 | 0.790 | 0.763–0.851 | 0.943 | 8.9% | 67.40 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 0.847 |
| scalar | 1000000 | clean | default | 64MB | fetch_clustered | hash (partial) | 10 | 0.762 | 0.751–0.792 | 0.813 | 3.2% | 69.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 0.800 |
| scalar | 1000000 | clean | default | 64MB | fetch_clustered | roaring | 10 | 0.623 | 0.604–0.630 | 0.658 | 4.1% | 85.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 0.663 |
| scalar | 1000000 | clean | default | 64MB | fetch_clustered | roaring_bitmap | 10 | 0.605 | 0.598–0.613 | 0.643 | 4.1% | 87.88 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 0.653 |
| scalar | 1000000 | clean | default | 64MB | fetch_clustered | seq | 10 | 53.209 | 51.575–56.307 | 60.016 | 6.3% | 1.00 | Seq Scan | 0.038 | 53.246 |
| scalar | 1000000 | clean | default | 64MB | fetch_medium | brin | 10 | 71.120 | 70.168–73.011 | 79.342 | 6.1% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 71.179 |
| scalar | 1000000 | clean | default | 64MB | fetch_medium | btree | 10 | 3.946 | 3.427–4.302 | 4.616 | 13.6% | 12.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.986 |
| scalar | 1000000 | clean | default | 64MB | fetch_medium | btree_tuned | 10 | 0.605 | 0.589–0.643 | 0.730 | 9.7% | 81.73 | Index Only Scan | 0.044 | 0.648 |
| scalar | 1000000 | clean | default | 64MB | fetch_medium | gin | 10 | 3.820 | 3.399–3.997 | 4.075 | 9.1% | 12.93 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 3.878 |
| scalar | 1000000 | clean | default | 64MB | fetch_medium | gist | 10 | 3.934 | 3.309–4.716 | 5.539 | 23.5% | 12.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.998 |
| scalar | 1000000 | clean | default | 64MB | fetch_medium | hash (partial) | 10 | 3.641 | 3.092–4.180 | 4.261 | 13.9% | 13.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.690 |
| scalar | 1000000 | clean | default | 64MB | fetch_medium | roaring | 10 | 3.452 | 2.949–4.055 | 4.483 | 17.1% | 14.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 3.491 |
| scalar | 1000000 | clean | default | 64MB | fetch_medium | roaring_bitmap | 10 | 3.218 | 2.968–3.396 | 3.604 | 8.8% | 15.35 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 3.266 |
| scalar | 1000000 | clean | default | 64MB | fetch_medium | seq | 10 | 49.407 | 47.002–50.651 | 52.110 | 4.7% | 1.00 | Seq Scan | 0.036 | 49.441 |
| scalar | 1000000 | clean | default | 64MB | fetch_rare | brin | 10 | 71.781 | 69.645–77.526 | 86.426 | 8.9% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 71.840 |
| scalar | 1000000 | clean | default | 64MB | fetch_rare | btree | 10 | 0.073 | 0.066–0.081 | 0.083 | 10.0% | 685.29 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 0.114 |
| scalar | 1000000 | clean | default | 64MB | fetch_rare | btree_tuned | 10 | 0.067 | 0.056–0.073 | 0.079 | 17.2% | 746.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 0.111 |
| scalar | 1000000 | clean | default | 64MB | fetch_rare | gin | 10 | 0.067 | 0.061–0.076 | 0.082 | 12.5% | 746.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.112 |
| scalar | 1000000 | clean | default | 64MB | fetch_rare | gist | 10 | 0.092 | 0.081–0.103 | 0.124 | 18.5% | 540.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 0.135 |
| scalar | 1000000 | clean | default | 64MB | fetch_rare | hash (partial) | 10 | 0.058 | 0.057–0.070 | 0.096 | 27.7% | 855.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 0.096 |
| scalar | 1000000 | clean | default | 64MB | fetch_rare | roaring | 10 | 0.069 | 0.060–0.080 | 0.099 | 21.7% | 725.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 0.109 |
| scalar | 1000000 | clean | default | 64MB | fetch_rare | roaring_bitmap | 10 | 0.059 | 0.054–0.064 | 0.083 | 21.0% | 840.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 0.101 |
| scalar | 1000000 | clean | default | 64MB | fetch_rare | seq | 10 | 50.026 | 47.998–52.079 | 53.628 | 5.1% | 1.00 | Seq Scan | 0.034 | 50.069 |
| scalar | 1000000 | clean | default | 64MB | group_c2 | brin | 10 | 135.122 | 127.591–140.259 | 149.034 | 6.2% | 1.01 | Seq Scan (fallback) | 0.045 | 135.161 |
| scalar | 1000000 | clean | default | 64MB | group_c2 | btree | 10 | 83.809 | 80.962–85.626 | 86.295 | 3.2% | 1.63 | Index Only Scan | 0.040 | 83.850 |
| scalar | 1000000 | clean | default | 64MB | group_c2 | btree_tuned | 10 | 84.008 | 82.416–85.127 | 87.939 | 2.9% | 1.63 | Index Only Scan | 0.043 | 84.052 |
| scalar | 1000000 | clean | default | 64MB | group_c2 | gin | 10 | 133.743 | 129.740–138.158 | 139.733 | 3.2% | 1.02 | Seq Scan (fallback) | 0.035 | 133.772 |
| scalar | 1000000 | clean | default | 64MB | group_c2 | gist | 10 | 196.892 | 194.329–201.411 | 206.826 | 3.0% | 0.70 | Index Only Scan | 0.034 | 196.930 |
| scalar | 1000000 | clean | default | 64MB | group_c2 | hash (partial) | 10 | 134.261 | 129.726–139.218 | 144.083 | 4.5% | 1.02 | Seq Scan (fallback) | 0.037 | 134.295 |
| scalar | 1000000 | clean | default | 64MB | group_c2 | roaring | 10 | 0.857 | 0.821–0.893 | 1.522 | 38.4% | 159.74 | RoaringCount | 0.039 | 0.895 |
| scalar | 1000000 | clean | default | 64MB | group_c2 | roaring_bitmap | 10 | 134.108 | 131.457–140.127 | 143.113 | 3.6% | 1.02 | Seq Scan (fallback) | 0.032 | 134.146 |
| scalar | 1000000 | clean | default | 64MB | group_c2 | seq | 10 | 136.897 | 134.139–142.964 | 146.799 | 4.1% | 1.00 | Seq Scan | 0.036 | 136.938 |
| scalar | 1000000 | clean | default | 64MB | group_c20 | brin | 10 | 145.894 | 144.406–149.487 | 155.801 | 3.1% | 1.00 | Seq Scan (fallback) | 0.045 | 145.935 |
| scalar | 1000000 | clean | default | 64MB | group_c20 | btree | 10 | 83.097 | 80.757–85.610 | 92.324 | 5.6% | 1.76 | Index Only Scan | 0.040 | 83.136 |
| scalar | 1000000 | clean | default | 64MB | group_c20 | btree_tuned | 10 | 84.729 | 82.043–86.884 | 88.350 | 3.5% | 1.73 | Index Only Scan | 0.043 | 84.773 |
| scalar | 1000000 | clean | default | 64MB | group_c20 | gin | 10 | 147.425 | 143.897–150.777 | 158.415 | 4.7% | 0.99 | Seq Scan (fallback) | 0.038 | 147.470 |
| scalar | 1000000 | clean | default | 64MB | group_c20 | gist | 10 | 205.233 | 203.084–207.037 | 209.698 | 2.4% | 0.71 | Index Only Scan | 0.036 | 205.269 |
| scalar | 1000000 | clean | default | 64MB | group_c20 | hash (partial) | 10 | 143.785 | 139.291–147.424 | 151.554 | 3.9% | 1.02 | Seq Scan (fallback) | 0.036 | 143.840 |
| scalar | 1000000 | clean | default | 64MB | group_c20 | roaring | 10 | 1.153 | 1.070–1.169 | 1.387 | 12.5% | 127.00 | RoaringCount | 0.034 | 1.187 |
| scalar | 1000000 | clean | default | 64MB | group_c20 | roaring_bitmap | 10 | 147.838 | 140.929–150.701 | 150.840 | 3.2% | 0.99 | Seq Scan (fallback) | 0.034 | 147.874 |
| scalar | 1000000 | clean | default | 64MB | group_c20 | seq | 10 | 146.427 | 144.380–151.205 | 156.980 | 3.8% | 1.00 | Seq Scan | 0.034 | 146.462 |
| scalar | 1000000 | clean | default | 64MB | group_c200 | brin | 10 | 154.025 | 153.114–159.521 | 163.039 | 3.0% | 0.99 | Seq Scan (fallback) | 0.056 | 154.075 |
| scalar | 1000000 | clean | default | 64MB | group_c200 | btree | 10 | 83.216 | 78.273–88.445 | 92.405 | 6.8% | 1.84 | Index Only Scan | 0.039 | 83.257 |
| scalar | 1000000 | clean | default | 64MB | group_c200 | btree_tuned | 10 | 83.801 | 82.287–85.574 | 89.055 | 4.0% | 1.82 | Index Only Scan | 0.043 | 83.843 |
| scalar | 1000000 | clean | default | 64MB | group_c200 | gin | 10 | 152.269 | 147.936–157.661 | 164.407 | 4.5% | 1.00 | Seq Scan (fallback) | 0.034 | 152.316 |
| scalar | 1000000 | clean | default | 64MB | group_c200 | gist | 10 | 203.514 | 200.586–209.514 | 214.173 | 2.7% | 0.75 | Index Only Scan | 0.036 | 203.559 |
| scalar | 1000000 | clean | default | 64MB | group_c200 | hash (partial) | 10 | 150.981 | 147.569–154.157 | 159.408 | 3.2% | 1.01 | Seq Scan (fallback) | 0.035 | 151.017 |
| scalar | 1000000 | clean | default | 64MB | group_c200 | roaring | 10 | 3.881 | 3.817–4.080 | 4.320 | 5.4% | 39.39 | RoaringCount | 0.034 | 3.917 |
| scalar | 1000000 | clean | default | 64MB | group_c200 | roaring_bitmap | 10 | 153.425 | 149.968–155.525 | 163.755 | 4.1% | 1.00 | Seq Scan (fallback) | 0.040 | 153.459 |
| scalar | 1000000 | clean | default | 64MB | group_c200 | seq | 10 | 152.871 | 150.226–159.657 | 166.436 | 4.2% | 1.00 | Seq Scan | 0.036 | 152.906 |
| scalar | 1000000 | clean | default | 64MB | group_c20k | brin | 10 | 177.357 | 175.572–184.245 | 187.855 | 2.9% | 1.04 | Seq Scan (fallback) | 0.042 | 177.422 |
| scalar | 1000000 | clean | default | 64MB | group_c20k | btree | 10 | 84.816 | 82.711–86.166 | 86.364 | 2.4% | 2.17 | Index Only Scan | 0.040 | 84.857 |
| scalar | 1000000 | clean | default | 64MB | group_c20k | btree_tuned | 10 | 86.756 | 82.495–88.050 | 90.602 | 3.9% | 2.13 | Index Only Scan | 0.041 | 86.799 |
| scalar | 1000000 | clean | default | 64MB | group_c20k | gin | 10 | 178.851 | 175.361–188.656 | 195.512 | 4.6% | 1.03 | Seq Scan (fallback) | 0.040 | 178.892 |
| scalar | 1000000 | clean | default | 64MB | group_c20k | gist | 10 | 204.435 | 200.999–210.458 | 212.536 | 2.5% | 0.90 | Index Only Scan | 0.036 | 204.469 |
| scalar | 1000000 | clean | default | 64MB | group_c20k | hash (partial) | 10 | 182.844 | 176.040–188.613 | 193.625 | 3.9% | 1.01 | Seq Scan (fallback) | 0.039 | 182.888 |
| scalar | 1000000 | clean | default | 64MB | group_c20k | roaring | 10 | 61.785 | 60.294–64.722 | 68.635 | 5.9% | 2.98 | RoaringCount | 0.035 | 61.826 |
| scalar | 1000000 | clean | default | 64MB | group_c20k | roaring_bitmap | 10 | 181.527 | 177.740–185.630 | 185.985 | 2.2% | 1.02 | Seq Scan (fallback) | 0.035 | 181.567 |
| scalar | 1000000 | clean | default | 64MB | group_c20k | seq | 10 | 184.384 | 177.720–186.765 | 189.778 | 2.9% | 1.00 | Seq Scan | 0.035 | 184.425 |
| scalar | 1000000 | clean | default | 64MB | group_filtered | brin | 10 | 72.257 | 69.809–77.292 | 81.881 | 6.9% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 72.322 |
| scalar | 1000000 | clean | default | 64MB | group_filtered | btree | 10 | 3.786 | 3.208–4.584 | 5.601 | 23.4% | 13.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 3.837 |
| scalar | 1000000 | clean | default | 64MB | group_filtered | btree_tuned | 10 | 0.452 | 0.445–0.471 | 0.529 | 8.1% | 109.87 | Index Only Scan | 0.056 | 0.508 |
| scalar | 1000000 | clean | default | 64MB | group_filtered | gin | 10 | 3.926 | 3.739–4.614 | 4.822 | 11.2% | 12.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 3.971 |
| scalar | 1000000 | clean | default | 64MB | group_filtered | gist | 10 | 4.151 | 3.688–4.475 | 4.781 | 14.0% | 11.96 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 4.205 |
| scalar | 1000000 | clean | default | 64MB | group_filtered | hash (partial) | 10 | 3.965 | 3.502–4.165 | 5.035 | 17.9% | 12.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 4.016 |
| scalar | 1000000 | clean | default | 64MB | group_filtered | roaring | 10 | 2.459 | 2.442–2.499 | 2.525 | 1.4% | 20.20 | RoaringCount | 0.047 | 2.513 |
| scalar | 1000000 | clean | default | 64MB | group_filtered | roaring_bitmap | 10 | 3.458 | 3.413–3.588 | 3.841 | 7.3% | 14.36 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 3.513 |
| scalar | 1000000 | clean | default | 64MB | group_filtered | seq | 10 | 49.661 | 46.613–52.464 | 52.992 | 6.0% | 1.00 | Seq Scan | 0.039 | 49.703 |
| scalar | 1000000 | clean | default | 64MB | group_nullable | brin | 10 | 160.963 | 156.005–163.281 | 165.889 | 3.1% | 1.03 | Seq Scan (fallback) | 0.048 | 161.011 |
| scalar | 1000000 | clean | default | 64MB | group_nullable | btree | 10 | 81.578 | 79.489–83.884 | 86.306 | 3.6% | 2.03 | Index Only Scan | 0.038 | 81.619 |
| scalar | 1000000 | clean | default | 64MB | group_nullable | btree_tuned | 10 | 82.653 | 81.203–86.065 | 91.446 | 5.0% | 2.00 | Index Only Scan | 0.042 | 82.700 |
| scalar | 1000000 | clean | default | 64MB | group_nullable | gin | 10 | 158.055 | 155.719–161.096 | 166.178 | 2.9% | 1.05 | Seq Scan (fallback) | 0.043 | 158.099 |
| scalar | 1000000 | clean | default | 64MB | group_nullable | gist | 10 | 197.244 | 193.674–202.138 | 206.280 | 2.9% | 0.84 | Index Only Scan | 0.038 | 197.281 |
| scalar | 1000000 | clean | default | 64MB | group_nullable | hash (partial) | 10 | 157.198 | 154.257–169.982 | 174.907 | 5.5% | 1.05 | Seq Scan (fallback) | 0.037 | 157.241 |
| scalar | 1000000 | clean | default | 64MB | group_nullable | roaring | 10 | 3.994 | 3.842–4.338 | 4.553 | 6.8% | 41.49 | RoaringCount | 0.035 | 4.041 |
| scalar | 1000000 | clean | default | 64MB | group_nullable | roaring_bitmap | 10 | 158.463 | 155.872–161.606 | 163.272 | 2.0% | 1.05 | Seq Scan (fallback) | 0.038 | 158.498 |
| scalar | 1000000 | clean | default | 64MB | group_nullable | seq | 10 | 165.709 | 160.662–168.997 | 172.402 | 3.1% | 1.00 | Seq Scan | 0.039 | 165.758 |
| scalar | 1000000 | clean | default | 64MB | in_and | brin | 10 | 69.466 | 68.166–72.616 | 74.318 | 3.7% | 1.10 | Seq Scan (fallback) | 0.066 | 69.520 |
| scalar | 1000000 | clean | default | 64MB | in_and | btree | 10 | 7.528 | 6.800–7.991 | 8.197 | 8.9% | 10.13 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 7.584 |
| scalar | 1000000 | clean | default | 64MB | in_and | btree_tuned | 10 | 0.179 | 0.177–0.191 | 0.196 | 4.6% | 425.01 | Index Only Scan | 0.055 | 0.239 |
| scalar | 1000000 | clean | default | 64MB | in_and | gin | 10 | 14.819 | 14.279–15.498 | 16.064 | 5.3% | 5.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 14.887 |
| scalar | 1000000 | clean | default | 64MB | in_and | gist | 10 | 11.327 | 10.524–12.597 | 14.335 | 12.8% | 6.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 11.376 |
| scalar | 1000000 | clean | default | 64MB | in_and | hash (partial) | 10 | 8.418 | 8.320–8.802 | 8.955 | 3.5% | 9.06 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 8.491 |
| scalar | 1000000 | clean | default | 64MB | in_and | roaring | 10 | 1.974 | 1.944–2.099 | 2.165 | 5.2% | 38.65 | RoaringCount | 0.053 | 2.029 |
| scalar | 1000000 | clean | default | 64MB | in_and | roaring_bitmap | 10 | 7.853 | 7.669–8.068 | 8.301 | 3.6% | 9.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 7.909 |
| scalar | 1000000 | clean | default | 64MB | in_and | seq | 10 | 76.289 | 72.226–78.777 | 82.277 | 7.3% | 1.00 | Seq Scan | 0.050 | 76.337 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_10 | brin | 10 | 59.852 | 56.570–61.782 | 65.272 | 5.8% | 1.14 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 59.917 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_10 | btree | 10 | 0.050 | 0.049–0.052 | 0.054 | 4.7% | 1383.01 | Index Only Scan | 0.043 | 0.092 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_10 | btree_tuned | 10 | 0.052 | 0.050–0.071 | 0.089 | 27.3% | 1316.52 | Index Only Scan | 0.046 | 0.099 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_10 | gin | 10 | 0.432 | 0.405–0.465 | 0.482 | 9.5% | 158.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 0.490 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_10 | gist | 10 | 0.617 | 0.538–0.796 | 0.870 | 20.9% | 110.95 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 0.659 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_10 | hash (partial) | 10 | 0.432 | 0.402–0.465 | 0.513 | 11.0% | 158.29 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 0.474 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_10 | roaring | 10 | 0.071 | 0.066–0.088 | 0.118 | 29.5% | 971.05 | RoaringCount | 0.049 | 0.119 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_10 | roaring_bitmap | 10 | 0.423 | 0.359–0.464 | 0.560 | 20.3% | 161.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 0.474 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_10 | seq | 10 | 68.459 | 68.127–70.834 | 73.220 | 3.1% | 1.00 | Seq Scan | 0.039 | 68.502 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_100 | brin | 10 | 153.325 | 148.923–156.337 | 159.579 | 3.2% | 0.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.096 | 153.415 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_100 | btree | 10 | 0.331 | 0.321–0.356 | 0.453 | 17.2% | 244.64 | Index Only Scan | 0.082 | 0.416 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_100 | btree_tuned | 10 | 0.331 | 0.313–0.361 | 0.435 | 15.8% | 244.27 | Index Only Scan | 0.082 | 0.413 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_100 | gin | 10 | 3.871 | 3.679–4.242 | 4.473 | 9.4% | 20.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.113 | 4.002 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_100 | gist | 10 | 5.890 | 4.735–6.687 | 6.975 | 17.4% | 13.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.081 | 5.971 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_100 | hash (partial) | 10 | 4.092 | 3.861–4.425 | 4.749 | 8.7% | 19.76 | Bitmap Heap Scan, Bitmap Index Scan | 0.099 | 4.196 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_100 | roaring | 10 | 0.629 | 0.604–0.644 | 0.671 | 4.2% | 128.44 | RoaringCount | 0.121 | 0.752 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_100 | roaring_bitmap | 10 | 3.554 | 3.432–3.675 | 3.790 | 5.5% | 22.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.083 | 3.647 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_100 | seq | 10 | 80.854 | 79.249–82.291 | 83.563 | 2.1% | 1.00 | Seq Scan | 0.060 | 80.919 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_1000 | brin | 10 | 75.026 | 71.777–76.788 | 78.330 | 3.9% | 1.00 | Seq Scan (fallback) | 0.473 | 75.499 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_1000 | btree | 10 | 3.103 | 3.085–3.287 | 3.589 | 6.6% | 24.19 | Index Only Scan | 0.449 | 3.548 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_1000 | btree_tuned | 10 | 3.135 | 3.066–3.179 | 3.352 | 4.0% | 23.94 | Index Only Scan | 0.437 | 3.571 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_1000 | gin | 10 | 21.236 | 21.005–21.912 | 23.715 | 5.6% | 3.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.622 | 21.842 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_1000 | gist | 10 | 40.031 | 38.796–42.090 | 43.700 | 5.1% | 1.87 | Bitmap Heap Scan, Bitmap Index Scan | 0.459 | 40.493 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_1000 | hash (partial) | 10 | 23.395 | 22.601–24.680 | 25.083 | 4.5% | 3.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.463 | 23.848 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_1000 | roaring | 10 | 15.384 | 14.336–16.529 | 19.180 | 13.2% | 4.88 | RoaringCount | 0.836 | 16.190 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_1000 | roaring_bitmap | 10 | 20.209 | 19.859–21.507 | 22.525 | 5.6% | 3.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.483 | 20.692 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_1000 | seq | 10 | 75.043 | 73.484–77.913 | 80.595 | 3.9% | 1.00 | Seq Scan | 0.311 | 75.378 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_3 | brin | 10 | 21.256 | 20.787–22.921 | 23.608 | 5.5% | 3.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 21.307 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_3 | btree | 10 | 0.028 | 0.026–0.029 | 0.031 | 7.0% | 2672.98 | Index Only Scan | 0.041 | 0.069 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_3 | btree_tuned | 10 | 0.027 | 0.026–0.030 | 0.036 | 16.1% | 2771.98 | Index Only Scan | 0.042 | 0.069 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_3 | gin | 10 | 0.150 | 0.141–0.162 | 0.163 | 9.1% | 497.30 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 0.195 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_3 | gist | 10 | 0.207 | 0.183–0.242 | 0.256 | 16.9% | 361.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 0.270 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_3 | hash (partial) | 10 | 0.158 | 0.131–0.170 | 0.188 | 15.1% | 475.20 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 0.195 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_3 | roaring | 10 | 0.025 | 0.024–0.032 | 0.039 | 23.9% | 2993.74 | RoaringCount | 0.044 | 0.069 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_3 | roaring_bitmap | 10 | 0.136 | 0.125–0.151 | 0.161 | 12.3% | 552.35 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 0.184 |
| scalar | 1000000 | clean | default | 64MB | in_c20k_3 | seq | 10 | 74.844 | 70.982–77.130 | 79.388 | 5.1% | 1.00 | Seq Scan | 0.033 | 74.878 |
| scalar | 1000000 | clean | default | 64MB | in_overlap | brin | 10 | 69.456 | 67.968–77.191 | 86.054 | 9.9% | 1.04 | Seq Scan (fallback) | 0.048 | 69.507 |
| scalar | 1000000 | clean | default | 64MB | in_overlap | btree | 10 | 0.643 | 0.623–0.713 | 0.857 | 15.2% | 112.54 | Index Only Scan | 0.041 | 0.681 |
| scalar | 1000000 | clean | default | 64MB | in_overlap | btree_tuned | 10 | 0.643 | 0.627–0.665 | 0.687 | 4.1% | 112.54 | Index Only Scan | 0.044 | 0.687 |
| scalar | 1000000 | clean | default | 64MB | in_overlap | gin | 10 | 6.756 | 6.157–7.224 | 7.629 | 9.4% | 10.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 6.801 |
| scalar | 1000000 | clean | default | 64MB | in_overlap | gist | 10 | 7.319 | 6.937–8.323 | 8.640 | 14.1% | 9.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 7.383 |
| scalar | 1000000 | clean | default | 64MB | in_overlap | hash (partial) | 10 | 6.397 | 6.217–6.722 | 7.253 | 7.0% | 11.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 6.438 |
| scalar | 1000000 | clean | default | 64MB | in_overlap | roaring | 10 | 0.096 | 0.094–0.111 | 0.120 | 11.1% | 753.78 | RoaringCount | 0.042 | 0.142 |
| scalar | 1000000 | clean | default | 64MB | in_overlap | roaring_bitmap | 10 | 6.522 | 6.131–6.961 | 7.685 | 9.9% | 11.09 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 6.571 |
| scalar | 1000000 | clean | default | 64MB | in_overlap | seq | 10 | 72.363 | 71.532–74.152 | 75.447 | 3.0% | 1.00 | Seq Scan | 0.037 | 72.412 |
| scalar | 1000000 | clean | default | 64MB | is_null | brin | 10 | 57.167 | 56.697–61.142 | 63.839 | 5.5% | 1.02 | Seq Scan (fallback) | 0.041 | 57.207 |
| scalar | 1000000 | clean | default | 64MB | is_null | btree | 10 | 6.885 | 6.645–7.348 | 7.678 | 5.9% | 8.46 | Index Only Scan | 0.033 | 6.916 |
| scalar | 1000000 | clean | default | 64MB | is_null | btree_tuned | 10 | 7.045 | 6.755–7.609 | 8.146 | 8.0% | 8.26 | Index Only Scan | 0.034 | 7.080 |
| scalar | 1000000 | clean | default | 64MB | is_null | gin | 10 | 60.729 | 56.811–62.073 | 64.569 | 6.1% | 0.96 | Seq Scan (fallback) | 0.034 | 60.757 |
| scalar | 1000000 | clean | default | 64MB | is_null | gist | 10 | 18.021 | 17.255–19.665 | 22.856 | 13.0% | 3.23 | Index Only Scan | 0.030 | 18.051 |
| scalar | 1000000 | clean | default | 64MB | is_null | hash (partial) | 10 | 57.810 | 55.591–59.578 | 60.576 | 3.8% | 1.01 | Seq Scan (fallback) | 0.026 | 57.841 |
| scalar | 1000000 | clean | default | 64MB | is_null | roaring | 10 | 0.102 | 0.099–0.121 | 0.138 | 14.6% | 570.80 | RoaringCount | 0.036 | 0.151 |
| scalar | 1000000 | clean | default | 64MB | is_null | roaring_bitmap | 10 | 26.794 | 25.703–27.843 | 29.485 | 6.0% | 2.17 | Bitmap Heap Scan, Bitmap Index Scan | 0.031 | 26.834 |
| scalar | 1000000 | clean | default | 64MB | is_null | seq | 10 | 58.222 | 56.361–59.911 | 60.340 | 3.3% | 1.00 | Seq Scan | 0.028 | 58.270 |
| scalar | 1000000 | clean | default | 64MB | not_null | brin | 10 | 80.808 | 80.174–82.178 | 83.189 | 2.0% | 0.99 | Seq Scan (fallback) | 0.045 | 80.857 |
| scalar | 1000000 | clean | default | 64MB | not_null | btree | 10 | 58.079 | 55.056–59.645 | 60.448 | 4.4% | 1.37 | Index Only Scan | 0.034 | 58.184 |
| scalar | 1000000 | clean | default | 64MB | not_null | btree_tuned | 10 | 57.654 | 55.365–60.110 | 61.277 | 4.3% | 1.38 | Index Only Scan | 0.035 | 57.686 |
| scalar | 1000000 | clean | default | 64MB | not_null | gin | 10 | 80.172 | 77.472–83.183 | 86.684 | 4.3% | 1.00 | Seq Scan (fallback) | 0.029 | 80.201 |
| scalar | 1000000 | clean | default | 64MB | not_null | gist | 10 | 115.275 | 112.882–121.131 | 123.386 | 4.4% | 0.69 | Index Only Scan | 0.032 | 115.306 |
| scalar | 1000000 | clean | default | 64MB | not_null | hash (partial) | 10 | 81.770 | 79.538–83.916 | 86.778 | 3.9% | 0.98 | Seq Scan (fallback) | 0.026 | 81.815 |
| scalar | 1000000 | clean | default | 64MB | not_null | roaring | 10 | 56.361 | 55.732–58.294 | 60.863 | 3.7% | 1.42 | RoaringCount | 0.035 | 56.407 |
| scalar | 1000000 | clean | default | 64MB | not_null | roaring_bitmap | 10 | 82.453 | 80.662–84.323 | 87.579 | 3.5% | 0.97 | Seq Scan (fallback) | 0.031 | 82.487 |
| scalar | 1000000 | clean | default | 64MB | not_null | seq | 10 | 79.791 | 78.474–85.959 | 92.277 | 6.9% | 1.00 | Seq Scan | 0.024 | 79.819 |
| scalar | 1000000 | clean | default | 64MB | null_and | brin | 10 | 72.757 | 70.954–78.395 | 81.877 | 6.3% | 0.76 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 72.816 |
| scalar | 1000000 | clean | default | 64MB | null_and | btree | 10 | 3.864 | 3.760–3.998 | 4.202 | 5.2% | 14.26 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.904 |
| scalar | 1000000 | clean | default | 64MB | null_and | btree_tuned | 10 | 3.957 | 3.816–4.164 | 4.490 | 7.1% | 13.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 4.024 |
| scalar | 1000000 | clean | default | 64MB | null_and | gin | 10 | 3.688 | 3.260–4.016 | 4.425 | 13.9% | 14.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 3.774 |
| scalar | 1000000 | clean | default | 64MB | null_and | gist | 10 | 12.351 | 11.849–13.144 | 14.008 | 7.6% | 4.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 12.417 |
| scalar | 1000000 | clean | default | 64MB | null_and | hash (partial) | 10 | 3.451 | 3.126–3.804 | 4.056 | 13.1% | 15.96 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 3.506 |
| scalar | 1000000 | clean | default | 64MB | null_and | roaring | 10 | 0.183 | 0.181–0.198 | 0.289 | 27.4% | 300.20 | RoaringCount | 0.045 | 0.231 |
| scalar | 1000000 | clean | default | 64MB | null_and | roaring_bitmap | 10 | 4.332 | 4.143–4.488 | 4.945 | 8.3% | 12.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 4.382 |
| scalar | 1000000 | clean | default | 64MB | null_and | seq | 10 | 55.087 | 53.127–57.666 | 58.868 | 4.5% | 1.00 | Seq Scan | 0.032 | 55.118 |
| scalar | 1000000 | clean | default | 64MB | or_columns | brin | 10 | 59.298 | 57.652–62.240 | 62.995 | 3.9% | 1.08 | Seq Scan (fallback) | 0.049 | 59.346 |
| scalar | 1000000 | clean | default | 64MB | or_columns | btree | 10 | 18.866 | 18.422–20.709 | 22.044 | 8.1% | 3.39 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 18.907 |
| scalar | 1000000 | clean | default | 64MB | or_columns | btree_tuned | 10 | 19.712 | 17.584–20.269 | 22.118 | 12.2% | 3.24 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 19.758 |
| scalar | 1000000 | clean | default | 64MB | or_columns | gin | 10 | 21.811 | 20.899–22.057 | 22.439 | 3.3% | 2.93 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 21.862 |
| scalar | 1000000 | clean | default | 64MB | or_columns | gist | 10 | 21.046 | 20.163–22.370 | 23.717 | 9.2% | 3.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 21.105 |
| scalar | 1000000 | clean | default | 64MB | or_columns | hash (partial) | 10 | 21.672 | 20.550–23.238 | 23.778 | 7.0% | 2.95 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 21.708 |
| scalar | 1000000 | clean | default | 64MB | or_columns | roaring | 10 | 19.389 | 18.763–20.192 | 21.774 | 6.4% | 3.29 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 19.430 |
| scalar | 1000000 | clean | default | 64MB | or_columns | roaring_bitmap | 10 | 19.732 | 18.855–20.805 | 21.263 | 5.2% | 3.24 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 19.775 |
| scalar | 1000000 | clean | default | 64MB | or_columns | seq | 10 | 63.862 | 58.470–65.630 | 66.070 | 5.8% | 1.00 | Seq Scan | 0.036 | 63.902 |
| scalar | 1000000 | clean | default | 64MB | ordered_limit | brin | 10 | 86.308 | 82.120–88.555 | 94.124 | 5.9% | 0.99 | Seq Scan (fallback) | 0.053 | 86.360 |
| scalar | 1000000 | clean | default | 64MB | ordered_limit | btree | 10 | 0.018 | 0.018–0.019 | 0.019 | 4.3% | 4744.75 | Index Only Scan | 0.054 | 0.072 |
| scalar | 1000000 | clean | default | 64MB | ordered_limit | btree_tuned | 10 | 0.018 | 0.018–0.018 | 0.019 | 2.3% | 4744.75 | Index Only Scan | 0.055 | 0.073 |
| scalar | 1000000 | clean | default | 64MB | ordered_limit | gin | 10 | 84.483 | 81.609–95.155 | 97.258 | 7.8% | 1.01 | Seq Scan (fallback) | 0.042 | 84.524 |
| scalar | 1000000 | clean | default | 64MB | ordered_limit | gist | 10 | 139.486 | 136.923–144.125 | 148.415 | 3.3% | 0.61 | Index Only Scan | 0.041 | 139.541 |
| scalar | 1000000 | clean | default | 64MB | ordered_limit | hash (partial) | 10 | 85.875 | 82.968–87.993 | 88.285 | 3.0% | 0.99 | Seq Scan (fallback) | 0.038 | 85.911 |
| scalar | 1000000 | clean | default | 64MB | ordered_limit | roaring | 10 | 86.665 | 81.822–88.299 | 88.463 | 3.9% | 0.99 | Seq Scan (fallback) | 0.036 | 86.701 |
| scalar | 1000000 | clean | default | 64MB | ordered_limit | roaring_bitmap | 10 | 86.547 | 84.981–89.018 | 89.559 | 2.6% | 0.99 | Seq Scan (fallback) | 0.038 | 86.589 |
| scalar | 1000000 | clean | default | 64MB | ordered_limit | seq | 10 | 85.406 | 83.229–87.373 | 93.753 | 5.4% | 1.00 | Seq Scan | 0.036 | 85.440 |
| scalar | 1000000 | clean | default | 64MB | range_broad | brin | 10 | 78.491 | 76.779–81.890 | 86.107 | 4.7% | 1.04 | Seq Scan (fallback) | 0.057 | 78.548 |
| scalar | 1000000 | clean | default | 64MB | range_broad | btree | 10 | 31.724 | 30.450–31.965 | 32.462 | 3.3% | 2.58 | Index Only Scan | 0.055 | 31.783 |
| scalar | 1000000 | clean | default | 64MB | range_broad | btree_tuned | 10 | 30.178 | 29.835–31.324 | 32.190 | 3.2% | 2.71 | Index Only Scan | 0.054 | 30.240 |
| scalar | 1000000 | clean | default | 64MB | range_broad | gin | 10 | 183.709 | 175.272–188.522 | 193.077 | 4.0% | 0.45 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 183.774 |
| scalar | 1000000 | clean | default | 64MB | range_broad | gist | 10 | 82.659 | 80.542–83.333 | 87.198 | 3.6% | 0.99 | Index Only Scan | 0.042 | 82.703 |
| scalar | 1000000 | clean | default | 64MB | range_broad | hash (partial) | 10 | 79.269 | 77.520–82.290 | 83.964 | 4.0% | 1.03 | Seq Scan (fallback) | 0.037 | 79.304 |
| scalar | 1000000 | clean | default | 64MB | range_broad | roaring | 10 | 79.514 | 77.108–82.245 | 83.521 | 3.7% | 1.03 | Seq Scan (fallback) | 0.041 | 79.555 |
| scalar | 1000000 | clean | default | 64MB | range_broad | roaring_bitmap | 10 | 76.949 | 76.255–79.986 | 81.341 | 3.1% | 1.06 | Seq Scan (fallback) | 0.041 | 76.992 |
| scalar | 1000000 | clean | default | 64MB | range_broad | seq | 10 | 81.840 | 77.309–86.808 | 91.690 | 7.0% | 1.00 | Seq Scan | 0.040 | 81.885 |
| scalar | 1000000 | clean | default | 64MB | range_clustered | brin | 10 | 6.061 | 5.701–6.258 | 7.882 | 16.0% | 9.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 6.116 |
| scalar | 1000000 | clean | default | 64MB | range_clustered | btree | 10 | 3.111 | 3.037–3.279 | 4.138 | 16.7% | 19.05 | Index Only Scan | 0.042 | 3.152 |
| scalar | 1000000 | clean | default | 64MB | range_clustered | btree_tuned | 10 | 3.101 | 3.067–3.239 | 3.363 | 3.9% | 19.11 | Index Only Scan | 0.044 | 3.145 |
| scalar | 1000000 | clean | default | 64MB | range_clustered | gin | 10 | 17.675 | 17.079–20.338 | 22.753 | 12.5% | 3.35 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 17.736 |
| scalar | 1000000 | clean | default | 64MB | range_clustered | gist | 10 | 7.753 | 7.706–8.142 | 8.690 | 5.4% | 7.64 | Index Only Scan | 0.042 | 7.795 |
| scalar | 1000000 | clean | default | 64MB | range_clustered | hash (partial) | 10 | 59.279 | 57.918–62.472 | 63.921 | 4.7% | 1.00 | Seq Scan (fallback) | 0.052 | 59.329 |
| scalar | 1000000 | clean | default | 64MB | range_clustered | roaring | 10 | 63.038 | 59.536–63.792 | 65.213 | 4.2% | 0.94 | Seq Scan (fallback) | 0.040 | 63.079 |
| scalar | 1000000 | clean | default | 64MB | range_clustered | roaring_bitmap | 10 | 59.086 | 56.754–61.428 | 63.736 | 5.1% | 1.00 | Seq Scan (fallback) | 0.039 | 59.140 |
| scalar | 1000000 | clean | default | 64MB | range_clustered | seq | 10 | 59.258 | 58.084–62.016 | 66.037 | 5.4% | 1.00 | Seq Scan | 0.035 | 59.295 |
| scalar | 1000000 | clean | default | 64MB | range_random | brin | 10 | 81.407 | 79.276–82.558 | 83.700 | 3.3% | 0.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 81.460 |
| scalar | 1000000 | clean | default | 64MB | range_random | btree | 10 | 0.303 | 0.299–0.323 | 0.335 | 4.8% | 176.45 | Index Only Scan | 0.057 | 0.362 |
| scalar | 1000000 | clean | default | 64MB | range_random | btree_tuned | 10 | 0.305 | 0.300–0.318 | 0.329 | 3.9% | 175.29 | Index Only Scan | 0.054 | 0.365 |
| scalar | 1000000 | clean | default | 64MB | range_random | gin | 10 | 41.002 | 38.664–43.700 | 44.055 | 6.2% | 1.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 41.061 |
| scalar | 1000000 | clean | default | 64MB | range_random | gist | 10 | 0.825 | 0.798–0.847 | 0.866 | 3.8% | 64.91 | Index Only Scan | 0.042 | 0.869 |
| scalar | 1000000 | clean | default | 64MB | range_random | hash (partial) | 10 | 54.707 | 52.870–57.693 | 59.375 | 4.6% | 0.98 | Seq Scan (fallback) | 0.036 | 54.744 |
| scalar | 1000000 | clean | default | 64MB | range_random | roaring | 10 | 56.209 | 54.206–58.404 | 58.978 | 4.2% | 0.95 | Seq Scan (fallback) | 0.038 | 56.245 |
| scalar | 1000000 | clean | default | 64MB | range_random | roaring_bitmap | 10 | 54.865 | 53.668–56.915 | 58.118 | 4.0% | 0.98 | Seq Scan (fallback) | 0.042 | 54.916 |
| scalar | 1000000 | clean | default | 64MB | range_random | seq | 10 | 53.552 | 52.861–59.105 | 60.278 | 6.0% | 1.00 | Seq Scan | 0.034 | 53.584 |
| scalar | 1000000 | clean | default | 64MB | residual_filter | brin | 10 | 74.472 | 71.780–78.311 | 81.035 | 5.6% | 0.76 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 74.562 |
| scalar | 1000000 | clean | default | 64MB | residual_filter | btree | 10 | 3.803 | 3.163–4.214 | 4.908 | 18.9% | 14.81 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.845 |
| scalar | 1000000 | clean | default | 64MB | residual_filter | btree_tuned | 10 | 0.607 | 0.580–0.640 | 0.755 | 12.2% | 92.72 | Index Only Scan | 0.046 | 0.658 |
| scalar | 1000000 | clean | default | 64MB | residual_filter | gin | 10 | 3.837 | 3.404–4.125 | 4.262 | 10.5% | 14.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 3.881 |
| scalar | 1000000 | clean | default | 64MB | residual_filter | gist | 10 | 3.745 | 3.048–4.538 | 5.076 | 21.0% | 15.04 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.784 |
| scalar | 1000000 | clean | default | 64MB | residual_filter | hash (partial) | 10 | 3.670 | 3.436–4.202 | 4.703 | 15.0% | 15.35 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 3.716 |
| scalar | 1000000 | clean | default | 64MB | residual_filter | roaring | 10 | 3.225 | 2.933–3.520 | 3.570 | 8.8% | 17.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.267 |
| scalar | 1000000 | clean | default | 64MB | residual_filter | roaring_bitmap | 10 | 3.370 | 2.794–3.542 | 3.657 | 10.9% | 16.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.410 |
| scalar | 1000000 | clean | default | 64MB | residual_filter | seq | 10 | 56.326 | 55.564–58.529 | 59.408 | 3.3% | 1.00 | Seq Scan | 0.040 | 56.366 |
| scalar | 1000000 | clean | prefer_index | 64MB | and2 | brin | 10 | 72.519 | 70.188–76.116 | 78.180 | 5.2% | 0.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 72.596 |
| scalar | 1000000 | clean | prefer_index | 64MB | and2 | btree | 10 | 3.418 | 2.868–4.346 | 4.776 | 22.6% | 13.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.460 |
| scalar | 1000000 | clean | prefer_index | 64MB | and2 | btree_tuned | 10 | 0.193 | 0.190–0.202 | 0.244 | 13.1% | 242.54 | Index Only Scan | 0.048 | 0.238 |
| scalar | 1000000 | clean | prefer_index | 64MB | and2 | gin | 10 | 35.759 | 34.447–38.073 | 40.958 | 7.4% | 1.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 35.805 |
| scalar | 1000000 | clean | prefer_index | 64MB | and2 | gist | 10 | 4.226 | 2.944–4.399 | 4.518 | 18.9% | 11.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 4.279 |
| scalar | 1000000 | clean | prefer_index | 64MB | and2 | hash (partial) | 10 | 3.894 | 3.413–4.060 | 4.114 | 12.1% | 12.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 3.933 |
| scalar | 1000000 | clean | prefer_index | 64MB | and2 | roaring | 10 | 0.354 | 0.344–0.372 | 0.385 | 5.3% | 132.23 | RoaringCount | 0.043 | 0.397 |
| scalar | 1000000 | clean | prefer_index | 64MB | and2 | roaring_bitmap | 10 | 3.083 | 2.761–3.170 | 3.298 | 8.6% | 15.18 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.130 |
| scalar | 1000000 | clean | prefer_index | 64MB | and2 | seq | 10 | 46.810 | 45.975–49.599 | 50.323 | 4.0% | 1.00 | Seq Scan | 0.036 | 46.844 |
| scalar | 1000000 | clean | prefer_index | 64MB | and3 | brin | 10 | 72.386 | 68.684–75.385 | 76.858 | 5.0% | 0.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 72.455 |
| scalar | 1000000 | clean | prefer_index | 64MB | and3 | btree | 10 | 2.875 | 2.748–3.283 | 4.053 | 17.9% | 16.40 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 2.928 |
| scalar | 1000000 | clean | prefer_index | 64MB | and3 | btree_tuned | 10 | 0.028 | 0.028–0.030 | 0.031 | 5.3% | 1684.46 | Index Only Scan | 0.052 | 0.081 |
| scalar | 1000000 | clean | prefer_index | 64MB | and3 | gin | 10 | 5.150 | 5.063–5.503 | 6.008 | 7.9% | 9.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 5.205 |
| scalar | 1000000 | clean | prefer_index | 64MB | and3 | gist | 10 | 4.003 | 3.934–4.228 | 4.605 | 7.7% | 11.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 4.067 |
| scalar | 1000000 | clean | prefer_index | 64MB | and3 | hash (partial) | 10 | 3.138 | 3.036–3.190 | 3.406 | 5.3% | 15.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 3.194 |
| scalar | 1000000 | clean | prefer_index | 64MB | and3 | roaring | 10 | 0.254 | 0.250–0.275 | 0.351 | 16.8% | 185.69 | RoaringCount | 0.051 | 0.307 |
| scalar | 1000000 | clean | prefer_index | 64MB | and3 | roaring_bitmap | 10 | 3.852 | 3.553–3.918 | 3.967 | 4.8% | 12.25 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 3.920 |
| scalar | 1000000 | clean | prefer_index | 64MB | and3 | seq | 10 | 47.165 | 45.632–50.024 | 51.989 | 5.7% | 1.00 | Seq Scan | 0.039 | 47.204 |
| scalar | 1000000 | clean | prefer_index | 64MB | count_distinct | brin | 10 | 75.776 | 70.635–81.082 | 87.198 | 8.6% | 0.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 75.845 |
| scalar | 1000000 | clean | prefer_index | 64MB | count_distinct | btree | 10 | 4.012 | 3.356–4.434 | 4.778 | 14.7% | 12.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 4.061 |
| scalar | 1000000 | clean | prefer_index | 64MB | count_distinct | btree_tuned | 10 | 4.745 | 4.276–4.870 | 4.981 | 11.4% | 10.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 4.796 |
| scalar | 1000000 | clean | prefer_index | 64MB | count_distinct | gin | 10 | 4.142 | 4.050–4.624 | 5.344 | 11.9% | 12.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 4.191 |
| scalar | 1000000 | clean | prefer_index | 64MB | count_distinct | gist | 10 | 4.742 | 4.097–4.923 | 5.238 | 14.5% | 10.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 4.787 |
| scalar | 1000000 | clean | prefer_index | 64MB | count_distinct | hash (partial) | 10 | 3.921 | 3.564–4.157 | 4.391 | 9.7% | 12.76 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 3.962 |
| scalar | 1000000 | clean | prefer_index | 64MB | count_distinct | roaring | 10 | 3.926 | 3.734–4.513 | 4.957 | 13.9% | 12.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.973 |
| scalar | 1000000 | clean | prefer_index | 64MB | count_distinct | roaring_bitmap | 10 | 3.667 | 3.348–3.856 | 4.179 | 10.6% | 13.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.724 |
| scalar | 1000000 | clean | prefer_index | 64MB | count_distinct | seq | 10 | 50.034 | 47.431–52.086 | 52.609 | 5.2% | 1.00 | Seq Scan | 0.040 | 50.071 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_absent | brin | 10 | 0.081 | 0.080–0.084 | 0.099 | 9.0% | 597.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 0.128 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_absent | btree | 10 | 0.017 | 0.017–0.018 | 0.018 | 3.7% | 2847.85 | Index Only Scan | 0.036 | 0.053 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_absent | btree_tuned | 10 | 0.018 | 0.017–0.019 | 0.023 | 13.6% | 2766.49 | Index Only Scan | 0.040 | 0.057 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_absent | gin | 10 | 0.018 | 0.017–0.023 | 0.026 | 19.9% | 2766.49 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 0.057 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_absent | gist | 10 | 0.016 | 0.014–0.018 | 0.104 | 156.1% | 3025.84 | Index Only Scan | 0.036 | 0.053 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_absent | hash (partial) | 10 | 0.017 | 0.017–0.018 | 0.018 | 3.3% | 2847.85 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 0.052 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_absent | roaring | 10 | 0.008 | 0.007–0.008 | 0.008 | 6.8% | 6051.69 | RoaringCount | 0.039 | 0.046 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_absent | roaring_bitmap | 10 | 0.017 | 0.017–0.019 | 0.022 | 12.8% | 2847.85 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 0.054 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_absent | seq | 10 | 48.413 | 47.596–51.483 | 54.840 | 6.5% | 1.00 | Seq Scan | 0.040 | 48.462 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_12345 | brin | 10 | 78.090 | 73.806–78.874 | 79.333 | 3.9% | 0.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 78.143 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_12345 | btree | 10 | 0.019 | 0.018–0.020 | 0.021 | 4.9% | 2717.79 | Index Only Scan | 0.035 | 0.054 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_12345 | btree_tuned | 10 | 0.020 | 0.019–0.022 | 0.024 | 8.6% | 2581.90 | Index Only Scan | 0.037 | 0.058 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_12345 | gin | 10 | 0.026 | 0.025–0.034 | 0.040 | 21.1% | 1948.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 0.070 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_12345 | gist | 10 | 0.039 | 0.038–0.045 | 0.056 | 18.9% | 1324.05 | Index Only Scan | 0.036 | 0.075 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_12345 | hash (partial) | 10 | 0.019 | 0.018–0.021 | 0.024 | 10.6% | 2648.10 | Index Scan | 0.037 | 0.057 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_12345 | roaring | 10 | 0.011 | 0.010–0.011 | 0.012 | 6.8% | 4694.36 | RoaringCount | 0.037 | 0.048 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_12345 | roaring_bitmap | 10 | 0.022 | 0.021–0.026 | 0.030 | 14.4% | 2347.18 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 0.056 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_12345 | seq | 10 | 51.638 | 50.248–55.117 | 56.533 | 5.3% | 1.00 | Seq Scan | 0.033 | 51.670 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_765432 | brin | 10 | 74.775 | 73.651–76.304 | 77.513 | 2.4% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 74.835 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_765432 | btree | 10 | 0.018 | 0.016–0.020 | 0.032 | 38.2% | 2946.31 | Index Only Scan | 0.034 | 0.053 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_765432 | btree_tuned | 10 | 0.018 | 0.017–0.021 | 0.041 | 52.0% | 2787.05 | Index Only Scan | 0.037 | 0.056 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_765432 | gin | 10 | 0.024 | 0.021–0.029 | 0.030 | 16.2% | 2194.06 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 0.075 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_765432 | gist | 10 | 0.033 | 0.032–0.038 | 0.042 | 11.6% | 1562.44 | Index Only Scan | 0.037 | 0.073 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_765432 | hash (partial) | 10 | 0.017 | 0.016–0.018 | 0.019 | 7.1% | 3032.97 | Index Scan | 0.032 | 0.049 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_765432 | roaring | 10 | 0.008 | 0.007–0.008 | 0.009 | 7.2% | 6445.06 | RoaringCount | 0.035 | 0.044 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_765432 | roaring_bitmap | 10 | 0.017 | 0.016–0.021 | 0.023 | 14.3% | 3032.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 0.053 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c1m_765432 | seq | 10 | 51.560 | 49.802–53.402 | 54.132 | 3.7% | 1.00 | Seq Scan | 0.033 | 51.592 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_103 | brin | 10 | 73.792 | 70.938–78.485 | 82.477 | 6.4% | 0.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 73.846 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_103 | btree | 10 | 0.344 | 0.312–0.461 | 0.587 | 28.2% | 140.03 | Index Only Scan | 0.036 | 0.385 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_103 | btree_tuned | 10 | 0.311 | 0.309–0.327 | 0.334 | 3.6% | 154.64 | Index Only Scan | 0.041 | 0.352 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_103 | gin | 10 | 3.764 | 3.620–3.824 | 3.868 | 5.2% | 12.80 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 3.819 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_103 | gist | 10 | 0.702 | 0.695–0.738 | 0.810 | 6.7% | 68.62 | Index Only Scan | 0.037 | 0.745 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_103 | hash (partial) | 10 | 3.698 | 3.345–3.813 | 4.139 | 11.7% | 13.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 3.744 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_103 | roaring | 10 | 0.028 | 0.027–0.030 | 0.032 | 6.9% | 1720.34 | RoaringCount | 0.038 | 0.067 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_103 | roaring_bitmap | 10 | 3.487 | 3.338–3.718 | 3.837 | 7.0% | 13.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 3.529 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_103 | seq | 10 | 48.169 | 46.432–50.691 | 54.356 | 7.0% | 1.00 | Seq Scan | 0.034 | 48.203 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_17 | brin | 10 | 70.721 | 69.106–75.385 | 78.358 | 5.6% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 70.762 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_17 | btree | 10 | 0.334 | 0.318–0.355 | 0.393 | 9.2% | 148.21 | Index Only Scan | 0.036 | 0.369 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_17 | btree_tuned | 10 | 0.325 | 0.321–0.345 | 0.361 | 5.1% | 152.09 | Index Only Scan | 0.041 | 0.366 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_17 | gin | 10 | 3.532 | 3.269–4.115 | 4.855 | 18.1% | 14.00 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 3.573 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_17 | gist | 10 | 0.745 | 0.726–0.807 | 1.032 | 17.7% | 66.35 | Index Only Scan | 0.036 | 0.784 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_17 | hash (partial) | 10 | 3.558 | 3.011–3.758 | 3.989 | 12.8% | 13.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 3.600 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_17 | roaring | 10 | 0.028 | 0.028–0.031 | 0.058 | 47.2% | 1765.34 | RoaringCount | 0.039 | 0.068 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_17 | roaring_bitmap | 10 | 3.069 | 2.665–3.208 | 3.984 | 19.0% | 16.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 3.104 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c200_17 | seq | 10 | 49.430 | 48.712–50.111 | 51.042 | 3.7% | 1.00 | Seq Scan | 0.030 | 49.459 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_17 | brin | 10 | 73.011 | 71.296–80.673 | 91.278 | 10.7% | 0.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 73.053 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_17 | btree | 10 | 3.202 | 3.113–3.354 | 3.448 | 4.3% | 15.09 | Index Only Scan | 0.037 | 3.239 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_17 | btree_tuned | 10 | 3.081 | 3.013–3.332 | 4.109 | 15.6% | 15.68 | Index Only Scan | 0.038 | 3.120 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_17 | gin | 10 | 20.629 | 19.672–20.982 | 21.455 | 4.2% | 2.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 20.672 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_17 | gist | 10 | 6.977 | 6.803–7.373 | 7.418 | 3.8% | 6.92 | Index Only Scan | 0.039 | 7.023 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_17 | hash (partial) | 10 | 19.822 | 19.041–20.297 | 20.758 | 4.6% | 2.44 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 19.855 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_17 | roaring | 10 | 0.062 | 0.061–0.069 | 0.084 | 14.8% | 779.28 | RoaringCount | 0.038 | 0.102 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_17 | roaring_bitmap | 10 | 18.137 | 17.921–18.898 | 21.680 | 10.0% | 2.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 18.171 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_17 | seq | 10 | 48.316 | 46.172–48.887 | 49.278 | 3.0% | 1.00 | Seq Scan | 0.030 | 48.349 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_3 | brin | 10 | 73.049 | 71.814–80.340 | 81.109 | 6.0% | 0.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 73.108 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_3 | btree | 10 | 3.096 | 3.062–3.191 | 5.050 | 31.0% | 16.93 | Index Only Scan | 0.037 | 3.135 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_3 | btree_tuned | 10 | 3.087 | 3.038–3.161 | 3.217 | 2.6% | 16.97 | Index Only Scan | 0.040 | 3.125 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_3 | gin | 10 | 19.791 | 19.391–20.452 | 21.424 | 4.2% | 2.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 19.828 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_3 | gist | 10 | 7.008 | 6.907–7.314 | 8.194 | 7.7% | 7.48 | Index Only Scan | 0.036 | 7.044 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_3 | hash (partial) | 10 | 20.081 | 19.758–21.113 | 23.099 | 6.6% | 2.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 20.120 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_3 | roaring | 10 | 0.062 | 0.061–0.070 | 0.079 | 11.3% | 845.30 | RoaringCount | 0.038 | 0.101 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_3 | roaring_bitmap | 10 | 18.239 | 17.867–18.620 | 19.074 | 3.0% | 2.87 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 18.274 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20_3 | seq | 10 | 52.409 | 49.347–54.639 | 57.685 | 7.9% | 1.00 | Seq Scan | 0.038 | 52.447 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_123 | brin | 10 | 73.790 | 70.196–76.947 | 78.970 | 5.5% | 0.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 73.846 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_123 | btree | 10 | 0.021 | 0.020–0.024 | 0.029 | 18.1% | 2330.29 | Index Only Scan | 0.036 | 0.057 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_123 | btree_tuned | 10 | 0.021 | 0.020–0.022 | 0.022 | 4.8% | 2330.29 | Index Only Scan | 0.037 | 0.058 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_123 | gin | 10 | 0.058 | 0.051–0.070 | 0.079 | 18.7% | 843.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 0.097 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_123 | gist | 10 | 0.043 | 0.042–0.051 | 0.067 | 21.7% | 1124.97 | Index Only Scan | 0.037 | 0.082 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_123 | hash (partial) | 10 | 0.060 | 0.053–0.068 | 0.097 | 33.2% | 808.86 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 0.095 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_123 | roaring | 10 | 0.013 | 0.012–0.013 | 0.016 | 12.9% | 3914.88 | RoaringCount | 0.038 | 0.051 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_123 | roaring_bitmap | 10 | 0.053 | 0.051–0.056 | 0.064 | 11.4% | 914.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 0.087 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_123 | seq | 10 | 48.936 | 47.907–52.731 | 56.385 | 6.8% | 1.00 | Seq Scan | 0.030 | 48.966 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_12345 | brin | 10 | 73.240 | 71.606–75.650 | 79.816 | 4.7% | 0.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 73.293 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_12345 | btree | 10 | 0.021 | 0.021–0.026 | 0.036 | 27.3% | 2305.47 | Index Only Scan | 0.036 | 0.057 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_12345 | btree_tuned | 10 | 0.021 | 0.020–0.022 | 0.023 | 6.9% | 2360.36 | Index Only Scan | 0.038 | 0.059 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_12345 | gin | 10 | 0.061 | 0.057–0.071 | 0.075 | 12.2% | 812.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 0.103 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_12345 | gist | 10 | 0.043 | 0.042–0.045 | 0.045 | 3.8% | 1139.48 | Index Only Scan | 0.041 | 0.085 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_12345 | hash (partial) | 10 | 0.062 | 0.054–0.067 | 0.076 | 18.0% | 793.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.033 | 0.096 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_12345 | roaring | 10 | 0.013 | 0.012–0.013 | 0.014 | 8.5% | 3965.40 | RoaringCount | 0.039 | 0.052 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_12345 | roaring_bitmap | 10 | 0.052 | 0.051–0.059 | 0.061 | 7.8% | 944.14 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 0.090 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c20k_12345 | seq | 10 | 49.567 | 48.171–52.094 | 55.745 | 6.3% | 1.00 | Seq Scan | 0.032 | 49.599 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_0 | brin | 10 | 92.488 | 89.874–97.195 | 100.018 | 4.7% | 0.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 92.534 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_0 | btree | 10 | 33.540 | 31.651–35.977 | 40.700 | 11.2% | 1.97 | Index Only Scan | 0.036 | 33.597 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_0 | btree_tuned | 10 | 31.067 | 30.335–33.919 | 36.472 | 8.1% | 2.13 | Index Only Scan | 0.042 | 31.108 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_0 | gin | 10 | 92.135 | 91.236–94.552 | 98.710 | 3.3% | 0.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 92.193 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_0 | gist | 10 | 73.438 | 70.536–75.055 | 77.833 | 4.4% | 0.90 | Index Only Scan | 0.036 | 73.473 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_0 | hash (partial) | 10 | 67.550 | 65.548–72.310 | 73.328 | 5.4% | 0.98 | Seq Scan (fallback) | 0.038 | 67.582 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_0 | roaring | 10 | 0.426 | 0.404–0.441 | 0.522 | 12.9% | 154.94 | RoaringCount | 0.037 | 0.469 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_0 | roaring_bitmap | 10 | 66.305 | 63.794–69.571 | 71.991 | 5.1% | 1.00 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 66.340 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_0 | seq | 10 | 66.084 | 65.048–69.543 | 71.786 | 4.4% | 1.00 | Seq Scan | 0.034 | 66.124 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_1 | brin | 10 | 95.288 | 92.936–97.512 | 98.035 | 2.5% | 0.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 95.346 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_1 | btree | 10 | 31.852 | 30.828–33.288 | 35.852 | 6.5% | 2.11 | Index Only Scan | 0.035 | 31.887 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_1 | btree_tuned | 10 | 31.172 | 30.548–32.413 | 33.665 | 4.1% | 2.16 | Index Only Scan | 0.041 | 31.213 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_1 | gin | 10 | 92.816 | 90.526–98.763 | 100.880 | 4.7% | 0.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 92.876 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_1 | gist | 10 | 72.020 | 69.493–73.385 | 75.856 | 3.5% | 0.94 | Index Only Scan | 0.034 | 72.055 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_1 | hash (partial) | 10 | 66.631 | 64.498–68.367 | 69.767 | 3.6% | 1.01 | Seq Scan (fallback) | 0.031 | 66.675 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_1 | roaring | 10 | 0.424 | 0.411–0.442 | 0.463 | 5.5% | 158.85 | RoaringCount | 0.040 | 0.469 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_1 | roaring_bitmap | 10 | 65.116 | 64.280–68.832 | 70.804 | 4.4% | 1.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 65.159 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_c2_1 | seq | 10 | 67.355 | 65.613–71.305 | 73.428 | 5.1% | 1.00 | Seq Scan | 0.033 | 67.386 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_103 | brin | 10 | 0.769 | 0.728–0.873 | 1.095 | 19.0% | 68.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 0.828 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_103 | btree | 10 | 0.323 | 0.317–0.364 | 0.373 | 7.4% | 162.39 | Index Only Scan | 0.036 | 0.358 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_103 | btree_tuned | 10 | 0.329 | 0.317–0.356 | 0.383 | 8.4% | 159.43 | Index Only Scan | 0.037 | 0.379 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_103 | gin | 10 | 0.688 | 0.679–0.726 | 0.787 | 6.2% | 76.29 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 0.734 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_103 | gist | 10 | 0.724 | 0.699–0.812 | 0.877 | 9.3% | 72.45 | Index Only Scan | 0.036 | 0.758 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_103 | hash (partial) | 10 | 0.666 | 0.641–0.683 | 0.691 | 3.8% | 78.76 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 0.708 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_103 | roaring | 10 | 0.011 | 0.010–0.011 | 0.125 | 208.0% | 4768.41 | RoaringCount | 0.038 | 0.049 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_103 | roaring_bitmap | 10 | 0.439 | 0.429–0.468 | 0.650 | 23.3% | 119.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.490 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_103 | seq | 10 | 52.453 | 51.539–55.144 | 57.867 | 4.8% | 1.00 | Seq Scan | 0.031 | 52.483 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_17 | brin | 10 | 0.739 | 0.713–0.754 | 0.766 | 3.2% | 74.10 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 0.788 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_17 | btree | 10 | 0.320 | 0.316–0.332 | 0.352 | 4.9% | 171.12 | Index Only Scan | 0.038 | 0.358 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_17 | btree_tuned | 10 | 0.323 | 0.310–0.334 | 0.355 | 5.5% | 169.53 | Index Only Scan | 0.038 | 0.366 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_17 | gin | 10 | 0.686 | 0.676–0.738 | 0.935 | 17.8% | 79.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 0.746 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_17 | gist | 10 | 0.726 | 0.714–0.783 | 0.809 | 5.5% | 75.48 | Index Only Scan | 0.036 | 0.761 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_17 | hash (partial) | 10 | 0.684 | 0.665–0.721 | 0.802 | 8.7% | 80.00 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 0.733 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_17 | roaring | 10 | 0.011 | 0.010–0.012 | 0.013 | 10.1% | 4978.05 | RoaringCount | 0.038 | 0.049 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_17 | roaring_bitmap | 10 | 0.443 | 0.433–0.460 | 0.482 | 4.6% | 123.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 0.483 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_clustered_17 | seq | 10 | 54.758 | 50.433–56.075 | 59.621 | 6.9% | 1.00 | Seq Scan | 0.030 | 54.867 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_nullable_17 | brin | 10 | 79.889 | 79.365–83.972 | 87.567 | 4.5% | 0.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 79.944 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_nullable_17 | btree | 10 | 0.299 | 0.293–0.372 | 0.479 | 22.6% | 189.72 | Index Only Scan | 0.036 | 0.342 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_nullable_17 | btree_tuned | 10 | 0.295 | 0.291–0.306 | 0.321 | 4.3% | 192.61 | Index Only Scan | 0.038 | 0.332 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_nullable_17 | gin | 10 | 3.451 | 3.268–3.529 | 4.182 | 12.8% | 16.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 3.515 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_nullable_17 | gist | 10 | 0.684 | 0.662–0.697 | 0.715 | 3.2% | 83.07 | Index Only Scan | 0.037 | 0.721 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_nullable_17 | hash (partial) | 10 | 3.373 | 3.076–3.635 | 3.873 | 9.7% | 16.85 | Bitmap Heap Scan, Bitmap Index Scan | 0.033 | 3.407 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_nullable_17 | roaring | 10 | 0.028 | 0.028–0.029 | 0.039 | 19.1% | 2029.30 | RoaringCount | 0.036 | 0.065 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_nullable_17 | roaring_bitmap | 10 | 3.237 | 3.112–3.282 | 3.675 | 9.4% | 17.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 3.268 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_nullable_17 | seq | 10 | 56.820 | 55.087–59.999 | 64.111 | 6.8% | 1.00 | Seq Scan | 0.036 | 56.861 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_0 | brin | 10 | 114.117 | 111.457–115.727 | 118.949 | 3.1% | 0.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 114.177 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_0 | btree | 10 | 57.142 | 55.177–58.809 | 59.092 | 3.0% | 1.47 | Index Only Scan | 0.036 | 57.185 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_0 | btree_tuned | 10 | 57.177 | 56.089–60.251 | 62.989 | 5.0% | 1.47 | Index Only Scan | 0.038 | 57.215 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_0 | gin | 10 | 133.275 | 129.922–139.161 | 142.029 | 3.7% | 0.63 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 133.317 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_0 | gist | 10 | 132.316 | 126.822–135.940 | 136.729 | 3.5% | 0.64 | Index Only Scan | 0.036 | 132.360 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_0 | hash (partial) | 10 | 84.228 | 82.783–88.157 | 91.744 | 4.7% | 1.00 | Seq Scan (fallback) | 0.035 | 84.264 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_0 | roaring | 10 | 0.159 | 0.157–0.178 | 0.213 | 13.9% | 528.86 | RoaringCount | 0.039 | 0.214 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_0 | roaring_bitmap | 10 | 86.969 | 85.967–88.160 | 90.120 | 2.0% | 0.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 87.002 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_0 | seq | 10 | 84.090 | 82.641–88.301 | 90.307 | 3.9% | 1.00 | Seq Scan | 0.033 | 84.127 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_17 | brin | 10 | 81.053 | 77.343–83.802 | 86.533 | 5.0% | 0.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 81.129 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_17 | btree | 10 | 0.026 | 0.025–0.027 | 0.028 | 4.8% | 2128.92 | Index Only Scan | 0.037 | 0.064 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_17 | btree_tuned | 10 | 0.027 | 0.024–0.037 | 0.045 | 27.6% | 2050.07 | Index Only Scan | 0.038 | 0.067 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_17 | gin | 10 | 0.103 | 0.101–0.113 | 0.117 | 6.3% | 534.80 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 0.144 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_17 | gist | 10 | 0.054 | 0.054–0.058 | 0.064 | 7.3% | 1015.63 | Index Only Scan | 0.035 | 0.089 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_17 | hash (partial) | 10 | 56.153 | 53.360–57.193 | 62.560 | 7.0% | 0.99 | Seq Scan (fallback) | 0.037 | 56.189 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_17 | roaring | 10 | 0.016 | 0.015–0.018 | 0.023 | 19.6% | 3459.50 | RoaringCount | 0.040 | 0.056 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_17 | roaring_bitmap | 10 | 0.104 | 0.093–0.115 | 0.139 | 17.4% | 529.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 0.150 |
| scalar | 1000000 | clean | prefer_index | 64MB | eq_skew_17 | seq | 10 | 55.352 | 51.684–57.055 | 58.764 | 5.3% | 1.00 | Seq Scan | 0.033 | 55.389 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_clustered | brin | 10 | 0.838 | 0.819–0.892 | 0.938 | 5.8% | 65.29 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 0.889 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_clustered | btree | 10 | 0.643 | 0.623–0.701 | 0.767 | 8.9% | 85.03 | Index Scan | 0.041 | 0.683 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_clustered | btree_tuned | 10 | 0.670 | 0.657–0.680 | 0.699 | 3.6% | 81.67 | Index Scan | 0.043 | 0.716 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_clustered | gin | 10 | 0.849 | 0.835–0.881 | 0.955 | 6.2% | 64.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.909 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_clustered | gist | 10 | 0.782 | 0.765–0.874 | 0.877 | 6.3% | 70.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 0.841 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_clustered | hash (partial) | 10 | 0.814 | 0.760–0.876 | 1.136 | 19.5% | 67.26 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 0.873 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_clustered | roaring | 10 | 0.612 | 0.591–0.633 | 0.695 | 7.5% | 89.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 0.653 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_clustered | roaring_bitmap | 10 | 0.616 | 0.608–0.646 | 0.779 | 12.5% | 88.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 0.661 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_clustered | seq | 10 | 54.716 | 52.703–55.519 | 55.848 | 2.8% | 1.00 | Seq Scan | 0.037 | 54.768 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_medium | brin | 10 | 73.456 | 72.193–75.284 | 76.088 | 3.0% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 73.508 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_medium | btree | 10 | 3.651 | 2.909–4.428 | 5.248 | 25.2% | 13.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.692 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_medium | btree_tuned | 10 | 0.591 | 0.577–0.613 | 0.634 | 4.1% | 85.17 | Index Only Scan | 0.044 | 0.641 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_medium | gin | 10 | 3.798 | 3.519–4.153 | 4.377 | 12.2% | 13.25 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 3.851 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_medium | gist | 10 | 4.600 | 3.148–4.758 | 4.971 | 21.0% | 10.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 4.661 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_medium | hash (partial) | 10 | 3.574 | 3.206–4.018 | 4.202 | 12.5% | 14.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 3.620 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_medium | roaring | 10 | 3.543 | 3.118–4.128 | 4.787 | 18.9% | 14.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.583 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_medium | roaring_bitmap | 10 | 3.309 | 3.061–3.506 | 3.526 | 7.7% | 15.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.349 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_medium | seq | 10 | 50.337 | 46.337–54.181 | 57.321 | 8.5% | 1.00 | Seq Scan | 0.038 | 50.374 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_rare | brin | 10 | 71.588 | 70.258–74.567 | 75.774 | 3.8% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 71.656 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_rare | btree | 10 | 0.068 | 0.060–0.080 | 0.087 | 16.1% | 728.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 0.110 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_rare | btree_tuned | 10 | 0.072 | 0.067–0.089 | 0.100 | 18.3% | 682.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.119 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_rare | gin | 10 | 0.066 | 0.060–0.074 | 0.079 | 15.6% | 750.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 0.111 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_rare | gist | 10 | 0.098 | 0.089–0.102 | 0.108 | 10.1% | 507.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 0.139 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_rare | hash (partial) | 10 | 0.062 | 0.057–0.068 | 0.084 | 16.8% | 792.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 0.100 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_rare | roaring | 10 | 0.063 | 0.060–0.074 | 0.081 | 13.5% | 785.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 0.105 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_rare | roaring_bitmap | 10 | 0.066 | 0.058–0.071 | 0.078 | 16.7% | 750.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.108 |
| scalar | 1000000 | clean | prefer_index | 64MB | fetch_rare | seq | 10 | 49.505 | 48.181–51.458 | 56.719 | 7.4% | 1.00 | Seq Scan | 0.038 | 49.544 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c2 | brin | 10 | 135.888 | 131.724–141.226 | 143.809 | 4.1% | 1.01 | Seq Scan (fallback) | 0.044 | 135.947 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c2 | btree | 10 | 84.779 | 81.749–88.965 | 93.332 | 5.6% | 1.62 | Index Only Scan | 0.040 | 84.818 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c2 | btree_tuned | 10 | 84.597 | 81.112–88.354 | 92.893 | 6.2% | 1.62 | Index Only Scan | 0.043 | 84.657 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c2 | gin | 10 | 132.921 | 132.170–144.729 | 149.537 | 5.9% | 1.03 | Seq Scan (fallback) | 0.035 | 132.963 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c2 | gist | 10 | 201.325 | 197.024–204.106 | 206.914 | 2.5% | 0.68 | Index Only Scan | 0.036 | 201.372 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c2 | hash (partial) | 10 | 131.413 | 129.120–133.188 | 138.058 | 3.1% | 1.04 | Seq Scan (fallback) | 0.033 | 131.452 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c2 | roaring | 10 | 0.836 | 0.807–0.868 | 0.892 | 4.3% | 164.14 | RoaringCount | 0.035 | 0.875 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c2 | roaring_bitmap | 10 | 133.829 | 131.769–137.170 | 139.269 | 2.5% | 1.03 | Seq Scan (fallback) | 0.036 | 133.872 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c2 | seq | 10 | 137.223 | 133.176–139.649 | 140.842 | 3.1% | 1.00 | Seq Scan | 0.036 | 137.266 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20 | brin | 10 | 142.108 | 139.163–145.456 | 146.977 | 2.4% | 1.06 | Seq Scan (fallback) | 0.050 | 142.163 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20 | btree | 10 | 83.016 | 80.612–86.879 | 88.240 | 3.9% | 1.81 | Index Only Scan | 0.038 | 83.052 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20 | btree_tuned | 10 | 84.663 | 82.508–88.331 | 90.071 | 4.5% | 1.78 | Index Only Scan | 0.043 | 84.714 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20 | gin | 10 | 143.755 | 141.274–151.227 | 163.214 | 6.1% | 1.05 | Seq Scan (fallback) | 0.041 | 143.805 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20 | gist | 10 | 200.678 | 193.852–210.587 | 218.277 | 5.0% | 0.75 | Index Only Scan | 0.036 | 200.722 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20 | hash (partial) | 10 | 144.359 | 141.394–147.039 | 150.198 | 2.8% | 1.04 | Seq Scan (fallback) | 0.034 | 144.407 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20 | roaring | 10 | 1.117 | 1.066–1.134 | 1.159 | 3.6% | 134.90 | RoaringCount | 0.036 | 1.151 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20 | roaring_bitmap | 10 | 141.433 | 139.474–144.594 | 145.822 | 2.2% | 1.06 | Seq Scan (fallback) | 0.035 | 141.473 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20 | seq | 10 | 150.611 | 148.433–153.600 | 156.164 | 2.2% | 1.00 | Seq Scan | 0.039 | 150.654 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c200 | brin | 10 | 154.755 | 149.457–158.885 | 168.712 | 5.3% | 1.01 | Seq Scan (fallback) | 0.044 | 154.805 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c200 | btree | 10 | 85.131 | 79.195–85.308 | 86.031 | 4.0% | 1.83 | Index Only Scan | 0.040 | 85.169 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c200 | btree_tuned | 10 | 82.415 | 79.729–85.759 | 86.825 | 3.7% | 1.89 | Index Only Scan | 0.043 | 82.464 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c200 | gin | 10 | 155.430 | 152.649–158.953 | 164.224 | 3.0% | 1.00 | Seq Scan (fallback) | 0.049 | 155.494 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c200 | gist | 10 | 197.291 | 195.199–205.204 | 212.450 | 3.7% | 0.79 | Index Only Scan | 0.036 | 197.327 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c200 | hash (partial) | 10 | 148.865 | 145.435–152.123 | 156.460 | 3.1% | 1.04 | Seq Scan (fallback) | 0.033 | 148.907 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c200 | roaring | 10 | 3.845 | 3.804–3.983 | 4.137 | 3.5% | 40.46 | RoaringCount | 0.035 | 3.895 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c200 | roaring_bitmap | 10 | 150.007 | 147.584–155.917 | 157.630 | 2.9% | 1.04 | Seq Scan (fallback) | 0.038 | 150.041 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c200 | seq | 10 | 155.560 | 152.247–157.844 | 160.442 | 2.7% | 1.00 | Seq Scan | 0.037 | 155.598 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20k | brin | 10 | 178.102 | 175.928–183.614 | 185.889 | 2.6% | 1.03 | Seq Scan (fallback) | 0.051 | 178.171 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20k | btree | 10 | 89.446 | 85.177–91.808 | 94.714 | 4.9% | 2.05 | Index Only Scan | 0.038 | 89.487 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20k | btree_tuned | 10 | 88.695 | 85.697–90.561 | 93.974 | 4.3% | 2.07 | Index Only Scan | 0.042 | 88.763 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20k | gin | 10 | 179.924 | 176.810–185.646 | 190.810 | 3.4% | 1.02 | Seq Scan (fallback) | 0.035 | 179.960 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20k | gist | 10 | 207.640 | 200.516–211.724 | 216.780 | 3.3% | 0.88 | Index Only Scan | 0.036 | 207.674 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20k | hash (partial) | 10 | 177.910 | 174.311–180.553 | 184.392 | 2.5% | 1.03 | Seq Scan (fallback) | 0.044 | 177.946 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20k | roaring | 10 | 62.209 | 58.186–64.767 | 65.779 | 5.3% | 2.95 | RoaringCount | 0.033 | 62.244 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20k | roaring_bitmap | 10 | 179.145 | 178.064–181.564 | 184.747 | 1.5% | 1.03 | Seq Scan (fallback) | 0.039 | 179.179 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_c20k | seq | 10 | 183.719 | 179.604–187.686 | 191.626 | 2.9% | 1.00 | Seq Scan | 0.033 | 183.750 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_filtered | brin | 10 | 77.481 | 74.391–81.752 | 84.957 | 6.6% | 0.63 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 77.548 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_filtered | btree | 10 | 3.877 | 3.297–4.260 | 4.546 | 14.3% | 12.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 3.936 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_filtered | btree_tuned | 10 | 0.459 | 0.444–0.471 | 0.480 | 3.6% | 105.91 | Index Only Scan | 0.055 | 0.514 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_filtered | gin | 10 | 4.105 | 3.694–4.238 | 4.368 | 8.5% | 11.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 4.151 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_filtered | gist | 10 | 4.647 | 3.226–4.976 | 5.093 | 19.0% | 10.45 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 4.706 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_filtered | hash (partial) | 10 | 3.741 | 3.360–4.180 | 4.477 | 12.6% | 12.98 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.802 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_filtered | roaring | 10 | 2.505 | 2.427–2.658 | 2.757 | 5.2% | 19.39 | RoaringCount | 0.045 | 2.551 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_filtered | roaring_bitmap | 10 | 3.442 | 3.220–3.630 | 3.733 | 8.2% | 14.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 3.508 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_filtered | seq | 10 | 48.561 | 47.715–51.469 | 53.084 | 5.0% | 1.00 | Seq Scan | 0.040 | 48.599 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_nullable | brin | 10 | 162.764 | 155.085–167.165 | 172.640 | 5.0% | 0.99 | Seq Scan (fallback) | 0.051 | 162.806 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_nullable | btree | 10 | 81.702 | 79.248–85.030 | 88.340 | 4.7% | 1.98 | Index Only Scan | 0.040 | 81.741 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_nullable | btree_tuned | 10 | 82.998 | 81.028–87.062 | 89.613 | 4.5% | 1.94 | Index Only Scan | 0.042 | 83.040 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_nullable | gin | 10 | 157.168 | 152.719–160.619 | 162.905 | 2.5% | 1.03 | Seq Scan (fallback) | 0.039 | 157.213 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_nullable | gist | 10 | 200.593 | 197.692–203.323 | 206.147 | 1.9% | 0.80 | Index Only Scan | 0.036 | 200.627 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_nullable | hash (partial) | 10 | 156.847 | 153.555–161.678 | 165.063 | 3.3% | 1.03 | Seq Scan (fallback) | 0.048 | 156.904 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_nullable | roaring | 10 | 3.973 | 3.865–4.092 | 4.313 | 4.7% | 40.62 | RoaringCount | 0.036 | 4.007 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_nullable | roaring_bitmap | 10 | 160.679 | 154.762–164.652 | 166.704 | 3.2% | 1.00 | Seq Scan (fallback) | 0.035 | 160.714 |
| scalar | 1000000 | clean | prefer_index | 64MB | group_nullable | seq | 10 | 161.375 | 157.680–162.802 | 163.537 | 1.8% | 1.00 | Seq Scan | 0.039 | 161.414 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_and | brin | 10 | 95.737 | 93.623–101.364 | 110.059 | 6.8% | 0.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 95.802 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_and | btree | 10 | 7.474 | 6.905–7.921 | 9.797 | 15.7% | 9.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 7.525 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_and | btree_tuned | 10 | 0.190 | 0.176–0.230 | 0.252 | 15.1% | 376.20 | Index Only Scan | 0.055 | 0.254 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_and | gin | 10 | 14.788 | 14.067–15.728 | 17.264 | 8.8% | 4.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 14.841 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_and | gist | 10 | 11.287 | 10.781–11.651 | 12.221 | 5.6% | 6.33 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 11.347 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_and | hash (partial) | 10 | 8.533 | 7.988–8.650 | 8.949 | 4.7% | 8.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 8.584 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_and | roaring | 10 | 2.002 | 1.927–2.139 | 2.200 | 6.0% | 35.70 | RoaringCount | 0.053 | 2.055 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_and | roaring_bitmap | 10 | 7.933 | 7.758–8.043 | 8.193 | 2.8% | 9.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 7.995 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_and | seq | 10 | 71.478 | 69.899–75.490 | 77.854 | 5.3% | 1.00 | Seq Scan | 0.046 | 71.520 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_10 | brin | 10 | 59.245 | 56.300–63.486 | 64.346 | 5.8% | 1.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 59.311 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_10 | btree | 10 | 0.051 | 0.050–0.056 | 0.059 | 7.2% | 1339.28 | Index Only Scan | 0.045 | 0.096 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_10 | btree_tuned | 10 | 0.050 | 0.050–0.071 | 0.101 | 35.7% | 1379.46 | Index Only Scan | 0.046 | 0.096 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_10 | gin | 10 | 0.435 | 0.411–0.450 | 0.483 | 7.5% | 158.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 0.483 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_10 | gist | 10 | 0.701 | 0.578–0.750 | 0.896 | 19.7% | 98.39 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 0.744 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_10 | hash (partial) | 10 | 0.470 | 0.434–0.501 | 0.510 | 8.1% | 146.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 0.526 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_10 | roaring | 10 | 0.071 | 0.068–0.075 | 0.078 | 5.6% | 978.34 | RoaringCount | 0.055 | 0.125 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_10 | roaring_bitmap | 10 | 0.421 | 0.379–0.436 | 0.453 | 9.5% | 163.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 0.479 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_10 | seq | 10 | 68.973 | 65.867–70.858 | 75.220 | 5.6% | 1.00 | Seq Scan | 0.036 | 69.013 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_100 | brin | 10 | 153.119 | 147.870–154.452 | 155.632 | 2.8% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.094 | 153.219 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_100 | btree | 10 | 0.335 | 0.316–0.350 | 0.366 | 6.0% | 251.57 | Index Only Scan | 0.081 | 0.420 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_100 | btree_tuned | 10 | 0.320 | 0.315–0.344 | 0.369 | 6.9% | 263.38 | Index Only Scan | 0.082 | 0.403 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_100 | gin | 10 | 3.579 | 3.369–3.951 | 4.394 | 13.3% | 23.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.096 | 3.679 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_100 | gist | 10 | 5.743 | 5.301–6.198 | 6.404 | 10.1% | 14.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.093 | 5.824 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_100 | hash (partial) | 10 | 3.994 | 3.607–4.109 | 4.171 | 8.1% | 21.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.090 | 4.085 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_100 | roaring | 10 | 0.648 | 0.599–0.702 | 0.834 | 14.8% | 129.86 | RoaringCount | 0.119 | 0.768 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_100 | roaring_bitmap | 10 | 3.479 | 3.271–3.621 | 3.895 | 7.5% | 24.19 | Bitmap Heap Scan, Bitmap Index Scan | 0.085 | 3.562 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_100 | seq | 10 | 84.150 | 81.730–85.420 | 97.017 | 8.8% | 1.00 | Seq Scan | 0.060 | 84.210 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_1000 | brin | 10 | 495.591 | 484.316–508.401 | 522.061 | 3.3% | 0.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.476 | 496.052 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_1000 | btree | 10 | 3.165 | 3.074–3.381 | 3.497 | 5.6% | 24.36 | Index Only Scan | 0.458 | 3.656 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_1000 | btree_tuned | 10 | 3.067 | 3.045–3.264 | 3.502 | 6.0% | 25.14 | Index Only Scan | 0.444 | 3.534 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_1000 | gin | 10 | 21.713 | 21.367–24.091 | 25.112 | 7.2% | 3.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.615 | 22.395 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_1000 | gist | 10 | 39.373 | 38.605–41.100 | 42.768 | 4.3% | 1.96 | Bitmap Heap Scan, Bitmap Index Scan | 0.446 | 39.835 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_1000 | hash (partial) | 10 | 23.003 | 22.474–25.746 | 27.256 | 8.7% | 3.35 | Bitmap Heap Scan, Bitmap Index Scan | 0.477 | 23.639 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_1000 | roaring | 10 | 15.578 | 14.774–16.392 | 16.826 | 6.2% | 4.95 | RoaringCount | 0.901 | 16.567 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_1000 | roaring_bitmap | 10 | 20.076 | 19.526–21.091 | 23.407 | 8.6% | 3.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.515 | 20.639 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_1000 | seq | 10 | 77.093 | 71.396–80.114 | 86.310 | 7.7% | 1.00 | Seq Scan | 0.307 | 77.429 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_3 | brin | 10 | 21.265 | 21.101–24.508 | 28.248 | 12.9% | 3.49 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 21.329 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_3 | btree | 10 | 0.028 | 0.027–0.029 | 0.031 | 5.8% | 2649.77 | Index Only Scan | 0.042 | 0.071 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_3 | btree_tuned | 10 | 0.028 | 0.027–0.030 | 0.040 | 21.4% | 2649.77 | Index Only Scan | 0.042 | 0.072 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_3 | gin | 10 | 0.150 | 0.143–0.175 | 0.197 | 13.8% | 492.98 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 0.214 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_3 | gist | 10 | 0.226 | 0.192–0.263 | 0.278 | 19.0% | 329.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.268 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_3 | hash (partial) | 10 | 0.137 | 0.119–0.162 | 0.170 | 16.3% | 543.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 0.174 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_3 | roaring | 10 | 0.025 | 0.024–0.028 | 0.028 | 8.1% | 3028.31 | RoaringCount | 0.044 | 0.070 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_3 | roaring_bitmap | 10 | 0.131 | 0.126–0.162 | 0.179 | 15.7% | 568.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 0.173 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_c20k_3 | seq | 10 | 74.194 | 70.912–76.419 | 80.569 | 6.0% | 1.00 | Seq Scan | 0.036 | 74.233 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_overlap | brin | 10 | 96.933 | 95.081–102.602 | 104.254 | 4.5% | 0.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 96.988 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_overlap | btree | 10 | 0.652 | 0.628–0.748 | 0.823 | 11.7% | 117.81 | Index Only Scan | 0.040 | 0.691 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_overlap | btree_tuned | 10 | 0.651 | 0.639–0.708 | 0.737 | 6.4% | 117.90 | Index Only Scan | 0.046 | 0.693 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_overlap | gin | 10 | 6.729 | 6.399–7.328 | 7.585 | 7.1% | 11.42 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 6.777 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_overlap | gist | 10 | 7.296 | 6.279–7.660 | 7.841 | 10.9% | 10.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 7.338 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_overlap | hash (partial) | 10 | 6.574 | 6.261–6.908 | 7.829 | 10.6% | 11.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 6.619 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_overlap | roaring | 10 | 0.095 | 0.093–0.115 | 0.154 | 24.8% | 812.86 | RoaringCount | 0.042 | 0.138 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_overlap | roaring_bitmap | 10 | 6.350 | 5.904–7.154 | 7.414 | 12.8% | 12.10 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 6.401 |
| scalar | 1000000 | clean | prefer_index | 64MB | in_overlap | seq | 10 | 76.815 | 76.020–79.786 | 82.385 | 4.8% | 1.00 | Seq Scan | 0.044 | 76.856 |
| scalar | 1000000 | clean | prefer_index | 64MB | is_null | brin | 10 | 84.436 | 80.704–89.744 | 94.007 | 6.6% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 84.475 |
| scalar | 1000000 | clean | prefer_index | 64MB | is_null | btree | 10 | 6.628 | 6.593–6.730 | 7.122 | 3.8% | 8.76 | Index Only Scan | 0.032 | 6.659 |
| scalar | 1000000 | clean | prefer_index | 64MB | is_null | btree_tuned | 10 | 6.722 | 6.597–7.093 | 8.534 | 12.7% | 8.64 | Index Only Scan | 0.035 | 6.757 |
| scalar | 1000000 | clean | prefer_index | 64MB | is_null | gin | 10 | 59.669 | 56.990–62.062 | 65.026 | 5.3% | 0.97 | Seq Scan (fallback) | 0.029 | 59.700 |
| scalar | 1000000 | clean | prefer_index | 64MB | is_null | gist | 10 | 17.989 | 17.558–20.790 | 23.906 | 13.4% | 3.23 | Index Only Scan | 0.032 | 18.021 |
| scalar | 1000000 | clean | prefer_index | 64MB | is_null | hash (partial) | 10 | 58.406 | 55.276–60.633 | 61.332 | 4.6% | 0.99 | Seq Scan (fallback) | 0.028 | 58.438 |
| scalar | 1000000 | clean | prefer_index | 64MB | is_null | roaring | 10 | 0.099 | 0.098–0.108 | 0.121 | 9.2% | 589.71 | RoaringCount | 0.032 | 0.131 |
| scalar | 1000000 | clean | prefer_index | 64MB | is_null | roaring_bitmap | 10 | 26.923 | 25.943–30.152 | 32.314 | 9.6% | 2.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 26.973 |
| scalar | 1000000 | clean | prefer_index | 64MB | is_null | seq | 10 | 58.087 | 56.317–60.188 | 64.109 | 5.8% | 1.00 | Seq Scan | 0.026 | 58.114 |
| scalar | 1000000 | clean | prefer_index | 64MB | not_null | brin | 10 | 110.099 | 107.348–114.815 | 121.709 | 5.5% | 0.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 110.153 |
| scalar | 1000000 | clean | prefer_index | 64MB | not_null | btree | 10 | 56.862 | 55.242–60.246 | 69.587 | 10.5% | 1.45 | Index Only Scan | 0.032 | 56.903 |
| scalar | 1000000 | clean | prefer_index | 64MB | not_null | btree_tuned | 10 | 59.941 | 57.402–60.686 | 61.119 | 3.6% | 1.38 | Index Only Scan | 0.034 | 59.973 |
| scalar | 1000000 | clean | prefer_index | 64MB | not_null | gin | 10 | 80.431 | 78.672–83.379 | 88.117 | 4.7% | 1.03 | Seq Scan (fallback) | 0.029 | 80.460 |
| scalar | 1000000 | clean | prefer_index | 64MB | not_null | gist | 10 | 113.931 | 111.476–123.179 | 133.338 | 7.6% | 0.72 | Index Only Scan | 0.032 | 113.969 |
| scalar | 1000000 | clean | prefer_index | 64MB | not_null | hash (partial) | 10 | 79.737 | 78.959–87.748 | 91.617 | 6.6% | 1.03 | Seq Scan (fallback) | 0.026 | 79.763 |
| scalar | 1000000 | clean | prefer_index | 64MB | not_null | roaring | 10 | 57.940 | 55.461–59.953 | 60.443 | 3.6% | 1.42 | RoaringCount | 0.034 | 57.989 |
| scalar | 1000000 | clean | prefer_index | 64MB | not_null | roaring_bitmap | 10 | 110.927 | 108.314–113.689 | 116.131 | 3.6% | 0.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 110.958 |
| scalar | 1000000 | clean | prefer_index | 64MB | not_null | seq | 10 | 82.517 | 80.703–85.494 | 86.089 | 3.0% | 1.00 | Seq Scan | 0.026 | 82.548 |
| scalar | 1000000 | clean | prefer_index | 64MB | null_and | brin | 10 | 73.909 | 71.808–75.790 | 79.969 | 4.6% | 0.77 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 73.967 |
| scalar | 1000000 | clean | prefer_index | 64MB | null_and | btree | 10 | 3.861 | 3.686–3.990 | 4.100 | 4.5% | 14.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.902 |
| scalar | 1000000 | clean | prefer_index | 64MB | null_and | btree_tuned | 10 | 3.952 | 3.773–4.076 | 4.242 | 5.2% | 14.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 3.998 |
| scalar | 1000000 | clean | prefer_index | 64MB | null_and | gin | 10 | 3.160 | 2.923–4.227 | 6.975 | 47.1% | 17.93 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.212 |
| scalar | 1000000 | clean | prefer_index | 64MB | null_and | gist | 10 | 11.857 | 11.742–12.362 | 12.802 | 4.0% | 4.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 11.916 |
| scalar | 1000000 | clean | prefer_index | 64MB | null_and | hash (partial) | 10 | 3.505 | 2.904–3.744 | 4.038 | 14.2% | 16.17 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 3.551 |
| scalar | 1000000 | clean | prefer_index | 64MB | null_and | roaring | 10 | 0.184 | 0.181–0.186 | 0.201 | 4.8% | 307.99 | RoaringCount | 0.045 | 0.232 |
| scalar | 1000000 | clean | prefer_index | 64MB | null_and | roaring_bitmap | 10 | 4.265 | 3.981–4.434 | 4.513 | 5.9% | 13.29 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 4.319 |
| scalar | 1000000 | clean | prefer_index | 64MB | null_and | seq | 10 | 56.671 | 54.312–57.709 | 60.952 | 5.4% | 1.00 | Seq Scan | 0.035 | 56.710 |
| scalar | 1000000 | clean | prefer_index | 64MB | or_columns | brin | 10 | 81.760 | 80.547–88.236 | 90.038 | 5.0% | 0.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 81.808 |
| scalar | 1000000 | clean | prefer_index | 64MB | or_columns | btree | 10 | 19.843 | 19.085–21.605 | 22.374 | 8.4% | 3.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 19.885 |
| scalar | 1000000 | clean | prefer_index | 64MB | or_columns | btree_tuned | 10 | 20.393 | 19.624–21.758 | 23.674 | 7.7% | 2.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 20.445 |
| scalar | 1000000 | clean | prefer_index | 64MB | or_columns | gin | 10 | 21.187 | 20.430–23.018 | 25.514 | 10.0% | 2.86 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 21.231 |
| scalar | 1000000 | clean | prefer_index | 64MB | or_columns | gist | 10 | 21.041 | 20.679–22.831 | 23.884 | 10.3% | 2.88 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 21.088 |
| scalar | 1000000 | clean | prefer_index | 64MB | or_columns | hash (partial) | 10 | 21.385 | 20.940–22.181 | 22.434 | 3.3% | 2.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 21.422 |
| scalar | 1000000 | clean | prefer_index | 64MB | or_columns | roaring | 10 | 18.895 | 18.471–19.652 | 21.607 | 7.3% | 3.20 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 18.933 |
| scalar | 1000000 | clean | prefer_index | 64MB | or_columns | roaring_bitmap | 10 | 19.606 | 19.142–20.328 | 22.796 | 8.7% | 3.09 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 19.654 |
| scalar | 1000000 | clean | prefer_index | 64MB | or_columns | seq | 10 | 60.536 | 57.895–62.991 | 64.854 | 5.1% | 1.00 | Seq Scan | 0.033 | 60.579 |
| scalar | 1000000 | clean | prefer_index | 64MB | ordered_limit | brin | 10 | 107.206 | 103.541–112.846 | 120.725 | 6.4% | 0.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 107.257 |
| scalar | 1000000 | clean | prefer_index | 64MB | ordered_limit | btree | 10 | 0.019 | 0.018–0.020 | 0.020 | 5.5% | 4470.18 | Index Only Scan | 0.054 | 0.072 |
| scalar | 1000000 | clean | prefer_index | 64MB | ordered_limit | btree_tuned | 10 | 0.019 | 0.018–0.020 | 0.020 | 3.9% | 4470.18 | Index Only Scan | 0.057 | 0.076 |
| scalar | 1000000 | clean | prefer_index | 64MB | ordered_limit | gin | 10 | 194.428 | 189.133–197.376 | 205.592 | 3.8% | 0.44 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 194.470 |
| scalar | 1000000 | clean | prefer_index | 64MB | ordered_limit | gist | 10 | 143.395 | 138.558–149.087 | 151.277 | 4.1% | 0.59 | Index Only Scan | 0.058 | 143.443 |
| scalar | 1000000 | clean | prefer_index | 64MB | ordered_limit | hash (partial) | 10 | 87.076 | 85.304–89.443 | 96.328 | 5.9% | 0.98 | Seq Scan (fallback) | 0.036 | 87.121 |
| scalar | 1000000 | clean | prefer_index | 64MB | ordered_limit | roaring | 10 | 87.222 | 84.259–90.348 | 92.797 | 4.1% | 0.97 | Seq Scan (fallback) | 0.035 | 87.262 |
| scalar | 1000000 | clean | prefer_index | 64MB | ordered_limit | roaring_bitmap | 10 | 84.073 | 83.444–85.877 | 88.643 | 2.9% | 1.01 | Seq Scan (fallback) | 0.038 | 84.115 |
| scalar | 1000000 | clean | prefer_index | 64MB | ordered_limit | seq | 10 | 84.934 | 83.295–86.916 | 90.500 | 3.5% | 1.00 | Seq Scan | 0.045 | 84.980 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_broad | brin | 10 | 108.309 | 104.950–109.768 | 118.574 | 5.7% | 0.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 108.381 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_broad | btree | 10 | 30.834 | 30.058–32.183 | 33.676 | 4.7% | 2.65 | Index Only Scan | 0.052 | 30.887 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_broad | btree_tuned | 10 | 30.801 | 30.006–32.337 | 36.677 | 9.6% | 2.65 | Index Only Scan | 0.052 | 30.851 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_broad | gin | 10 | 184.864 | 181.339–186.228 | 190.263 | 2.5% | 0.44 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 184.924 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_broad | gist | 10 | 81.491 | 78.072–83.596 | 84.197 | 3.8% | 1.00 | Index Only Scan | 0.044 | 81.534 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_broad | hash (partial) | 10 | 77.763 | 76.872–81.376 | 83.984 | 4.4% | 1.05 | Seq Scan (fallback) | 0.058 | 77.825 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_broad | roaring | 10 | 80.079 | 78.106–83.929 | 86.645 | 4.8% | 1.02 | Seq Scan (fallback) | 0.040 | 80.127 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_broad | roaring_bitmap | 10 | 76.864 | 75.374–80.379 | 81.951 | 3.6% | 1.06 | Seq Scan (fallback) | 0.039 | 76.903 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_broad | seq | 10 | 81.743 | 79.290–84.199 | 84.648 | 3.6% | 1.00 | Seq Scan | 0.036 | 81.781 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_clustered | brin | 10 | 6.217 | 5.722–6.380 | 6.814 | 7.3% | 9.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 6.290 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_clustered | btree | 10 | 3.082 | 3.030–3.269 | 3.607 | 8.1% | 19.83 | Index Only Scan | 0.042 | 3.123 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_clustered | btree_tuned | 10 | 3.178 | 3.093–3.254 | 3.691 | 8.1% | 19.23 | Index Only Scan | 0.045 | 3.223 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_clustered | gin | 10 | 17.486 | 17.047–19.157 | 20.975 | 9.3% | 3.49 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 17.532 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_clustered | gist | 10 | 7.771 | 7.683–8.168 | 8.175 | 2.9% | 7.86 | Index Only Scan | 0.044 | 7.816 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_clustered | hash (partial) | 10 | 58.132 | 57.305–61.118 | 62.566 | 3.8% | 1.05 | Seq Scan (fallback) | 0.036 | 58.167 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_clustered | roaring | 10 | 60.778 | 58.800–63.006 | 64.511 | 4.0% | 1.01 | Seq Scan (fallback) | 0.037 | 60.820 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_clustered | roaring_bitmap | 10 | 59.212 | 55.960–63.576 | 65.551 | 6.4% | 1.03 | Seq Scan (fallback) | 0.041 | 59.257 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_clustered | seq | 10 | 61.112 | 59.204–64.824 | 66.877 | 5.8% | 1.00 | Seq Scan | 0.045 | 61.155 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_random | brin | 10 | 81.880 | 78.674–84.249 | 91.784 | 6.5% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 81.936 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_random | btree | 10 | 0.304 | 0.297–0.312 | 0.321 | 3.5% | 185.16 | Index Only Scan | 0.057 | 0.362 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_random | btree_tuned | 10 | 0.306 | 0.301–0.341 | 0.393 | 11.6% | 184.25 | Index Only Scan | 0.054 | 0.376 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_random | gin | 10 | 39.415 | 38.480–43.082 | 44.271 | 6.3% | 1.43 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 39.461 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_random | gist | 10 | 0.812 | 0.791–0.838 | 0.874 | 4.2% | 69.43 | Index Only Scan | 0.046 | 0.873 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_random | hash (partial) | 10 | 55.119 | 54.084–56.670 | 60.151 | 4.9% | 1.02 | Seq Scan (fallback) | 0.043 | 55.163 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_random | roaring | 10 | 55.849 | 54.161–57.216 | 58.262 | 3.4% | 1.01 | Seq Scan (fallback) | 0.040 | 55.888 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_random | roaring_bitmap | 10 | 54.239 | 52.965–55.359 | 56.964 | 3.3% | 1.04 | Seq Scan (fallback) | 0.038 | 54.281 |
| scalar | 1000000 | clean | prefer_index | 64MB | range_random | seq | 10 | 56.380 | 55.261–60.043 | 62.213 | 5.8% | 1.00 | Seq Scan | 0.034 | 56.415 |
| scalar | 1000000 | clean | prefer_index | 64MB | residual_filter | brin | 10 | 74.101 | 72.656–78.287 | 83.515 | 6.2% | 0.77 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 74.156 |
| scalar | 1000000 | clean | prefer_index | 64MB | residual_filter | btree | 10 | 3.795 | 2.941–4.470 | 4.705 | 21.2% | 15.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.835 |
| scalar | 1000000 | clean | prefer_index | 64MB | residual_filter | btree_tuned | 10 | 0.600 | 0.587–0.623 | 0.646 | 4.0% | 95.00 | Index Only Scan | 0.046 | 0.643 |
| scalar | 1000000 | clean | prefer_index | 64MB | residual_filter | gin | 10 | 4.034 | 3.651–4.594 | 5.128 | 17.0% | 14.13 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 4.077 |
| scalar | 1000000 | clean | prefer_index | 64MB | residual_filter | gist | 10 | 3.939 | 3.103–4.443 | 5.157 | 21.8% | 14.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.982 |
| scalar | 1000000 | clean | prefer_index | 64MB | residual_filter | hash (partial) | 10 | 3.460 | 3.373–3.680 | 3.895 | 6.0% | 16.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 3.500 |
| scalar | 1000000 | clean | prefer_index | 64MB | residual_filter | roaring | 10 | 3.596 | 3.321–3.898 | 4.201 | 11.5% | 15.85 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.643 |
| scalar | 1000000 | clean | prefer_index | 64MB | residual_filter | roaring_bitmap | 10 | 3.258 | 3.018–3.470 | 3.582 | 8.5% | 17.50 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 3.295 |
| scalar | 1000000 | clean | prefer_index | 64MB | residual_filter | seq | 10 | 57.002 | 55.203–57.939 | 60.806 | 4.4% | 1.00 | Seq Scan | 0.038 | 57.038 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and2 | brin | 10 | 46.957 | 45.972–48.986 | 50.256 | 4.0% | 1.03 | Seq Scan (fallback) | 0.052 | 47.012 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and2 | btree | 10 | 2.923 | 2.657–3.231 | 3.647 | 14.6% | 16.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 2.966 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and2 | btree_tuned | 10 | 0.276 | 0.270–0.286 | 0.307 | 6.0% | 176.23 | Index Only Scan | 0.048 | 0.326 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and2 | gin | 10 | 36.968 | 36.203–39.010 | 43.718 | 9.0% | 1.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 37.048 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and2 | gist | 10 | 3.256 | 2.880–3.454 | 3.637 | 10.2% | 14.91 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 3.325 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and2 | hash (partial) | 10 | 3.282 | 3.135–3.505 | 3.946 | 11.1% | 14.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.321 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and2 | roaring | 10 | 0.426 | 0.409–0.511 | 0.562 | 14.1% | 113.84 | RoaringCount | 0.046 | 0.479 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and2 | roaring_bitmap | 10 | 2.904 | 2.816–3.135 | 3.340 | 7.6% | 16.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 2.970 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and2 | seq | 10 | 48.552 | 47.530–49.615 | 50.924 | 3.2% | 1.00 | Seq Scan | 0.037 | 48.609 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and3 | brin | 10 | 48.509 | 47.948–51.059 | 52.135 | 4.3% | 1.00 | Seq Scan (fallback) | 0.058 | 48.571 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and3 | btree | 10 | 2.894 | 2.713–3.023 | 3.209 | 7.1% | 16.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 2.943 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and3 | btree_tuned | 10 | 0.035 | 0.034–0.036 | 0.037 | 4.3% | 1380.87 | Index Only Scan | 0.052 | 0.087 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and3 | gin | 10 | 8.753 | 8.340–8.915 | 10.119 | 9.0% | 5.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.072 | 8.820 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and3 | gist | 10 | 4.111 | 3.932–4.368 | 4.538 | 6.2% | 11.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 4.159 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and3 | hash (partial) | 10 | 3.283 | 3.226–3.497 | 3.925 | 9.2% | 14.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 3.343 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and3 | roaring | 10 | 0.271 | 0.267–0.282 | 0.293 | 5.8% | 178.67 | RoaringCount | 0.050 | 0.321 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and3 | roaring_bitmap | 10 | 2.426 | 2.392–2.511 | 2.706 | 5.2% | 19.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 2.473 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | and3 | seq | 10 | 48.331 | 47.032–50.693 | 52.919 | 5.1% | 1.00 | Seq Scan | 0.039 | 48.386 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | brin | 10 | 79.011 | 73.873–79.655 | 83.378 | 5.4% | 0.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 79.106 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | btree | 10 | 0.020 | 0.019–0.021 | 0.022 | 5.6% | 2688.03 | Index Only Scan | 0.036 | 0.056 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | btree_tuned | 10 | 0.020 | 0.018–0.021 | 0.048 | 64.9% | 2688.03 | Index Only Scan | 0.037 | 0.057 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | gin | 10 | 1.589 | 1.560–1.661 | 1.738 | 4.7% | 33.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 1.645 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | gist | 10 | 0.030 | 0.028–0.031 | 0.032 | 7.0% | 1792.02 | Index Only Scan | 0.035 | 0.066 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | hash (partial) | 10 | 0.019 | 0.018–0.022 | 0.025 | 13.7% | 2756.95 | Index Scan | 0.033 | 0.053 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | roaring | 10 | 0.011 | 0.010–0.011 | 0.013 | 9.1% | 4887.32 | RoaringCount | 0.037 | 0.049 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | roaring_bitmap | 10 | 0.024 | 0.022–0.027 | 0.031 | 13.6% | 2287.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 0.059 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | seq | 10 | 53.761 | 50.814–56.587 | 57.113 | 5.5% | 1.00 | Seq Scan | 0.026 | 53.794 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | brin | 10 | 49.154 | 45.913–51.146 | 54.296 | 6.8% | 1.00 | Seq Scan (fallback) | 0.045 | 49.208 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | btree | 10 | 0.421 | 0.411–0.439 | 0.458 | 4.2% | 116.35 | Index Only Scan | 0.053 | 0.479 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | btree_tuned | 10 | 0.538 | 0.506–0.655 | 0.720 | 15.8% | 91.04 | Index Only Scan | 0.043 | 0.579 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | gin | 10 | 5.053 | 4.958–5.543 | 6.235 | 9.7% | 9.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 5.122 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | gist | 10 | 0.843 | 0.823–0.896 | 0.951 | 6.2% | 58.07 | Index Only Scan | 0.036 | 0.885 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | hash (partial) | 10 | 3.256 | 3.066–3.421 | 3.807 | 9.9% | 15.04 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 3.316 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | roaring | 10 | 0.136 | 0.129–0.174 | 0.192 | 17.7% | 360.16 | RoaringCount | 0.040 | 0.175 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | roaring_bitmap | 10 | 2.962 | 2.737–3.201 | 3.235 | 7.1% | 16.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 3.000 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | seq | 10 | 48.981 | 47.697–49.834 | 52.165 | 4.1% | 1.00 | Seq Scan | 0.029 | 49.008 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | brin | 10 | 48.335 | 46.574–49.867 | 51.042 | 3.9% | 1.04 | Seq Scan (fallback) | 0.046 | 48.382 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | btree | 10 | 3.792 | 3.724–4.126 | 4.322 | 6.7% | 13.31 | Index Only Scan | 0.038 | 3.852 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | btree_tuned | 10 | 3.741 | 3.667–4.092 | 4.424 | 8.4% | 13.49 | Index Only Scan | 0.038 | 3.777 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | gin | 10 | 23.065 | 22.263–24.869 | 24.986 | 5.2% | 2.19 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 23.102 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | gist | 10 | 7.989 | 7.836–8.264 | 8.503 | 4.3% | 6.32 | Index Only Scan | 0.037 | 8.027 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | hash (partial) | 10 | 20.323 | 19.694–21.792 | 23.803 | 8.5% | 2.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 20.355 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | roaring | 10 | 0.636 | 0.616–0.764 | 0.890 | 16.8% | 79.36 | RoaringCount | 0.038 | 0.673 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | roaring_bitmap | 10 | 19.130 | 17.895–22.121 | 22.953 | 10.9% | 2.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 19.164 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | seq | 10 | 50.470 | 48.672–51.838 | 55.156 | 5.3% | 1.00 | Seq Scan | 0.029 | 50.501 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | brin | 10 | 73.595 | 71.210–77.442 | 79.733 | 4.7% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 73.645 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | btree | 10 | 0.026 | 0.025–0.027 | 0.028 | 6.9% | 1977.71 | Index Only Scan | 0.037 | 0.063 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | btree_tuned | 10 | 0.024 | 0.023–0.027 | 0.029 | 10.4% | 2142.52 | Index Only Scan | 0.041 | 0.065 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | gin | 10 | 1.649 | 1.606–1.821 | 1.872 | 7.2% | 31.18 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 1.700 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | gist | 10 | 0.040 | 0.039–0.040 | 0.041 | 1.7% | 1285.51 | Index Only Scan | 0.036 | 0.076 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | hash (partial) | 10 | 0.055 | 0.050–0.061 | 0.087 | 28.1% | 934.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.033 | 0.086 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | roaring | 10 | 0.015 | 0.014–0.017 | 0.019 | 11.9% | 3428.03 | RoaringCount | 0.039 | 0.054 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | roaring_bitmap | 10 | 0.055 | 0.051–0.062 | 0.075 | 16.9% | 934.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 0.090 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | seq | 10 | 51.421 | 49.388–54.177 | 55.409 | 5.3% | 1.00 | Seq Scan | 0.029 | 51.456 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | brin | 10 | 68.152 | 64.761–72.320 | 75.481 | 6.3% | 1.03 | Seq Scan (fallback) | 0.043 | 68.195 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | btree | 10 | 34.444 | 33.634–37.715 | 41.707 | 9.2% | 2.03 | Index Only Scan | 0.036 | 34.478 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | btree_tuned | 10 | 35.435 | 34.713–36.634 | 37.636 | 3.5% | 1.98 | Index Only Scan | 0.040 | 35.474 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | gin | 10 | 98.031 | 96.882–101.251 | 104.165 | 3.1% | 0.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 98.088 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | gist | 10 | 78.698 | 75.073–80.672 | 81.288 | 3.7% | 0.89 | Index Only Scan | 0.036 | 78.734 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | hash (partial) | 10 | 66.963 | 64.603–69.733 | 71.383 | 4.2% | 1.05 | Seq Scan (fallback) | 0.033 | 67.007 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | roaring | 10 | 2.332 | 2.246–2.615 | 2.669 | 7.7% | 30.06 | RoaringCount | 0.037 | 2.368 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | roaring_bitmap | 10 | 68.452 | 65.675–69.243 | 70.348 | 3.8% | 1.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 68.490 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | seq | 10 | 70.089 | 67.130–71.322 | 77.281 | 6.4% | 1.00 | Seq Scan | 0.032 | 70.117 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | brin | 10 | 4.085 | 3.935–4.214 | 4.292 | 3.9% | 13.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 4.139 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | btree | 10 | 0.321 | 0.313–0.346 | 0.389 | 9.3% | 172.40 | Index Only Scan | 0.036 | 0.357 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | btree_tuned | 10 | 0.314 | 0.310–0.322 | 0.369 | 9.1% | 175.96 | Index Only Scan | 0.039 | 0.354 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | gin | 10 | 2.253 | 2.234–2.286 | 2.324 | 1.6% | 24.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 2.312 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | gist | 10 | 0.725 | 0.712–0.761 | 0.796 | 4.7% | 76.21 | Index Only Scan | 0.038 | 0.772 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | hash (partial) | 10 | 0.706 | 0.678–0.740 | 0.856 | 10.9% | 78.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.755 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | roaring | 10 | 0.011 | 0.010–0.012 | 0.013 | 11.6% | 5023.00 | RoaringCount | 0.038 | 0.049 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | roaring_bitmap | 10 | 0.445 | 0.421–0.471 | 0.482 | 6.2% | 124.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 0.499 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | seq | 10 | 55.253 | 54.146–57.369 | 60.821 | 5.3% | 1.00 | Seq Scan | 0.033 | 55.279 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | brin | 10 | 81.183 | 79.742–83.406 | 88.711 | 4.7% | 0.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 81.240 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | btree | 10 | 0.440 | 0.417–0.467 | 0.493 | 6.9% | 133.92 | Index Only Scan | 0.036 | 0.477 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | btree_tuned | 10 | 0.429 | 0.422–0.436 | 0.463 | 4.4% | 137.04 | Index Only Scan | 0.038 | 0.469 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | gin | 10 | 5.188 | 5.129–5.485 | 6.178 | 8.7% | 11.35 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 5.247 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | gist | 10 | 0.835 | 0.775–0.864 | 0.934 | 7.8% | 70.53 | Index Only Scan | 0.036 | 0.869 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | hash (partial) | 10 | 3.558 | 3.347–3.723 | 3.892 | 6.9% | 16.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 3.599 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | roaring | 10 | 0.162 | 0.147–0.195 | 0.218 | 16.9% | 363.32 | RoaringCount | 0.036 | 0.198 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | roaring_bitmap | 10 | 3.297 | 3.041–3.568 | 3.748 | 11.6% | 17.85 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 3.331 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | seq | 10 | 58.858 | 55.428–61.056 | 62.168 | 5.1% | 1.00 | Seq Scan | 0.028 | 58.897 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | brin | 10 | 83.647 | 82.067–85.696 | 88.361 | 3.4% | 1.04 | Seq Scan (fallback) | 0.046 | 83.692 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | btree | 10 | 63.205 | 60.398–66.824 | 71.509 | 7.0% | 1.38 | Index Only Scan | 0.036 | 63.241 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | btree_tuned | 10 | 63.731 | 61.411–69.957 | 74.630 | 8.5% | 1.36 | Index Only Scan | 0.039 | 63.766 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | gin | 10 | 88.072 | 83.868–93.358 | 94.173 | 5.6% | 0.99 | Seq Scan (fallback) | 0.045 | 88.116 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | gist | 10 | 86.078 | 83.299–90.191 | 92.037 | 4.4% | 1.01 | Seq Scan (fallback) | 0.036 | 86.111 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | hash (partial) | 10 | 84.950 | 84.337–89.453 | 96.061 | 6.1% | 1.02 | Seq Scan (fallback) | 0.032 | 84.990 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | roaring | 10 | 2.696 | 2.646–2.822 | 2.904 | 4.0% | 32.25 | RoaringCount | 0.037 | 2.731 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | roaring_bitmap | 10 | 87.090 | 84.621–90.184 | 98.159 | 6.8% | 1.00 | Seq Scan (fallback) | 0.038 | 87.163 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | seq | 10 | 86.918 | 83.933–89.475 | 90.178 | 3.6% | 1.00 | Seq Scan | 0.030 | 86.953 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | brin | 10 | 49.064 | 46.871–51.928 | 53.625 | 5.9% | 1.04 | Seq Scan (fallback) | 0.049 | 49.112 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | btree | 10 | 3.271 | 2.912–3.640 | 4.044 | 13.5% | 15.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.316 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | btree_tuned | 10 | 0.655 | 0.647–0.698 | 0.732 | 5.9% | 77.70 | Index Only Scan | 0.044 | 0.710 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | gin | 10 | 5.187 | 4.878–5.299 | 5.767 | 8.2% | 9.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 5.245 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | gist | 10 | 3.465 | 3.143–3.760 | 4.240 | 13.7% | 14.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.504 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | hash (partial) | 10 | 3.425 | 3.176–3.572 | 3.751 | 7.6% | 14.87 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 3.476 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | roaring | 10 | 3.190 | 3.008–3.522 | 3.566 | 8.7% | 15.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 3.231 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | roaring_bitmap | 10 | 2.942 | 2.867–3.408 | 3.653 | 10.7% | 17.32 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 2.983 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | seq | 10 | 50.935 | 47.418–53.843 | 54.761 | 6.3% | 1.00 | Seq Scan | 0.038 | 50.976 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c2 | brin | 10 | 136.286 | 132.028–140.041 | 142.464 | 4.2% | 1.01 | Seq Scan (fallback) | 0.044 | 136.329 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c2 | btree | 10 | 89.745 | 85.959–94.245 | 97.349 | 5.1% | 1.53 | Index Only Scan | 0.042 | 89.786 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c2 | btree_tuned | 10 | 87.904 | 86.621–90.769 | 93.993 | 3.5% | 1.56 | Index Only Scan | 0.042 | 87.945 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c2 | gin | 10 | 136.219 | 130.961–137.820 | 139.316 | 2.7% | 1.01 | Seq Scan (fallback) | 0.035 | 136.270 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c2 | gist | 10 | 137.313 | 133.553–140.145 | 147.164 | 4.5% | 1.00 | Seq Scan (fallback) | 0.035 | 137.346 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c2 | hash (partial) | 10 | 138.056 | 132.971–141.603 | 142.072 | 3.1% | 0.99 | Seq Scan (fallback) | 0.036 | 138.103 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c2 | roaring | 10 | 4.733 | 4.651–4.930 | 5.252 | 6.8% | 29.00 | RoaringCount | 0.036 | 4.769 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c2 | roaring_bitmap | 10 | 136.219 | 134.254–139.855 | 142.550 | 2.6% | 1.01 | Seq Scan (fallback) | 0.035 | 136.253 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c2 | seq | 10 | 137.253 | 134.678–140.789 | 143.923 | 3.3% | 1.00 | Seq Scan | 0.032 | 137.285 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c200 | brin | 10 | 154.042 | 150.950–160.822 | 164.423 | 3.8% | 1.00 | Seq Scan (fallback) | 0.042 | 154.091 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c200 | btree | 10 | 109.269 | 105.729–109.835 | 111.017 | 2.2% | 1.41 | Index Only Scan | 0.039 | 109.308 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c200 | btree_tuned | 10 | 121.202 | 116.136–126.064 | 128.278 | 4.5% | 1.27 | Index Only Scan | 0.044 | 121.245 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c200 | gin | 10 | 156.188 | 151.371–160.075 | 161.511 | 3.3% | 0.99 | Seq Scan (fallback) | 0.035 | 156.245 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c200 | gist | 10 | 160.695 | 155.027–165.023 | 166.037 | 3.5% | 0.96 | Seq Scan (fallback) | 0.037 | 160.729 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c200 | hash (partial) | 10 | 152.258 | 151.374–154.275 | 155.775 | 1.5% | 1.01 | Seq Scan (fallback) | 0.055 | 152.394 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c200 | roaring | 10 | 164.665 | 155.169–174.484 | 185.062 | 7.5% | 0.93 | Seq Scan (fallback) | 0.035 | 164.700 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c200 | roaring_bitmap | 10 | 157.353 | 151.953–160.543 | 163.492 | 3.5% | 0.98 | Seq Scan (fallback) | 0.036 | 157.389 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_c200 | seq | 10 | 153.916 | 148.796–155.780 | 159.155 | 3.0% | 1.00 | Seq Scan | 0.034 | 153.950 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_filtered | brin | 10 | 50.917 | 48.588–52.287 | 53.456 | 4.8% | 0.98 | Seq Scan (fallback) | 0.054 | 50.974 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_filtered | btree | 10 | 3.793 | 3.217–3.899 | 4.080 | 11.5% | 13.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 3.861 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_filtered | btree_tuned | 10 | 0.620 | 0.600–0.639 | 0.669 | 5.1% | 80.18 | Index Only Scan | 0.056 | 0.676 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_filtered | gin | 10 | 5.709 | 5.337–6.417 | 7.421 | 15.6% | 8.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 5.771 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_filtered | gist | 10 | 3.617 | 3.247–4.109 | 4.395 | 13.0% | 13.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 3.665 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_filtered | hash (partial) | 10 | 3.698 | 3.413–3.881 | 3.943 | 7.7% | 13.44 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 3.750 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_filtered | roaring | 10 | 2.753 | 2.686–2.880 | 2.995 | 4.2% | 18.05 | RoaringCount | 0.047 | 2.805 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_filtered | roaring_bitmap | 10 | 3.558 | 3.325–3.724 | 3.937 | 7.8% | 13.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 3.611 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | group_filtered | seq | 10 | 49.710 | 48.352–51.778 | 54.170 | 4.9% | 1.00 | Seq Scan | 0.037 | 49.747 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_and | brin | 10 | 70.898 | 69.279–74.946 | 79.306 | 5.9% | 1.05 | Seq Scan (fallback) | 0.059 | 70.952 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_and | btree | 10 | 7.415 | 6.978–7.595 | 7.841 | 5.5% | 10.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 7.467 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_and | btree_tuned | 10 | 0.247 | 0.243–0.257 | 0.266 | 4.0% | 300.82 | Index Only Scan | 0.054 | 0.304 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_and | gin | 10 | 24.724 | 24.094–26.250 | 26.494 | 4.4% | 3.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 24.777 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_and | gist | 10 | 11.234 | 11.002–11.463 | 11.755 | 2.7% | 6.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 11.287 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_and | hash (partial) | 10 | 8.713 | 8.573–9.157 | 10.845 | 12.2% | 8.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 8.769 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_and | roaring | 10 | 2.064 | 2.040–2.077 | 2.146 | 2.3% | 36.00 | RoaringCount | 0.053 | 2.119 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_and | roaring_bitmap | 10 | 6.604 | 6.357–6.836 | 6.886 | 4.1% | 11.25 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 6.659 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_and | seq | 10 | 74.302 | 71.043–77.122 | 78.463 | 4.9% | 1.00 | Seq Scan | 0.041 | 74.341 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | brin | 10 | 60.636 | 58.609–66.794 | 67.475 | 6.8% | 1.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 60.715 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | btree | 10 | 0.074 | 0.072–0.097 | 0.116 | 21.3% | 939.64 | Index Only Scan | 0.044 | 0.122 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | btree_tuned | 10 | 0.072 | 0.072–0.079 | 0.086 | 8.8% | 965.57 | Index Only Scan | 0.045 | 0.118 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | gin | 10 | 16.202 | 15.720–16.562 | 19.777 | 12.1% | 4.32 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 16.271 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | gist | 10 | 0.617 | 0.600–0.653 | 0.695 | 6.4% | 113.37 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 0.665 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | hash (partial) | 10 | 0.469 | 0.420–0.568 | 0.667 | 21.1% | 149.42 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 0.514 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | roaring | 10 | 0.089 | 0.085–0.093 | 0.108 | 11.1% | 782.16 | RoaringCount | 0.049 | 0.139 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | roaring_bitmap | 10 | 0.431 | 0.403–0.484 | 0.495 | 9.7% | 162.42 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 0.484 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | seq | 10 | 70.004 | 67.363–72.536 | 74.071 | 3.9% | 1.00 | Seq Scan | 0.035 | 70.040 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | brin | 10 | 74.671 | 73.058–76.981 | 82.866 | 5.5% | 1.03 | Seq Scan (fallback) | 0.472 | 75.277 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | btree | 10 | 4.595 | 4.469–4.706 | 5.425 | 9.7% | 16.73 | Index Only Scan | 0.441 | 5.029 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | btree_tuned | 10 | 4.724 | 4.579–4.797 | 4.880 | 2.7% | 16.27 | Index Only Scan | 0.451 | 5.178 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | gin | 10 | 77.013 | 75.882–79.304 | 81.136 | 3.2% | 1.00 | Seq Scan (fallback) | 0.631 | 77.665 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | gist | 10 | 37.248 | 36.399–40.490 | 41.834 | 6.1% | 2.06 | Bitmap Heap Scan, Bitmap Index Scan | 0.467 | 37.797 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | hash (partial) | 10 | 25.728 | 25.085–26.802 | 27.313 | 4.9% | 2.99 | Bitmap Heap Scan, Bitmap Index Scan | 0.449 | 26.182 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | roaring | 10 | 19.013 | 18.256–21.718 | 23.537 | 10.8% | 4.04 | RoaringCount | 0.811 | 19.828 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | roaring_bitmap | 10 | 21.761 | 20.040–24.676 | 27.449 | 14.7% | 3.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.470 | 22.232 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | seq | 10 | 76.860 | 75.168–78.470 | 80.569 | 3.3% | 1.00 | Seq Scan | 0.448 | 77.300 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | is_null | brin | 10 | 59.065 | 56.070–60.576 | 62.596 | 4.5% | 1.00 | Seq Scan (fallback) | 0.042 | 59.115 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | is_null | btree | 10 | 7.768 | 7.630–8.022 | 8.645 | 5.5% | 7.63 | Index Only Scan | 0.032 | 7.804 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | is_null | btree_tuned | 10 | 7.665 | 7.591–7.894 | 8.032 | 2.5% | 7.74 | Index Only Scan | 0.034 | 7.705 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | is_null | gin | 10 | 62.417 | 60.383–63.428 | 67.032 | 5.6% | 0.95 | Seq Scan (fallback) | 0.040 | 62.455 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | is_null | gist | 10 | 21.709 | 20.930–22.964 | 23.703 | 5.0% | 2.73 | Index Only Scan | 0.032 | 21.746 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | is_null | hash (partial) | 10 | 61.611 | 58.919–62.845 | 64.670 | 4.1% | 0.96 | Seq Scan (fallback) | 0.027 | 61.639 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | is_null | roaring | 10 | 1.014 | 0.920–1.304 | 1.452 | 20.3% | 58.48 | RoaringCount | 0.034 | 1.047 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | is_null | roaring_bitmap | 10 | 25.998 | 24.755–28.933 | 29.981 | 8.7% | 2.28 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 26.029 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | is_null | seq | 10 | 59.302 | 57.783–61.004 | 62.613 | 3.5% | 1.00 | Seq Scan | 0.025 | 59.331 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | range_random | brin | 10 | 57.508 | 54.814–58.903 | 61.507 | 5.0% | 0.98 | Seq Scan (fallback) | 0.059 | 57.562 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | range_random | btree | 10 | 0.488 | 0.466–0.523 | 0.585 | 9.9% | 116.05 | Index Only Scan | 0.053 | 0.544 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | range_random | btree_tuned | 10 | 0.500 | 0.475–0.520 | 0.561 | 7.6% | 113.15 | Index Only Scan | 0.057 | 0.558 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | range_random | gin | 10 | 45.843 | 44.378–48.748 | 49.834 | 5.5% | 1.24 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 45.918 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | range_random | gist | 10 | 0.891 | 0.881–0.955 | 0.983 | 4.9% | 63.52 | Index Only Scan | 0.042 | 0.939 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | range_random | hash (partial) | 10 | 56.933 | 55.716–60.377 | 61.222 | 4.4% | 0.99 | Seq Scan (fallback) | 0.037 | 56.969 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | range_random | roaring | 10 | 66.769 | 61.354–84.470 | 89.639 | 18.6% | 0.85 | Seq Scan (fallback) | 0.041 | 66.821 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | range_random | roaring_bitmap | 10 | 58.961 | 55.284–61.781 | 63.430 | 6.0% | 0.96 | Seq Scan (fallback) | 0.040 | 59.004 |
| scalar | 1000000 | dirty_clustered_5pct | default | 64MB | range_random | seq | 10 | 56.630 | 54.936–60.744 | 62.179 | 5.7% | 1.00 | Seq Scan | 0.033 | 56.666 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | brin | 10 | 72.892 | 70.712–76.553 | 80.810 | 5.5% | 0.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 72.961 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | btree | 10 | 3.381 | 3.144–3.721 | 4.176 | 13.6% | 14.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 3.431 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | btree_tuned | 10 | 0.273 | 0.262–0.299 | 0.405 | 22.2% | 180.23 | Index Only Scan | 0.049 | 0.323 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | gin | 10 | 37.448 | 36.305–39.526 | 40.062 | 4.4% | 1.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 37.519 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | gist | 10 | 3.284 | 3.087–3.309 | 3.382 | 6.4% | 14.98 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.324 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | hash (partial) | 10 | 3.117 | 2.884–3.596 | 3.870 | 12.9% | 15.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 3.157 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | roaring | 10 | 0.423 | 0.411–0.454 | 0.482 | 6.9% | 116.18 | RoaringCount | 0.046 | 0.467 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | roaring_bitmap | 10 | 2.956 | 2.822–3.366 | 3.968 | 14.9% | 16.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 3.000 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | seq | 10 | 49.202 | 47.953–50.846 | 54.922 | 6.0% | 1.00 | Seq Scan | 0.034 | 49.263 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | brin | 10 | 73.067 | 70.133–77.486 | 80.946 | 5.6% | 0.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 73.131 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | btree | 10 | 2.781 | 2.698–2.866 | 2.906 | 3.2% | 17.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 2.831 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | btree_tuned | 10 | 0.033 | 0.032–0.035 | 0.037 | 5.6% | 1467.48 | Index Only Scan | 0.050 | 0.083 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | gin | 10 | 8.874 | 8.438–9.247 | 10.895 | 12.9% | 5.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.079 | 8.962 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | gist | 10 | 4.150 | 3.945–4.540 | 4.862 | 8.8% | 11.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 4.197 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | hash (partial) | 10 | 3.292 | 3.239–3.395 | 3.454 | 2.7% | 14.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 3.353 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | roaring | 10 | 0.278 | 0.271–0.299 | 0.327 | 8.2% | 174.51 | RoaringCount | 0.051 | 0.329 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | roaring_bitmap | 10 | 2.470 | 2.393–2.543 | 2.722 | 5.5% | 19.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 2.521 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | seq | 10 | 48.427 | 47.386–49.824 | 51.944 | 4.1% | 1.00 | Seq Scan | 0.035 | 48.460 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | brin | 10 | 75.352 | 72.985–79.102 | 82.502 | 5.4% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 75.410 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | btree | 10 | 0.020 | 0.019–0.024 | 0.048 | 56.5% | 2645.07 | Index Only Scan | 0.036 | 0.055 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | btree_tuned | 10 | 0.021 | 0.019–0.021 | 0.031 | 28.4% | 2580.56 | Index Only Scan | 0.038 | 0.059 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | gin | 10 | 1.619 | 1.583–1.667 | 1.721 | 3.8% | 32.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 1.695 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | gist | 10 | 0.030 | 0.029–0.037 | 0.042 | 16.3% | 1763.38 | Index Only Scan | 0.035 | 0.065 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | hash (partial) | 10 | 0.020 | 0.018–0.021 | 0.024 | 11.8% | 2645.07 | Index Scan | 0.033 | 0.053 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | roaring | 10 | 0.010 | 0.009–0.011 | 0.013 | 13.7% | 5290.15 | RoaringCount | 0.036 | 0.045 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | roaring_bitmap | 10 | 0.026 | 0.023–0.031 | 0.065 | 65.9% | 2034.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 0.070 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | seq | 10 | 52.901 | 51.408–57.436 | 59.394 | 6.6% | 1.00 | Seq Scan | 0.029 | 52.926 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | brin | 10 | 72.276 | 69.476–75.663 | 80.224 | 5.9% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 72.323 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | btree | 10 | 0.419 | 0.412–0.462 | 0.622 | 21.5% | 119.75 | Index Only Scan | 0.037 | 0.458 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | btree_tuned | 10 | 0.518 | 0.492–0.567 | 0.760 | 21.8% | 96.96 | Index Only Scan | 0.040 | 0.558 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | gin | 10 | 5.099 | 4.927–5.659 | 6.191 | 9.6% | 9.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 5.164 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | gist | 10 | 0.838 | 0.811–0.872 | 0.917 | 5.6% | 59.88 | Index Only Scan | 0.036 | 0.878 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | hash (partial) | 10 | 3.372 | 3.125–3.598 | 3.972 | 11.5% | 14.88 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 3.440 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | roaring | 10 | 0.128 | 0.125–0.164 | 0.219 | 26.3% | 393.54 | RoaringCount | 0.036 | 0.164 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | roaring_bitmap | 10 | 3.213 | 2.832–3.477 | 3.612 | 12.1% | 15.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 3.261 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | seq | 10 | 50.177 | 47.460–51.844 | 54.124 | 5.6% | 1.00 | Seq Scan | 0.032 | 50.210 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | brin | 10 | 72.302 | 69.742–77.907 | 81.748 | 6.5% | 0.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 72.361 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | btree | 10 | 3.813 | 3.675–3.893 | 4.151 | 5.5% | 12.99 | Index Only Scan | 0.038 | 3.862 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | btree_tuned | 10 | 3.873 | 3.782–4.016 | 4.338 | 6.5% | 12.79 | Index Only Scan | 0.040 | 3.931 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | gin | 10 | 24.561 | 23.672–25.850 | 26.976 | 6.9% | 2.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 24.617 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | gist | 10 | 7.807 | 7.644–8.267 | 8.779 | 5.8% | 6.34 | Index Only Scan | 0.036 | 7.848 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | hash (partial) | 10 | 20.256 | 20.037–21.751 | 25.126 | 11.4% | 2.44 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 20.294 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | roaring | 10 | 0.653 | 0.608–0.706 | 0.904 | 19.5% | 75.89 | RoaringCount | 0.038 | 0.689 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | roaring_bitmap | 10 | 18.948 | 17.648–20.268 | 22.058 | 8.8% | 2.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 18.983 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | seq | 10 | 49.517 | 47.611–52.676 | 55.301 | 6.3% | 1.00 | Seq Scan | 0.029 | 49.547 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | brin | 10 | 74.200 | 72.913–76.453 | 79.317 | 3.5% | 0.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 74.255 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | btree | 10 | 0.026 | 0.025–0.029 | 0.032 | 12.8% | 1955.16 | Index Only Scan | 0.037 | 0.063 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | btree_tuned | 10 | 0.025 | 0.024–0.026 | 0.028 | 8.5% | 1994.26 | Index Only Scan | 0.038 | 0.064 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | gin | 10 | 1.633 | 1.574–1.720 | 2.083 | 13.2% | 30.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 1.696 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | gist | 10 | 0.042 | 0.039–0.044 | 0.052 | 12.9% | 1201.36 | Index Only Scan | 0.035 | 0.077 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | hash (partial) | 10 | 0.054 | 0.052–0.057 | 0.060 | 7.6% | 923.27 | Bitmap Heap Scan, Bitmap Index Scan | 0.033 | 0.086 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | roaring | 10 | 0.015 | 0.014–0.015 | 0.016 | 6.2% | 3323.77 | RoaringCount | 0.038 | 0.052 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | roaring_bitmap | 10 | 0.057 | 0.054–0.068 | 0.095 | 28.1% | 882.42 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 0.093 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | seq | 10 | 49.856 | 49.189–52.467 | 55.267 | 5.2% | 1.00 | Seq Scan | 0.029 | 49.889 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | brin | 10 | 95.159 | 91.377–96.975 | 102.182 | 5.0% | 0.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 95.202 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | btree | 10 | 34.302 | 33.472–37.360 | 39.523 | 7.2% | 1.98 | Index Only Scan | 0.039 | 34.343 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | btree_tuned | 10 | 34.407 | 33.351–34.868 | 35.773 | 3.1% | 1.97 | Index Only Scan | 0.040 | 34.447 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | gin | 10 | 101.595 | 96.687–103.574 | 105.051 | 3.6% | 0.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 101.631 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | gist | 10 | 78.781 | 76.102–80.931 | 83.661 | 4.4% | 0.86 | Index Only Scan | 0.035 | 78.816 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | hash (partial) | 10 | 66.177 | 64.964–73.976 | 75.126 | 6.6% | 1.03 | Seq Scan (fallback) | 0.032 | 66.213 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | roaring | 10 | 2.359 | 2.183–2.523 | 2.658 | 8.1% | 28.77 | RoaringCount | 0.037 | 2.397 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | roaring_bitmap | 10 | 67.314 | 65.878–70.299 | 71.811 | 3.8% | 1.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 67.376 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | seq | 10 | 67.865 | 67.184–69.976 | 72.544 | 3.5% | 1.00 | Seq Scan | 0.028 | 67.907 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | brin | 10 | 3.976 | 3.918–4.056 | 4.139 | 2.8% | 14.27 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 4.020 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | btree | 10 | 0.320 | 0.315–0.336 | 0.465 | 21.9% | 177.53 | Index Only Scan | 0.036 | 0.367 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | btree_tuned | 10 | 0.328 | 0.315–0.337 | 0.342 | 3.4% | 173.19 | Index Only Scan | 0.041 | 0.367 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | gin | 10 | 2.237 | 2.236–2.406 | 3.562 | 28.1% | 25.36 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 2.286 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | gist | 10 | 0.738 | 0.703–0.776 | 0.884 | 9.8% | 76.81 | Index Only Scan | 0.036 | 0.779 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | hash (partial) | 10 | 0.707 | 0.663–0.760 | 0.875 | 11.8% | 80.23 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 0.744 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | roaring | 10 | 0.011 | 0.010–0.011 | 0.012 | 6.3% | 5156.45 | RoaringCount | 0.038 | 0.050 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | roaring_bitmap | 10 | 0.441 | 0.429–0.454 | 0.458 | 2.9% | 128.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 0.487 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | seq | 10 | 56.721 | 54.952–60.205 | 64.257 | 7.2% | 1.00 | Seq Scan | 0.033 | 56.764 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | brin | 10 | 82.132 | 80.443–84.535 | 85.374 | 3.1% | 0.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 82.203 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | btree | 10 | 0.431 | 0.419–0.464 | 0.538 | 10.5% | 128.63 | Index Only Scan | 0.036 | 0.467 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | btree_tuned | 10 | 0.426 | 0.420–0.435 | 0.446 | 2.6% | 129.99 | Index Only Scan | 0.038 | 0.461 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | gin | 10 | 5.579 | 5.220–5.745 | 6.399 | 9.4% | 9.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 5.651 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | gist | 10 | 0.779 | 0.751–0.823 | 0.873 | 6.3% | 71.17 | Index Only Scan | 0.036 | 0.822 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | hash (partial) | 10 | 3.811 | 3.623–4.031 | 4.143 | 7.2% | 14.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 3.853 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | roaring | 10 | 0.183 | 0.165–0.213 | 0.248 | 18.6% | 302.12 | RoaringCount | 0.038 | 0.225 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | roaring_bitmap | 10 | 3.371 | 3.130–3.446 | 3.582 | 5.9% | 16.45 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 3.410 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | seq | 10 | 55.439 | 54.877–58.289 | 60.228 | 4.1% | 1.00 | Seq Scan | 0.030 | 55.466 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | brin | 10 | 115.040 | 110.363–119.745 | 121.533 | 4.3% | 0.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 115.094 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | btree | 10 | 61.794 | 61.034–63.281 | 69.834 | 6.7% | 1.39 | Index Only Scan | 0.037 | 61.831 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | btree_tuned | 10 | 61.697 | 60.279–63.992 | 67.034 | 4.4% | 1.40 | Index Only Scan | 0.036 | 61.732 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | gin | 10 | 143.459 | 140.831–146.832 | 147.083 | 2.7% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 143.509 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | gist | 10 | 137.954 | 133.217–146.200 | 149.720 | 5.1% | 0.62 | Index Only Scan | 0.036 | 137.990 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | hash (partial) | 10 | 85.210 | 83.577–89.401 | 90.264 | 3.3% | 1.01 | Seq Scan (fallback) | 0.031 | 85.248 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | roaring | 10 | 2.879 | 2.741–3.063 | 3.336 | 8.6% | 29.91 | RoaringCount | 0.039 | 2.917 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | roaring_bitmap | 10 | 86.769 | 85.022–89.710 | 93.286 | 4.0% | 0.99 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 86.809 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | seq | 10 | 86.108 | 84.964–88.684 | 93.780 | 4.7% | 1.00 | Seq Scan | 0.031 | 86.138 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | brin | 10 | 72.209 | 70.012–75.695 | 75.995 | 3.7% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 72.264 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | btree | 10 | 3.484 | 3.056–3.831 | 4.651 | 19.3% | 14.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.526 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | btree_tuned | 10 | 0.652 | 0.645–0.694 | 0.710 | 4.2% | 77.73 | Index Only Scan | 0.043 | 0.702 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | gin | 10 | 5.152 | 4.953–5.460 | 5.777 | 7.4% | 9.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 5.199 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | gist | 10 | 3.336 | 3.009–3.540 | 4.087 | 13.1% | 15.19 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 3.377 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | hash (partial) | 10 | 3.458 | 3.192–3.554 | 3.999 | 10.1% | 14.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 3.509 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | roaring | 10 | 3.391 | 2.933–3.549 | 3.999 | 12.4% | 14.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.432 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | roaring_bitmap | 10 | 3.252 | 3.031–3.484 | 3.779 | 9.6% | 15.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.304 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | seq | 10 | 50.677 | 48.314–51.845 | 54.920 | 5.8% | 1.00 | Seq Scan | 0.034 | 50.710 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | brin | 10 | 138.813 | 135.622–143.257 | 146.891 | 3.8% | 0.98 | Seq Scan (fallback) | 0.048 | 138.858 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | btree | 10 | 87.860 | 85.977–91.328 | 94.764 | 4.4% | 1.55 | Index Only Scan | 0.039 | 87.897 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | btree_tuned | 10 | 92.992 | 88.367–98.620 | 101.683 | 6.1% | 1.46 | Index Only Scan | 0.043 | 93.035 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | gin | 10 | 136.510 | 134.258–139.808 | 141.902 | 3.3% | 1.00 | Seq Scan (fallback) | 0.035 | 136.542 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | gist | 10 | 215.403 | 210.607–216.898 | 218.987 | 1.9% | 0.63 | Index Only Scan | 0.040 | 215.452 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | hash (partial) | 10 | 133.776 | 132.388–141.922 | 147.666 | 4.9% | 1.02 | Seq Scan (fallback) | 0.032 | 133.808 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | roaring | 10 | 4.667 | 4.341–4.779 | 4.808 | 4.7% | 29.19 | RoaringCount | 0.035 | 4.701 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | roaring_bitmap | 10 | 134.284 | 130.372–140.593 | 141.004 | 3.6% | 1.01 | Seq Scan (fallback) | 0.036 | 134.320 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | seq | 10 | 136.213 | 132.690–138.387 | 141.147 | 2.8% | 1.00 | Seq Scan | 0.033 | 136.243 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | brin | 10 | 160.404 | 153.580–162.073 | 167.755 | 4.3% | 0.95 | Seq Scan (fallback) | 0.042 | 160.452 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | btree | 10 | 108.014 | 105.524–113.458 | 121.536 | 6.3% | 1.42 | Index Only Scan | 0.040 | 108.058 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | btree_tuned | 10 | 119.305 | 116.756–123.143 | 124.883 | 3.3% | 1.28 | Index Only Scan | 0.044 | 119.353 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | gin | 10 | 154.659 | 150.956–157.347 | 160.390 | 2.8% | 0.99 | Seq Scan (fallback) | 0.036 | 154.707 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | gist | 10 | 219.683 | 216.433–229.338 | 231.210 | 2.8% | 0.70 | Index Only Scan | 0.035 | 219.722 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | hash (partial) | 10 | 155.079 | 150.776–158.109 | 159.840 | 2.9% | 0.99 | Seq Scan (fallback) | 0.038 | 155.133 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | roaring | 10 | 24.622 | 23.582–25.760 | 26.079 | 4.6% | 6.22 | RoaringCount | 0.035 | 24.655 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | roaring_bitmap | 10 | 154.379 | 150.471–161.166 | 162.198 | 3.3% | 0.99 | Seq Scan (fallback) | 0.035 | 154.425 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | seq | 10 | 153.031 | 150.016–154.751 | 156.047 | 2.1% | 1.00 | Seq Scan | 0.033 | 153.064 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | brin | 10 | 76.660 | 71.562–79.686 | 84.922 | 7.6% | 0.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 76.727 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | btree | 10 | 3.667 | 3.397–4.114 | 4.307 | 12.4% | 13.29 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 3.731 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | btree_tuned | 10 | 0.606 | 0.593–0.653 | 0.698 | 7.2% | 80.44 | Index Only Scan | 0.056 | 0.659 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | gin | 10 | 5.415 | 5.217–5.617 | 5.839 | 5.5% | 9.00 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 5.467 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | gist | 10 | 3.550 | 3.416–3.776 | 3.956 | 7.1% | 13.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.590 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | hash (partial) | 10 | 3.479 | 3.291–3.649 | 3.926 | 7.6% | 14.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 3.529 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | roaring | 10 | 2.789 | 2.704–2.821 | 2.869 | 3.0% | 17.47 | RoaringCount | 0.046 | 2.836 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | roaring_bitmap | 10 | 3.389 | 3.287–3.542 | 3.701 | 5.3% | 14.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 3.433 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | seq | 10 | 48.745 | 47.025–51.730 | 56.085 | 7.3% | 1.00 | Seq Scan | 0.037 | 48.786 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | brin | 10 | 98.139 | 94.429–104.803 | 112.119 | 7.1% | 0.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 98.197 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | btree | 10 | 7.884 | 7.627–8.643 | 9.829 | 11.1% | 9.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 7.947 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | btree_tuned | 10 | 0.246 | 0.242–0.303 | 0.375 | 20.7% | 290.79 | Index Only Scan | 0.054 | 0.302 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | gin | 10 | 24.791 | 24.076–25.995 | 29.315 | 8.7% | 2.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 24.845 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | gist | 10 | 11.477 | 11.282–11.955 | 12.424 | 4.3% | 6.23 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 11.524 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | hash (partial) | 10 | 8.637 | 8.395–9.838 | 12.027 | 16.0% | 8.28 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 8.697 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | roaring | 10 | 2.153 | 2.095–2.359 | 2.795 | 13.3% | 33.23 | RoaringCount | 0.054 | 2.208 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | roaring_bitmap | 10 | 6.662 | 6.464–6.690 | 7.297 | 5.5% | 10.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 6.710 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | seq | 10 | 71.535 | 70.477–73.521 | 75.417 | 3.2% | 1.00 | Seq Scan | 0.039 | 71.572 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | brin | 10 | 59.662 | 57.952–61.457 | 63.903 | 4.1% | 1.19 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 59.721 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | btree | 10 | 0.079 | 0.072–0.100 | 0.154 | 41.2% | 898.01 | Index Only Scan | 0.043 | 0.123 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | btree_tuned | 10 | 0.074 | 0.072–0.095 | 0.098 | 15.6% | 958.68 | Index Only Scan | 0.045 | 0.119 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | gin | 10 | 16.204 | 15.392–18.139 | 20.001 | 11.0% | 4.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 16.282 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | gist | 10 | 0.577 | 0.567–0.613 | 0.634 | 5.8% | 123.06 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.622 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | hash (partial) | 10 | 0.456 | 0.442–0.507 | 0.568 | 12.0% | 155.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 0.508 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | roaring | 10 | 0.089 | 0.086–0.098 | 0.112 | 11.3% | 792.65 | RoaringCount | 0.048 | 0.140 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | roaring_bitmap | 10 | 0.413 | 0.382–0.452 | 0.464 | 10.8% | 171.77 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 0.467 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | seq | 10 | 70.942 | 69.342–72.316 | 74.120 | 2.7% | 1.00 | Seq Scan | 0.035 | 70.977 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | brin | 10 | 513.773 | 509.648–516.933 | 521.507 | 1.1% | 0.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.470 | 514.229 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | btree | 10 | 4.576 | 4.430–4.625 | 4.690 | 2.6% | 17.16 | Index Only Scan | 0.443 | 5.027 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | btree_tuned | 10 | 4.774 | 4.651–4.867 | 5.097 | 4.2% | 16.45 | Index Only Scan | 0.440 | 5.240 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | gin | 10 | 1630.664 | 1604.199–1650.905 | 1662.426 | 1.5% | 0.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.621 | 1631.312 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | gist | 10 | 36.960 | 36.531–38.266 | 39.020 | 2.9% | 2.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.469 | 37.434 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | hash (partial) | 10 | 25.199 | 23.789–27.898 | 30.436 | 10.7% | 3.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.445 | 25.656 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | roaring | 10 | 19.280 | 17.893–22.230 | 26.447 | 18.3% | 4.07 | RoaringCount | 0.816 | 20.116 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | roaring_bitmap | 10 | 19.925 | 19.332–21.671 | 21.929 | 5.9% | 3.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.459 | 20.389 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | seq | 10 | 78.526 | 74.052–81.483 | 84.836 | 5.5% | 1.00 | Seq Scan | 0.434 | 79.037 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | brin | 10 | 81.491 | 80.470–87.983 | 91.404 | 5.6% | 0.76 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 81.534 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | btree | 10 | 7.886 | 7.680–8.068 | 9.096 | 7.8% | 7.88 | Index Only Scan | 0.033 | 7.918 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | btree_tuned | 10 | 7.918 | 7.748–8.080 | 9.082 | 7.9% | 7.84 | Index Only Scan | 0.032 | 7.950 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | gin | 10 | 62.373 | 59.510–65.243 | 67.653 | 5.5% | 1.00 | Seq Scan (fallback) | 0.030 | 62.404 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | gist | 10 | 21.767 | 20.870–22.773 | 24.601 | 7.1% | 2.85 | Index Only Scan | 0.032 | 21.800 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | hash (partial) | 10 | 59.133 | 58.435–61.593 | 64.306 | 4.6% | 1.05 | Seq Scan (fallback) | 0.026 | 59.168 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | roaring | 10 | 0.928 | 0.886–1.084 | 1.114 | 10.6% | 66.93 | RoaringCount | 0.033 | 0.961 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | roaring_bitmap | 10 | 26.540 | 25.922–27.986 | 29.848 | 6.1% | 2.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 26.572 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | seq | 10 | 62.108 | 59.834–64.899 | 67.321 | 5.3% | 1.00 | Seq Scan | 0.029 | 62.137 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | brin | 10 | 80.883 | 78.220–84.409 | 88.428 | 5.0% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 80.948 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | btree | 10 | 0.468 | 0.453–0.501 | 0.530 | 6.6% | 121.45 | Index Only Scan | 0.054 | 0.532 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | btree_tuned | 10 | 0.484 | 0.472–0.501 | 0.511 | 3.7% | 117.43 | Index Only Scan | 0.056 | 0.550 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | gin | 10 | 44.658 | 44.304–48.680 | 51.820 | 6.9% | 1.27 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 44.720 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | gist | 10 | 0.893 | 0.879–0.940 | 0.988 | 5.4% | 63.65 | Index Only Scan | 0.042 | 0.936 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | hash (partial) | 10 | 58.017 | 55.830–60.819 | 61.860 | 5.3% | 0.98 | Seq Scan (fallback) | 0.037 | 58.052 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | roaring | 10 | 66.748 | 55.486–76.131 | 85.139 | 17.2% | 0.85 | Seq Scan (fallback) | 0.040 | 66.800 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | roaring_bitmap | 10 | 55.477 | 54.223–62.175 | 65.350 | 8.2% | 1.02 | Seq Scan (fallback) | 0.039 | 55.514 |
| scalar | 1000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | seq | 10 | 56.838 | 55.361–59.143 | 59.833 | 3.5% | 1.00 | Seq Scan | 0.034 | 56.872 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and2 | brin | 10 | 74.886 | 71.287–78.924 | 82.834 | 6.0% | 0.63 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 74.946 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and2 | btree | 10 | 2.961 | 2.896–3.045 | 3.156 | 5.3% | 15.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 3.012 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and2 | btree_tuned | 10 | 0.793 | 0.739–0.958 | 1.040 | 16.8% | 59.10 | Index Only Scan | 0.066 | 0.842 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and2 | gin | 10 | 38.806 | 36.453–40.093 | 41.176 | 5.3% | 1.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 38.867 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and2 | gist | 10 | 3.133 | 3.050–3.418 | 3.516 | 6.3% | 14.96 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.174 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and2 | hash (partial) | 10 | 3.256 | 2.825–3.684 | 4.108 | 16.4% | 14.39 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 3.312 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and2 | roaring | 10 | 0.422 | 0.406–0.442 | 0.477 | 6.9% | 111.06 | RoaringCount | 0.048 | 0.469 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and2 | roaring_bitmap | 10 | 7.038 | 6.828–7.293 | 7.465 | 4.2% | 6.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 7.080 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and2 | seq | 10 | 46.866 | 46.096–49.804 | 54.394 | 7.4% | 1.00 | Seq Scan | 0.032 | 46.903 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and3 | brin | 10 | 71.730 | 70.473–78.044 | 81.217 | 6.4% | 0.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 71.790 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and3 | btree | 10 | 2.863 | 2.692–2.951 | 3.193 | 7.3% | 16.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 2.927 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and3 | btree_tuned | 10 | 0.064 | 0.061–0.072 | 0.105 | 28.8% | 747.17 | Index Only Scan | 0.054 | 0.119 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and3 | gin | 10 | 8.754 | 8.564–9.232 | 10.298 | 8.3% | 5.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 8.820 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and3 | gist | 10 | 4.042 | 4.006–4.209 | 4.344 | 3.6% | 11.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 4.103 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and3 | hash (partial) | 10 | 3.196 | 3.150–3.493 | 3.811 | 8.5% | 14.96 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 3.245 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and3 | roaring | 10 | 0.283 | 0.270–0.315 | 0.325 | 7.8% | 168.97 | RoaringCount | 0.053 | 0.350 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and3 | roaring_bitmap | 10 | 2.487 | 2.429–2.561 | 2.701 | 4.8% | 19.22 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 2.549 |
| scalar | 1000000 | dirty_scattered | default | 64MB | and3 | seq | 10 | 47.819 | 45.850–51.584 | 53.091 | 6.3% | 1.00 | Seq Scan | 0.035 | 47.858 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | brin | 10 | 76.495 | 74.932–78.190 | 78.955 | 2.3% | 0.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 76.543 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | btree | 10 | 0.020 | 0.018–0.021 | 0.031 | 30.3% | 2550.90 | Index Only Scan | 0.036 | 0.055 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | btree_tuned | 10 | 0.022 | 0.020–0.036 | 0.053 | 46.7% | 2267.47 | Index Only Scan | 0.037 | 0.061 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | gin | 10 | 1.558 | 1.551–1.637 | 1.758 | 5.3% | 32.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 1.611 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | gist | 10 | 0.030 | 0.030–0.036 | 0.041 | 14.4% | 1700.60 | Index Only Scan | 0.035 | 0.065 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | hash (partial) | 10 | 0.020 | 0.019–0.021 | 0.023 | 8.3% | 2550.90 | Index Scan | 0.033 | 0.053 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | roaring | 10 | 0.012 | 0.011–0.013 | 0.013 | 7.8% | 4251.50 | RoaringCount | 0.040 | 0.052 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | roaring_bitmap | 10 | 0.022 | 0.021–0.024 | 0.027 | 11.2% | 2267.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 0.058 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | seq | 10 | 51.018 | 49.354–53.464 | 57.467 | 6.4% | 1.00 | Seq Scan | 0.028 | 51.048 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c200_17 | brin | 10 | 73.727 | 72.098–77.553 | 81.205 | 5.0% | 0.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 73.773 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c200_17 | btree | 10 | 0.439 | 0.407–0.448 | 0.540 | 13.9% | 112.04 | Index Only Scan | 0.043 | 0.482 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c200_17 | btree_tuned | 10 | 1.474 | 1.331–1.749 | 1.855 | 15.4% | 33.34 | Index Only Scan | 0.066 | 1.548 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c200_17 | gin | 10 | 4.838 | 4.478–5.157 | 5.608 | 9.2% | 10.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 4.880 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c200_17 | gist | 10 | 0.817 | 0.811–0.859 | 0.910 | 4.9% | 60.13 | Index Only Scan | 0.041 | 0.867 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c200_17 | hash (partial) | 10 | 3.333 | 3.169–3.463 | 3.922 | 11.2% | 14.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 3.369 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c200_17 | roaring | 10 | 0.111 | 0.103–0.127 | 0.138 | 14.1% | 444.60 | RoaringCount | 0.038 | 0.147 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c200_17 | roaring_bitmap | 10 | 3.069 | 2.955–3.494 | 3.921 | 12.5% | 16.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 3.110 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c200_17 | seq | 10 | 49.128 | 48.402–52.497 | 54.258 | 5.2% | 1.00 | Seq Scan | 0.029 | 49.156 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20_3 | brin | 10 | 51.433 | 49.001–51.720 | 52.590 | 3.6% | 0.98 | Seq Scan (fallback) | 0.051 | 51.483 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20_3 | btree | 10 | 19.572 | 18.936–21.156 | 22.205 | 7.6% | 2.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 19.607 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20_3 | btree_tuned | 10 | 19.554 | 18.497–22.170 | 22.883 | 10.5% | 2.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 19.602 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20_3 | gin | 10 | 23.744 | 22.914–25.108 | 25.462 | 5.2% | 2.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 23.813 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20_3 | gist | 10 | 18.943 | 18.165–21.208 | 21.376 | 8.0% | 2.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 18.980 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20_3 | hash (partial) | 10 | 21.944 | 20.611–23.990 | 25.553 | 9.3% | 2.30 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 21.980 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20_3 | roaring | 10 | 18.566 | 17.506–19.676 | 20.211 | 5.9% | 2.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 18.630 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20_3 | roaring_bitmap | 10 | 18.535 | 17.361–19.369 | 21.556 | 9.8% | 2.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 18.569 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20_3 | seq | 10 | 50.421 | 47.871–51.869 | 52.808 | 4.9% | 1.00 | Seq Scan | 0.028 | 50.453 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20k_123 | brin | 10 | 74.659 | 71.930–80.010 | 83.262 | 6.2% | 0.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 74.723 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20k_123 | btree | 10 | 0.027 | 0.023–0.029 | 0.031 | 13.4% | 1836.43 | Index Only Scan | 0.041 | 0.068 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20k_123 | btree_tuned | 10 | 0.038 | 0.034–0.044 | 0.057 | 22.2% | 1287.88 | Index Only Scan | 0.041 | 0.079 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20k_123 | gin | 10 | 1.673 | 1.587–1.732 | 1.785 | 5.1% | 29.63 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 1.728 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20k_123 | gist | 10 | 0.043 | 0.040–0.052 | 0.058 | 17.5% | 1153.10 | Index Only Scan | 0.038 | 0.081 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20k_123 | hash (partial) | 10 | 0.054 | 0.052–0.068 | 0.073 | 15.1% | 909.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 0.090 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20k_123 | roaring | 10 | 0.015 | 0.014–0.015 | 0.016 | 7.0% | 3305.57 | RoaringCount | 0.038 | 0.053 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20k_123 | roaring_bitmap | 10 | 0.057 | 0.053–0.067 | 0.071 | 13.0% | 877.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 0.100 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c20k_123 | seq | 10 | 49.584 | 48.295–55.025 | 57.164 | 7.6% | 1.00 | Seq Scan | 0.029 | 49.612 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c2_0 | brin | 10 | 68.505 | 65.501–73.547 | 75.254 | 6.1% | 1.01 | Seq Scan (fallback) | 0.050 | 68.553 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c2_0 | btree | 10 | 73.716 | 72.648–76.839 | 80.233 | 4.6% | 0.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 73.749 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c2_0 | btree_tuned | 10 | 76.608 | 73.293–79.563 | 80.493 | 4.5% | 0.90 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 76.647 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c2_0 | gin | 10 | 96.555 | 94.280–99.545 | 102.257 | 3.4% | 0.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 96.596 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c2_0 | gist | 10 | 67.948 | 67.593–70.156 | 72.244 | 4.0% | 1.01 | Seq Scan (fallback) | 0.036 | 67.985 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c2_0 | hash (partial) | 10 | 69.228 | 64.742–73.590 | 77.383 | 7.4% | 1.00 | Seq Scan (fallback) | 0.035 | 69.270 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c2_0 | roaring | 10 | 66.404 | 65.325–69.515 | 70.524 | 3.7% | 1.04 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 66.461 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c2_0 | roaring_bitmap | 10 | 68.038 | 66.330–70.686 | 76.117 | 6.3% | 1.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 68.087 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_c2_0 | seq | 10 | 68.953 | 66.968–70.869 | 72.742 | 4.1% | 1.00 | Seq Scan | 0.028 | 68.988 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_clustered_17 | brin | 10 | 4.200 | 4.065–4.341 | 4.959 | 9.8% | 12.44 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 4.256 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_clustered_17 | btree | 10 | 0.322 | 0.315–0.361 | 0.428 | 14.4% | 162.47 | Index Only Scan | 0.037 | 0.365 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_clustered_17 | btree_tuned | 10 | 0.458 | 0.422–0.479 | 0.484 | 7.3% | 114.17 | Index Only Scan | 0.039 | 0.498 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_clustered_17 | gin | 10 | 2.260 | 2.225–2.333 | 2.418 | 3.4% | 23.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 2.308 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_clustered_17 | gist | 10 | 0.724 | 0.714–0.768 | 0.837 | 7.1% | 72.15 | Index Only Scan | 0.036 | 0.766 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_clustered_17 | hash (partial) | 10 | 0.698 | 0.681–0.757 | 0.893 | 12.8% | 74.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 0.746 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_clustered_17 | roaring | 10 | 0.011 | 0.011–0.013 | 0.015 | 15.3% | 4542.00 | RoaringCount | 0.040 | 0.052 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_clustered_17 | roaring_bitmap | 10 | 0.450 | 0.434–0.470 | 0.655 | 23.9% | 116.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 0.498 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_clustered_17 | seq | 10 | 52.233 | 51.417–54.880 | 57.840 | 4.9% | 1.00 | Seq Scan | 0.029 | 52.263 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_nullable_17 | brin | 10 | 56.034 | 54.438–59.093 | 61.920 | 5.2% | 1.00 | Seq Scan (fallback) | 0.051 | 56.084 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_nullable_17 | btree | 10 | 0.419 | 0.397–0.445 | 0.520 | 12.7% | 133.95 | Index Only Scan | 0.042 | 0.460 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_nullable_17 | btree_tuned | 10 | 1.212 | 1.062–1.387 | 1.458 | 14.4% | 46.29 | Index Only Scan | 0.038 | 1.249 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_nullable_17 | gin | 10 | 5.399 | 5.222–5.621 | 5.926 | 7.2% | 10.40 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 5.475 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_nullable_17 | gist | 10 | 0.746 | 0.732–0.776 | 0.791 | 3.4% | 75.18 | Index Only Scan | 0.036 | 0.781 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_nullable_17 | hash (partial) | 10 | 3.564 | 3.351–3.841 | 3.966 | 9.2% | 15.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 3.595 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_nullable_17 | roaring | 10 | 0.144 | 0.123–0.193 | 0.210 | 23.7% | 388.40 | RoaringCount | 0.039 | 0.183 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_nullable_17 | roaring_bitmap | 10 | 3.372 | 3.067–3.591 | 3.805 | 9.3% | 16.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 3.415 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_nullable_17 | seq | 10 | 56.124 | 54.415–60.228 | 63.593 | 6.7% | 1.00 | Seq Scan | 0.028 | 56.154 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_skew_0 | brin | 10 | 85.906 | 82.498–88.076 | 90.802 | 3.8% | 0.99 | Seq Scan (fallback) | 0.051 | 85.964 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_skew_0 | btree | 10 | 85.800 | 83.068–89.127 | 90.134 | 3.8% | 0.99 | Seq Scan (fallback) | 0.035 | 85.838 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_skew_0 | btree_tuned | 10 | 93.441 | 89.849–95.849 | 98.774 | 4.0% | 0.91 | Seq Scan (fallback) | 0.066 | 93.493 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_skew_0 | gin | 10 | 86.222 | 83.477–89.459 | 93.788 | 5.1% | 0.99 | Seq Scan (fallback) | 0.038 | 86.261 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_skew_0 | gist | 10 | 86.501 | 84.691–89.537 | 92.697 | 4.2% | 0.98 | Seq Scan (fallback) | 0.036 | 86.535 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_skew_0 | hash (partial) | 10 | 86.257 | 83.049–87.601 | 88.736 | 3.1% | 0.99 | Seq Scan (fallback) | 0.031 | 86.293 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_skew_0 | roaring | 10 | 86.803 | 84.590–88.492 | 89.798 | 2.7% | 0.98 | Seq Scan (fallback) | 0.040 | 86.844 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_skew_0 | roaring_bitmap | 10 | 87.143 | 86.006–90.561 | 93.240 | 3.6% | 0.98 | Seq Scan (fallback) | 0.034 | 87.180 |
| scalar | 1000000 | dirty_scattered | default | 64MB | eq_skew_0 | seq | 10 | 85.107 | 84.073–87.470 | 92.094 | 4.1% | 1.00 | Seq Scan | 0.031 | 85.142 |
| scalar | 1000000 | dirty_scattered | default | 64MB | fetch_medium | brin | 10 | 73.369 | 72.278–76.586 | 78.644 | 3.7% | 0.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 73.427 |
| scalar | 1000000 | dirty_scattered | default | 64MB | fetch_medium | btree | 10 | 3.154 | 3.044–3.268 | 3.427 | 6.8% | 15.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.204 |
| scalar | 1000000 | dirty_scattered | default | 64MB | fetch_medium | btree_tuned | 10 | 1.606 | 1.368–1.914 | 2.076 | 18.2% | 29.49 | Index Only Scan | 0.046 | 1.652 |
| scalar | 1000000 | dirty_scattered | default | 64MB | fetch_medium | gin | 10 | 4.912 | 4.794–5.183 | 5.515 | 6.1% | 9.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 4.968 |
| scalar | 1000000 | dirty_scattered | default | 64MB | fetch_medium | gist | 10 | 3.303 | 3.178–3.436 | 3.587 | 6.4% | 14.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.377 |
| scalar | 1000000 | dirty_scattered | default | 64MB | fetch_medium | hash (partial) | 10 | 3.429 | 2.961–3.707 | 3.929 | 11.6% | 13.81 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 3.473 |
| scalar | 1000000 | dirty_scattered | default | 64MB | fetch_medium | roaring | 10 | 3.325 | 3.070–3.620 | 4.188 | 14.8% | 14.25 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.374 |
| scalar | 1000000 | dirty_scattered | default | 64MB | fetch_medium | roaring_bitmap | 10 | 3.301 | 3.082–3.620 | 4.050 | 12.0% | 14.35 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.343 |
| scalar | 1000000 | dirty_scattered | default | 64MB | fetch_medium | seq | 10 | 47.361 | 46.987–49.843 | 51.575 | 4.3% | 1.00 | Seq Scan | 0.031 | 47.392 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c2 | brin | 10 | 136.624 | 133.772–139.827 | 144.326 | 3.6% | 0.96 | Seq Scan (fallback) | 0.045 | 136.666 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c2 | btree | 10 | 135.399 | 133.784–141.290 | 142.240 | 3.1% | 0.97 | Seq Scan (fallback) | 0.040 | 135.440 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c2 | btree_tuned | 10 | 149.438 | 143.831–153.987 | 157.013 | 4.5% | 0.88 | Seq Scan (fallback) | 0.044 | 149.486 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c2 | gin | 10 | 137.050 | 134.810–142.610 | 144.263 | 3.1% | 0.96 | Seq Scan (fallback) | 0.040 | 137.088 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c2 | gist | 10 | 139.630 | 134.015–141.163 | 147.434 | 5.1% | 0.94 | Seq Scan (fallback) | 0.036 | 139.664 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c2 | hash (partial) | 10 | 136.887 | 133.652–142.993 | 150.852 | 5.1% | 0.96 | Seq Scan (fallback) | 0.035 | 136.922 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c2 | roaring | 10 | 132.927 | 131.328–136.274 | 139.650 | 2.8% | 0.99 | Seq Scan (fallback) | 0.038 | 132.966 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c2 | roaring_bitmap | 10 | 137.572 | 133.435–141.790 | 143.750 | 3.3% | 0.95 | Seq Scan (fallback) | 0.034 | 137.612 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c2 | seq | 10 | 131.316 | 128.659–138.188 | 147.203 | 6.3% | 1.00 | Seq Scan | 0.030 | 131.348 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c200 | brin | 10 | 154.206 | 152.654–157.756 | 162.436 | 2.6% | 0.99 | Seq Scan (fallback) | 0.045 | 154.255 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c200 | btree | 10 | 155.917 | 150.825–159.666 | 162.707 | 3.2% | 0.98 | Seq Scan (fallback) | 0.042 | 155.965 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c200 | btree_tuned | 10 | 161.633 | 159.202–165.809 | 170.080 | 2.9% | 0.94 | Seq Scan (fallback) | 0.049 | 161.685 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c200 | gin | 10 | 156.200 | 153.476–162.813 | 167.257 | 3.8% | 0.97 | Seq Scan (fallback) | 0.033 | 156.244 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c200 | gist | 10 | 154.678 | 152.023–157.969 | 162.990 | 3.0% | 0.98 | Seq Scan (fallback) | 0.036 | 154.719 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c200 | hash (partial) | 10 | 157.096 | 155.062–160.357 | 168.599 | 3.9% | 0.97 | Seq Scan (fallback) | 0.043 | 157.142 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c200 | roaring | 10 | 155.397 | 152.106–158.805 | 166.821 | 4.3% | 0.98 | Seq Scan (fallback) | 0.036 | 155.431 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c200 | roaring_bitmap | 10 | 154.184 | 151.522–157.927 | 161.802 | 2.6% | 0.99 | Seq Scan (fallback) | 0.036 | 154.223 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_c200 | seq | 10 | 152.061 | 149.000–157.109 | 161.798 | 3.8% | 1.00 | Seq Scan | 0.032 | 152.094 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_filtered | brin | 10 | 74.457 | 72.396–78.662 | 78.781 | 4.2% | 0.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 74.531 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_filtered | btree | 10 | 3.404 | 3.245–3.610 | 3.832 | 7.9% | 14.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 3.457 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_filtered | btree_tuned | 10 | 1.603 | 1.415–2.092 | 2.565 | 26.7% | 29.88 | Index Only Scan | 0.058 | 1.660 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_filtered | gin | 10 | 5.310 | 5.133–5.546 | 5.937 | 6.5% | 9.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 5.385 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_filtered | gist | 10 | 3.686 | 3.396–4.178 | 5.083 | 18.7% | 12.99 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 3.737 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_filtered | hash (partial) | 10 | 3.485 | 3.321–3.714 | 4.012 | 8.3% | 13.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.528 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_filtered | roaring | 10 | 2.744 | 2.702–2.793 | 3.075 | 6.4% | 17.45 | RoaringCount | 0.049 | 2.795 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_filtered | roaring_bitmap | 10 | 3.465 | 3.370–3.848 | 4.117 | 9.2% | 13.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 3.508 |
| scalar | 1000000 | dirty_scattered | default | 64MB | group_filtered | seq | 10 | 47.884 | 46.957–49.409 | 51.092 | 3.6% | 1.00 | Seq Scan | 0.041 | 47.921 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_and | brin | 10 | 72.724 | 70.816–74.763 | 77.718 | 4.2% | 1.00 | Seq Scan (fallback) | 0.063 | 72.787 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_and | btree | 10 | 7.373 | 7.213–7.905 | 8.367 | 6.4% | 9.88 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 7.421 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_and | btree_tuned | 10 | 0.700 | 0.641–0.713 | 0.778 | 8.6% | 104.04 | Index Only Scan | 0.056 | 0.758 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_and | gin | 10 | 25.608 | 24.888–26.540 | 27.549 | 5.1% | 2.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 25.663 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_and | gist | 10 | 11.334 | 10.940–11.664 | 11.830 | 3.5% | 6.43 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 11.381 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_and | hash (partial) | 10 | 8.736 | 8.275–9.053 | 9.458 | 5.6% | 8.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 8.806 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_and | roaring | 10 | 2.112 | 2.077–2.173 | 2.293 | 4.7% | 34.49 | RoaringCount | 0.056 | 2.162 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_and | roaring_bitmap | 10 | 6.577 | 6.247–6.848 | 7.658 | 9.4% | 11.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 6.627 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_and | seq | 10 | 72.828 | 70.884–74.880 | 76.354 | 3.6% | 1.00 | Seq Scan | 0.039 | 72.870 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_10 | brin | 10 | 59.954 | 58.886–61.400 | 63.176 | 3.0% | 1.17 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 60.008 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_10 | btree | 10 | 0.071 | 0.069–0.077 | 0.091 | 12.6% | 989.91 | Index Only Scan | 0.042 | 0.113 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_10 | btree_tuned | 10 | 0.191 | 0.175–0.231 | 0.259 | 16.7% | 367.98 | Index Only Scan | 0.050 | 0.240 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_10 | gin | 10 | 15.458 | 15.146–15.841 | 16.437 | 3.3% | 4.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 15.532 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_10 | gist | 10 | 0.563 | 0.544–0.627 | 0.682 | 10.6% | 124.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.607 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_10 | hash (partial) | 10 | 0.465 | 0.428–0.536 | 0.567 | 14.1% | 151.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 0.532 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_10 | roaring | 10 | 0.093 | 0.089–0.122 | 0.152 | 24.3% | 755.74 | RoaringCount | 0.050 | 0.143 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_10 | roaring_bitmap | 10 | 0.415 | 0.394–0.444 | 0.497 | 10.0% | 169.36 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 0.460 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_10 | seq | 10 | 70.284 | 68.927–73.338 | 76.683 | 4.9% | 1.00 | Seq Scan | 0.037 | 70.321 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_1000 | brin | 10 | 75.150 | 74.192–75.762 | 79.616 | 2.9% | 1.04 | Seq Scan (fallback) | 0.468 | 75.806 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_1000 | btree | 10 | 20.706 | 18.573–22.455 | 22.812 | 11.0% | 3.77 | Bitmap Heap Scan, Bitmap Index Scan | 0.446 | 21.151 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_1000 | btree_tuned | 10 | 20.082 | 19.260–21.151 | 23.398 | 8.6% | 3.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.461 | 20.544 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_1000 | gin | 10 | 78.891 | 73.830–82.815 | 85.203 | 5.8% | 0.99 | Seq Scan (fallback) | 0.646 | 79.628 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_1000 | gist | 10 | 38.148 | 36.222–40.865 | 43.666 | 8.3% | 2.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.446 | 38.614 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_1000 | hash (partial) | 10 | 24.639 | 24.117–25.348 | 27.151 | 5.2% | 3.17 | Bitmap Heap Scan, Bitmap Index Scan | 0.448 | 25.100 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_1000 | roaring | 10 | 21.338 | 20.163–22.642 | 23.589 | 7.0% | 3.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.800 | 22.139 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_1000 | roaring_bitmap | 10 | 20.623 | 19.863–21.687 | 23.446 | 8.0% | 3.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.455 | 21.094 |
| scalar | 1000000 | dirty_scattered | default | 64MB | in_c20k_1000 | seq | 10 | 78.136 | 73.515–81.370 | 84.782 | 6.5% | 1.00 | Seq Scan | 0.439 | 78.690 |
| scalar | 1000000 | dirty_scattered | default | 64MB | is_null | brin | 10 | 57.560 | 56.885–60.520 | 62.328 | 3.9% | 1.03 | Seq Scan (fallback) | 0.042 | 57.606 |
| scalar | 1000000 | dirty_scattered | default | 64MB | is_null | btree | 10 | 28.398 | 26.910–30.036 | 31.696 | 6.8% | 2.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 28.435 |
| scalar | 1000000 | dirty_scattered | default | 64MB | is_null | btree_tuned | 10 | 30.392 | 29.096–31.600 | 33.587 | 6.5% | 1.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 30.434 |
| scalar | 1000000 | dirty_scattered | default | 64MB | is_null | gin | 10 | 59.538 | 58.413–61.258 | 63.512 | 4.0% | 0.99 | Seq Scan (fallback) | 0.029 | 59.577 |
| scalar | 1000000 | dirty_scattered | default | 64MB | is_null | gist | 10 | 39.349 | 36.485–41.288 | 43.493 | 7.7% | 1.50 | Bitmap Heap Scan, Bitmap Index Scan | 0.031 | 39.379 |
| scalar | 1000000 | dirty_scattered | default | 64MB | is_null | hash (partial) | 10 | 58.960 | 57.385–61.152 | 62.556 | 4.1% | 1.00 | Seq Scan (fallback) | 0.028 | 58.990 |
| scalar | 1000000 | dirty_scattered | default | 64MB | is_null | roaring | 10 | 27.962 | 25.949–28.880 | 29.137 | 5.3% | 2.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 27.999 |
| scalar | 1000000 | dirty_scattered | default | 64MB | is_null | roaring_bitmap | 10 | 28.061 | 26.980–31.063 | 33.998 | 11.4% | 2.10 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 28.104 |
| scalar | 1000000 | dirty_scattered | default | 64MB | is_null | seq | 10 | 59.019 | 58.054–63.021 | 63.608 | 4.1% | 1.00 | Seq Scan | 0.024 | 59.046 |
| scalar | 1000000 | dirty_scattered | default | 64MB | range_random | brin | 10 | 57.324 | 55.513–60.472 | 61.518 | 4.8% | 0.96 | Seq Scan (fallback) | 0.056 | 57.384 |
| scalar | 1000000 | dirty_scattered | default | 64MB | range_random | btree | 10 | 0.483 | 0.453–0.520 | 0.551 | 8.9% | 113.52 | Index Only Scan | 0.055 | 0.547 |
| scalar | 1000000 | dirty_scattered | default | 64MB | range_random | btree_tuned | 10 | 1.680 | 1.520–1.982 | 2.090 | 16.3% | 32.64 | Index Only Scan | 0.062 | 1.756 |
| scalar | 1000000 | dirty_scattered | default | 64MB | range_random | gin | 10 | 44.559 | 43.889–46.402 | 48.149 | 4.1% | 1.23 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 44.620 |
| scalar | 1000000 | dirty_scattered | default | 64MB | range_random | gist | 10 | 0.900 | 0.858–0.939 | 0.994 | 5.9% | 60.92 | Index Only Scan | 0.042 | 0.947 |
| scalar | 1000000 | dirty_scattered | default | 64MB | range_random | hash (partial) | 10 | 55.486 | 53.314–58.296 | 58.970 | 4.3% | 0.99 | Seq Scan (fallback) | 0.036 | 55.525 |
| scalar | 1000000 | dirty_scattered | default | 64MB | range_random | roaring | 10 | 57.984 | 55.193–59.136 | 61.005 | 4.3% | 0.95 | Seq Scan (fallback) | 0.040 | 58.034 |
| scalar | 1000000 | dirty_scattered | default | 64MB | range_random | roaring_bitmap | 10 | 57.421 | 55.608–59.667 | 61.358 | 4.3% | 0.95 | Seq Scan (fallback) | 0.042 | 57.462 |
| scalar | 1000000 | dirty_scattered | default | 64MB | range_random | seq | 10 | 54.829 | 53.176–56.585 | 58.626 | 4.4% | 1.00 | Seq Scan | 0.034 | 54.863 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and2 | brin | 10 | 73.768 | 72.336–74.800 | 78.166 | 4.1% | 0.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 73.821 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and2 | btree | 10 | 3.171 | 2.938–3.342 | 3.405 | 8.7% | 15.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.229 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and2 | btree_tuned | 10 | 0.756 | 0.701–0.915 | 1.153 | 22.2% | 62.91 | Index Only Scan | 0.050 | 0.809 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and2 | gin | 10 | 37.061 | 36.128–38.207 | 41.779 | 6.9% | 1.28 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 37.108 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and2 | gist | 10 | 3.052 | 2.906–3.208 | 3.507 | 7.9% | 15.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 3.098 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and2 | hash (partial) | 10 | 3.212 | 2.821–3.376 | 3.682 | 10.8% | 14.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 3.252 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and2 | roaring | 10 | 0.423 | 0.409–0.434 | 0.439 | 4.3% | 112.38 | RoaringCount | 0.047 | 0.474 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and2 | roaring_bitmap | 10 | 6.932 | 6.649–7.155 | 8.865 | 14.3% | 6.87 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 6.975 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and2 | seq | 10 | 47.594 | 46.863–52.254 | 55.444 | 7.8% | 1.00 | Seq Scan | 0.034 | 47.633 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and3 | brin | 10 | 72.542 | 70.527–80.543 | 83.663 | 7.6% | 0.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 72.602 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and3 | btree | 10 | 2.950 | 2.834–3.160 | 3.973 | 17.0% | 16.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 3.011 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and3 | btree_tuned | 10 | 0.073 | 0.067–0.097 | 0.102 | 21.1% | 663.50 | Index Only Scan | 0.074 | 0.148 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and3 | gin | 10 | 8.593 | 8.420–9.180 | 9.734 | 6.2% | 5.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 8.649 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and3 | gist | 10 | 4.236 | 3.931–4.480 | 4.597 | 6.7% | 11.51 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 4.297 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and3 | hash (partial) | 10 | 3.236 | 3.162–3.650 | 4.105 | 11.3% | 15.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 3.288 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and3 | roaring | 10 | 0.277 | 0.267–0.299 | 0.407 | 22.3% | 175.74 | RoaringCount | 0.050 | 0.339 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and3 | roaring_bitmap | 10 | 2.511 | 2.355–2.615 | 2.736 | 6.2% | 19.42 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 2.585 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | and3 | seq | 10 | 48.767 | 46.533–51.176 | 51.951 | 5.0% | 1.00 | Seq Scan | 0.035 | 48.800 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | brin | 10 | 76.864 | 74.562–79.648 | 84.564 | 5.8% | 0.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 76.924 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | btree | 10 | 0.021 | 0.019–0.022 | 0.023 | 7.2% | 2463.05 | Index Only Scan | 0.036 | 0.057 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | btree_tuned | 10 | 0.022 | 0.021–0.023 | 0.025 | 8.3% | 2295.11 | Index Only Scan | 0.038 | 0.060 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | gin | 10 | 1.585 | 1.570–1.604 | 1.699 | 4.0% | 31.86 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 1.632 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | gist | 10 | 0.030 | 0.028–0.038 | 0.051 | 28.2% | 1683.08 | Index Only Scan | 0.034 | 0.065 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | hash (partial) | 10 | 0.021 | 0.019–0.024 | 0.038 | 34.6% | 2348.49 | Index Scan | 0.037 | 0.059 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | roaring | 10 | 0.012 | 0.011–0.013 | 0.014 | 12.2% | 4207.71 | RoaringCount | 0.039 | 0.051 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | roaring_bitmap | 10 | 0.023 | 0.022–0.026 | 0.031 | 16.6% | 2195.33 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 0.059 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | seq | 10 | 50.493 | 49.435–51.377 | 54.048 | 4.0% | 1.00 | Seq Scan | 0.025 | 50.517 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | brin | 10 | 73.936 | 72.949–75.977 | 82.562 | 5.7% | 0.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 73.989 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | btree | 10 | 0.403 | 0.397–0.416 | 0.422 | 3.1% | 118.50 | Index Only Scan | 0.036 | 0.439 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | btree_tuned | 10 | 1.434 | 1.313–1.688 | 1.741 | 13.6% | 33.26 | Index Only Scan | 0.043 | 1.491 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | gin | 10 | 4.997 | 4.778–5.165 | 5.750 | 8.9% | 9.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 5.034 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | gist | 10 | 0.820 | 0.794–0.839 | 0.886 | 5.3% | 58.17 | Index Only Scan | 0.036 | 0.855 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | hash (partial) | 10 | 3.279 | 2.833–3.557 | 3.755 | 12.2% | 14.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.033 | 3.312 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | roaring | 10 | 0.113 | 0.107–0.117 | 0.134 | 10.2% | 423.98 | RoaringCount | 0.043 | 0.165 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | roaring_bitmap | 10 | 3.117 | 2.835–3.700 | 4.146 | 16.6% | 15.30 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 3.152 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | seq | 10 | 47.698 | 46.725–51.067 | 52.187 | 5.3% | 1.00 | Seq Scan | 0.030 | 47.728 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | brin | 10 | 75.874 | 73.015–78.372 | 80.167 | 3.9% | 0.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 75.927 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | btree | 10 | 19.823 | 18.495–21.603 | 23.379 | 11.7% | 2.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 19.884 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | btree_tuned | 10 | 19.306 | 18.331–19.981 | 21.671 | 7.0% | 2.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 19.347 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | gin | 10 | 22.951 | 22.267–24.098 | 25.351 | 5.6% | 2.23 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 22.988 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | gist | 10 | 19.230 | 18.874–21.206 | 22.810 | 8.7% | 2.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 19.264 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | hash (partial) | 10 | 21.398 | 20.518–23.597 | 25.614 | 9.1% | 2.40 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 21.444 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | roaring | 10 | 19.482 | 18.880–20.788 | 23.324 | 9.5% | 2.63 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 19.524 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | roaring_bitmap | 10 | 18.713 | 18.473–19.302 | 20.289 | 6.3% | 2.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 18.761 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | seq | 10 | 51.288 | 49.578–53.549 | 54.928 | 4.9% | 1.00 | Seq Scan | 0.027 | 51.318 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | brin | 10 | 76.928 | 75.089–78.803 | 81.908 | 4.1% | 0.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 76.972 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | btree | 10 | 0.025 | 0.025–0.026 | 0.028 | 7.2% | 2002.10 | Index Only Scan | 0.037 | 0.062 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | btree_tuned | 10 | 0.037 | 0.034–0.041 | 0.051 | 18.3% | 1352.77 | Index Only Scan | 0.039 | 0.079 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | gin | 10 | 1.620 | 1.563–1.691 | 1.763 | 4.8% | 30.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 1.667 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | gist | 10 | 0.042 | 0.040–0.046 | 0.050 | 10.0% | 1191.73 | Index Only Scan | 0.045 | 0.087 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | hash (partial) | 10 | 0.056 | 0.053–0.059 | 0.064 | 8.5% | 901.85 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 0.095 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | roaring | 10 | 0.016 | 0.015–0.017 | 0.018 | 7.2% | 3128.28 | RoaringCount | 0.039 | 0.055 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | roaring_bitmap | 10 | 0.060 | 0.055–0.070 | 0.079 | 15.1% | 827.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 0.107 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | seq | 10 | 50.052 | 46.708–52.529 | 55.329 | 6.5% | 1.00 | Seq Scan | 0.028 | 50.081 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | brin | 10 | 94.418 | 92.141–96.158 | 98.268 | 2.8% | 0.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 94.462 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | btree | 10 | 74.181 | 71.527–75.611 | 82.588 | 6.3% | 0.90 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 74.228 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | btree_tuned | 10 | 73.231 | 71.876–78.790 | 81.250 | 5.1% | 0.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 73.290 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | gin | 10 | 96.748 | 95.474–101.329 | 102.446 | 3.5% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 96.885 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | gist | 10 | 85.659 | 82.820–87.146 | 88.961 | 3.3% | 0.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 85.695 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | hash (partial) | 10 | 68.612 | 67.191–74.631 | 75.888 | 5.7% | 0.98 | Seq Scan (fallback) | 0.042 | 68.656 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | roaring | 10 | 67.489 | 65.305–68.346 | 70.063 | 3.4% | 0.99 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 67.526 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | roaring_bitmap | 10 | 66.420 | 65.410–69.559 | 69.999 | 3.6% | 1.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 66.454 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | seq | 10 | 67.046 | 65.133–74.887 | 79.389 | 8.4% | 1.00 | Seq Scan | 0.028 | 67.076 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | brin | 10 | 4.000 | 3.891–4.167 | 4.225 | 3.7% | 13.49 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 4.046 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | btree | 10 | 0.327 | 0.319–0.342 | 0.351 | 4.8% | 165.05 | Index Only Scan | 0.037 | 0.363 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | btree_tuned | 10 | 0.456 | 0.436–0.482 | 0.597 | 15.7% | 118.36 | Index Only Scan | 0.039 | 0.503 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | gin | 10 | 2.320 | 2.279–2.403 | 2.503 | 4.6% | 23.26 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 2.373 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | gist | 10 | 0.740 | 0.725–0.853 | 0.924 | 10.5% | 72.88 | Index Only Scan | 0.037 | 0.779 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | hash (partial) | 10 | 0.704 | 0.678–0.762 | 0.853 | 9.7% | 76.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 0.744 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | roaring | 10 | 0.012 | 0.010–0.014 | 0.016 | 18.6% | 4497.54 | RoaringCount | 0.043 | 0.057 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | roaring_bitmap | 10 | 0.446 | 0.436–0.451 | 0.490 | 5.5% | 121.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 0.481 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | seq | 10 | 53.971 | 51.818–55.632 | 60.158 | 6.6% | 1.00 | Seq Scan | 0.027 | 53.999 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | brin | 10 | 83.610 | 80.435–85.484 | 91.397 | 5.4% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 83.671 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | btree | 10 | 0.410 | 0.394–0.460 | 0.494 | 9.6% | 142.01 | Index Only Scan | 0.036 | 0.447 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | btree_tuned | 10 | 1.344 | 1.213–1.571 | 1.992 | 23.4% | 43.39 | Index Only Scan | 0.040 | 1.384 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | gin | 10 | 5.373 | 5.089–5.543 | 5.926 | 6.2% | 10.85 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 5.428 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | gist | 10 | 0.736 | 0.724–0.766 | 0.780 | 3.0% | 79.26 | Index Only Scan | 0.036 | 0.782 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | hash (partial) | 10 | 3.603 | 3.545–3.822 | 4.067 | 9.8% | 16.18 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 3.638 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | roaring | 10 | 0.141 | 0.132–0.156 | 0.206 | 22.6% | 414.90 | RoaringCount | 0.038 | 0.191 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | roaring_bitmap | 10 | 3.204 | 3.035–3.454 | 3.505 | 8.8% | 18.19 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 3.239 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | seq | 10 | 58.294 | 55.690–59.023 | 65.205 | 6.2% | 1.00 | Seq Scan | 0.031 | 58.323 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | brin | 10 | 111.387 | 108.559–113.743 | 117.398 | 3.3% | 0.76 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 111.436 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | btree | 10 | 61.108 | 58.712–62.063 | 68.130 | 7.0% | 1.39 | Index Only Scan | 0.040 | 61.170 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | btree_tuned | 10 | 85.870 | 83.512–91.713 | 92.774 | 4.8% | 0.99 | Index Only Scan | 0.039 | 85.907 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | gin | 10 | 144.575 | 138.494–148.299 | 150.499 | 3.6% | 0.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 144.626 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | gist | 10 | 117.388 | 114.570–124.205 | 126.090 | 4.4% | 0.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 117.425 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | hash (partial) | 10 | 86.212 | 82.414–89.518 | 92.229 | 4.7% | 0.98 | Seq Scan (fallback) | 0.030 | 86.242 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | roaring | 10 | 87.214 | 84.832–90.985 | 92.129 | 3.5% | 0.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 87.268 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | roaring_bitmap | 10 | 90.096 | 88.328–91.848 | 94.205 | 3.1% | 0.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 90.130 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | seq | 10 | 84.814 | 83.475–86.951 | 94.131 | 5.7% | 1.00 | Seq Scan | 0.026 | 84.840 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | brin | 10 | 73.630 | 71.356–77.169 | 79.395 | 4.7% | 0.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 73.683 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | btree | 10 | 3.173 | 2.947–3.449 | 3.659 | 9.7% | 15.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.224 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | btree_tuned | 10 | 1.515 | 1.385–1.804 | 1.956 | 14.9% | 33.00 | Index Only Scan | 0.044 | 1.558 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | gin | 10 | 5.105 | 4.999–5.487 | 5.736 | 6.2% | 9.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 5.183 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | gist | 10 | 3.157 | 2.972–3.311 | 3.467 | 6.1% | 15.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.198 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | hash (partial) | 10 | 3.440 | 3.178–3.746 | 4.239 | 13.2% | 14.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 3.503 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | roaring | 10 | 3.333 | 3.213–3.692 | 4.719 | 18.7% | 15.00 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 3.372 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | roaring_bitmap | 10 | 3.107 | 3.025–3.233 | 3.366 | 4.4% | 16.09 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 3.149 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | seq | 10 | 49.998 | 48.183–53.115 | 53.724 | 5.0% | 1.00 | Seq Scan | 0.031 | 50.035 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c2 | brin | 10 | 135.409 | 131.051–137.673 | 143.709 | 4.1% | 0.96 | Seq Scan (fallback) | 0.050 | 135.480 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c2 | btree | 10 | 88.263 | 84.938–91.595 | 95.838 | 5.3% | 1.47 | Index Only Scan | 0.042 | 88.315 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c2 | btree_tuned | 10 | 209.308 | 203.116–212.708 | 222.097 | 4.2% | 0.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 209.353 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c2 | gin | 10 | 135.214 | 130.635–139.566 | 143.530 | 3.9% | 0.96 | Seq Scan (fallback) | 0.036 | 135.252 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c2 | gist | 10 | 186.806 | 184.643–192.302 | 195.494 | 2.9% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 186.841 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c2 | hash (partial) | 10 | 137.343 | 132.280–143.427 | 148.495 | 4.8% | 0.94 | Seq Scan (fallback) | 0.036 | 137.380 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c2 | roaring | 10 | 3.971 | 3.843–4.232 | 4.840 | 10.2% | 32.62 | RoaringCount | 0.038 | 4.009 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c2 | roaring_bitmap | 10 | 136.994 | 133.831–140.738 | 141.441 | 2.6% | 0.95 | Seq Scan (fallback) | 0.038 | 137.027 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c2 | seq | 10 | 129.555 | 128.409–135.984 | 141.106 | 3.9% | 1.00 | Seq Scan | 0.031 | 129.588 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c200 | brin | 10 | 158.818 | 154.002–161.996 | 166.686 | 3.9% | 0.98 | Seq Scan (fallback) | 0.046 | 158.869 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c200 | btree | 10 | 98.967 | 96.700–105.982 | 107.662 | 4.7% | 1.58 | Index Only Scan | 0.041 | 99.007 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c200 | btree_tuned | 10 | 311.233 | 305.986–329.460 | 340.314 | 4.6% | 0.50 | Index Only Scan | 0.044 | 311.317 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c200 | gin | 10 | 158.211 | 153.799–161.069 | 161.729 | 2.6% | 0.99 | Seq Scan (fallback) | 0.035 | 158.244 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c200 | gist | 10 | 230.656 | 222.945–234.960 | 236.884 | 3.1% | 0.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 230.707 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c200 | hash (partial) | 10 | 156.031 | 150.205–160.137 | 163.297 | 4.3% | 1.00 | Seq Scan (fallback) | 0.040 | 156.073 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c200 | roaring | 10 | 20.167 | 19.838–20.868 | 21.952 | 5.4% | 7.74 | RoaringCount | 0.038 | 20.215 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c200 | roaring_bitmap | 10 | 154.213 | 151.476–160.469 | 163.826 | 3.5% | 1.01 | Seq Scan (fallback) | 0.038 | 154.265 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_c200 | seq | 10 | 156.089 | 151.145–159.916 | 162.555 | 3.5% | 1.00 | Seq Scan | 0.034 | 156.139 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_filtered | brin | 10 | 76.435 | 74.658–78.992 | 82.200 | 4.3% | 0.63 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 76.495 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_filtered | btree | 10 | 3.388 | 3.155–3.670 | 4.252 | 13.8% | 14.22 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 3.439 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_filtered | btree_tuned | 10 | 1.618 | 1.399–1.977 | 2.205 | 20.1% | 29.78 | Index Only Scan | 0.056 | 1.673 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_filtered | gin | 10 | 5.280 | 5.131–5.460 | 5.651 | 5.2% | 9.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 5.330 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_filtered | gist | 10 | 3.662 | 3.493–3.793 | 4.699 | 15.7% | 13.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 3.716 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_filtered | hash (partial) | 10 | 3.766 | 3.571–4.335 | 5.360 | 19.9% | 12.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.807 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_filtered | roaring | 10 | 2.773 | 2.695–2.856 | 3.101 | 6.6% | 17.37 | RoaringCount | 0.047 | 2.821 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_filtered | roaring_bitmap | 10 | 3.593 | 3.353–3.858 | 3.894 | 7.1% | 13.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 3.654 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | group_filtered | seq | 10 | 48.168 | 46.654–52.253 | 55.404 | 7.2% | 1.00 | Seq Scan | 0.040 | 48.224 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_and | brin | 10 | 99.535 | 97.180–101.454 | 103.340 | 3.0% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 99.598 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_and | btree | 10 | 7.442 | 7.177–7.709 | 7.938 | 4.4% | 9.36 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 7.497 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_and | btree_tuned | 10 | 0.843 | 0.744–0.915 | 0.946 | 13.8% | 82.61 | Index Only Scan | 0.059 | 0.906 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_and | gin | 10 | 24.874 | 24.240–25.825 | 26.390 | 3.6% | 2.80 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 24.962 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_and | gist | 10 | 11.323 | 11.064–11.971 | 12.446 | 5.1% | 6.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 11.381 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_and | hash (partial) | 10 | 8.676 | 8.508–9.032 | 10.662 | 11.1% | 8.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 8.721 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_and | roaring | 10 | 2.089 | 2.063–2.151 | 2.243 | 3.5% | 33.36 | RoaringCount | 0.056 | 2.143 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_and | roaring_bitmap | 10 | 6.678 | 6.481–7.088 | 7.814 | 8.2% | 10.43 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 6.730 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_and | seq | 10 | 69.683 | 66.921–73.494 | 78.376 | 6.2% | 1.00 | Seq Scan | 0.036 | 69.721 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | brin | 10 | 61.389 | 57.666–62.914 | 65.924 | 5.6% | 1.14 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 61.465 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | btree | 10 | 0.073 | 0.069–0.081 | 0.086 | 10.3% | 961.95 | Index Only Scan | 0.055 | 0.129 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | btree_tuned | 10 | 0.184 | 0.168–0.240 | 0.303 | 27.2% | 381.64 | Index Only Scan | 0.046 | 0.233 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | gin | 10 | 16.401 | 15.432–16.772 | 16.806 | 4.2% | 4.28 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 16.447 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | gist | 10 | 0.532 | 0.505–0.568 | 0.599 | 8.7% | 132.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.576 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | hash (partial) | 10 | 0.439 | 0.397–0.476 | 0.572 | 17.2% | 159.96 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 0.484 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | roaring | 10 | 0.097 | 0.088–0.100 | 0.116 | 11.9% | 727.69 | RoaringCount | 0.052 | 0.147 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | roaring_bitmap | 10 | 0.484 | 0.408–0.494 | 0.495 | 11.1% | 145.09 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 0.528 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | seq | 10 | 70.222 | 67.228–76.330 | 79.254 | 7.2% | 1.00 | Seq Scan | 0.036 | 70.261 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | brin | 10 | 518.279 | 506.411–527.407 | 533.959 | 2.4% | 0.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.468 | 518.904 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | btree | 10 | 20.553 | 19.333–21.585 | 22.259 | 7.3% | 3.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.435 | 20.984 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | btree_tuned | 10 | 20.556 | 19.238–21.271 | 22.564 | 7.0% | 3.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.466 | 21.023 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | gin | 10 | 1629.498 | 1587.520–1650.917 | 1675.069 | 2.3% | 0.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.629 | 1630.123 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | gist | 10 | 36.998 | 36.495–39.675 | 42.577 | 7.4% | 2.04 | Bitmap Heap Scan, Bitmap Index Scan | 0.454 | 37.484 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | hash (partial) | 10 | 24.258 | 24.009–26.851 | 29.736 | 9.5% | 3.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.451 | 24.709 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | roaring | 10 | 20.197 | 18.714–21.388 | 21.703 | 8.6% | 3.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.808 | 21.157 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | roaring_bitmap | 10 | 20.715 | 20.053–21.761 | 24.027 | 8.4% | 3.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.458 | 21.178 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | seq | 10 | 75.325 | 74.416–77.799 | 78.568 | 2.7% | 1.00 | Seq Scan | 0.418 | 75.761 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | is_null | brin | 10 | 84.944 | 83.874–87.397 | 92.670 | 4.4% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 84.984 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | is_null | btree | 10 | 28.431 | 26.840–29.571 | 31.063 | 6.1% | 2.09 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 28.473 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | is_null | btree_tuned | 10 | 27.982 | 27.004–31.509 | 34.307 | 11.7% | 2.13 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 28.022 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | is_null | gin | 10 | 60.714 | 59.277–64.249 | 69.808 | 7.0% | 0.98 | Seq Scan (fallback) | 0.029 | 60.755 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | is_null | gist | 10 | 38.545 | 36.834–39.391 | 40.992 | 4.9% | 1.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 38.578 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | is_null | hash (partial) | 10 | 60.668 | 57.558–62.158 | 62.956 | 4.4% | 0.98 | Seq Scan (fallback) | 0.026 | 60.695 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | is_null | roaring | 10 | 26.349 | 24.975–28.390 | 28.584 | 5.9% | 2.26 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 26.386 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | is_null | roaring_bitmap | 10 | 27.055 | 26.248–28.118 | 33.412 | 10.6% | 2.20 | Bitmap Heap Scan, Bitmap Index Scan | 0.030 | 27.096 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | is_null | seq | 10 | 59.529 | 57.668–61.566 | 63.867 | 4.4% | 1.00 | Seq Scan | 0.022 | 59.550 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | range_random | brin | 10 | 80.549 | 79.810–83.541 | 88.292 | 4.3% | 0.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 80.612 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | range_random | btree | 10 | 0.491 | 0.454–0.605 | 0.719 | 19.9% | 111.04 | Index Only Scan | 0.056 | 0.554 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | range_random | btree_tuned | 10 | 1.551 | 1.357–1.611 | 1.800 | 12.7% | 35.14 | Index Only Scan | 0.061 | 1.614 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | range_random | gin | 10 | 45.684 | 44.038–47.053 | 50.243 | 6.0% | 1.19 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 45.730 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | range_random | gist | 10 | 0.885 | 0.849–0.926 | 0.952 | 4.8% | 61.64 | Index Only Scan | 0.042 | 0.925 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | range_random | hash (partial) | 10 | 55.918 | 54.186–58.878 | 62.051 | 5.8% | 0.98 | Seq Scan (fallback) | 0.039 | 55.956 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | range_random | roaring | 10 | 57.845 | 56.125–59.377 | 60.304 | 2.9% | 0.94 | Seq Scan (fallback) | 0.044 | 57.883 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | range_random | roaring_bitmap | 10 | 57.280 | 55.739–59.064 | 59.608 | 3.3% | 0.95 | Seq Scan (fallback) | 0.038 | 57.331 |
| scalar | 1000000 | dirty_scattered | prefer_index | 64MB | range_random | seq | 10 | 54.523 | 52.775–58.224 | 59.300 | 5.0% | 1.00 | Seq Scan | 0.032 | 54.553 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | brin | 10 | 96.007 | 91.689–99.679 | 102.843 | 5.2% | 0.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 96.108 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | btree | 10 | 31.986 | 31.269–34.471 | 38.074 | 8.5% | 2.15 | Index Only Scan | 0.035 | 32.023 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | btree_tuned | 10 | 32.540 | 31.763–35.013 | 36.518 | 6.6% | 2.11 | Index Only Scan | 0.041 | 32.579 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | gin | 10 | 124.622 | 121.894–127.669 | 133.592 | 3.9% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 124.688 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | gist | 10 | 76.205 | 73.260–78.093 | 79.715 | 4.2% | 0.90 | Index Only Scan | 0.056 | 76.261 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | hash (partial) | 10 | 68.059 | 66.429–68.654 | 70.551 | 2.9% | 1.01 | Seq Scan (fallback) | 0.054 | 68.115 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | roaring | 10 | 0.419 | 0.410–0.461 | 0.504 | 8.8% | 163.90 | RoaringCount | 0.041 | 0.463 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | roaring_bitmap | 10 | 95.336 | 94.552–98.491 | 99.500 | 2.3% | 0.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 95.394 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | seq | 10 | 68.754 | 66.054–71.331 | 72.433 | 4.1% | 1.00 | Seq Scan | 0.031 | 68.793 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | fetch_medium | brin | 10 | 74.835 | 70.054–79.428 | 81.048 | 6.7% | 0.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 74.908 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | fetch_medium | btree | 10 | 2.709 | 2.322–3.092 | 3.264 | 15.9% | 18.15 | Index Scan | 0.046 | 2.752 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | fetch_medium | btree_tuned | 10 | 0.605 | 0.593–0.617 | 0.630 | 2.9% | 81.32 | Index Only Scan | 0.045 | 0.648 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | fetch_medium | gin | 10 | 15.822 | 15.401–16.901 | 18.152 | 7.1% | 3.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 15.889 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | fetch_medium | gist | 10 | 3.459 | 2.902–3.527 | 3.932 | 19.9% | 14.21 | Index Scan | 0.053 | 3.524 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | fetch_medium | hash (partial) | 10 | 2.939 | 2.623–3.026 | 4.465 | 30.4% | 16.73 | Index Scan | 0.065 | 3.005 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | fetch_medium | roaring | 10 | 16.324 | 15.381–17.690 | 21.583 | 16.9% | 3.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 16.369 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | fetch_medium | roaring_bitmap | 10 | 14.913 | 14.626–15.228 | 15.526 | 2.8% | 3.30 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 14.979 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | fetch_medium | seq | 10 | 49.158 | 47.489–50.123 | 52.279 | 4.7% | 1.00 | Seq Scan | 0.039 | 49.201 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | group_c200 | brin | 10 | 157.862 | 151.811–158.934 | 162.354 | 3.2% | 0.99 | Seq Scan (fallback) | 0.057 | 157.923 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | group_c200 | btree | 10 | 84.992 | 83.704–86.878 | 93.773 | 5.3% | 1.84 | Index Only Scan | 0.039 | 85.075 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | group_c200 | btree_tuned | 10 | 84.150 | 81.538–90.788 | 93.683 | 6.1% | 1.86 | Index Only Scan | 0.045 | 84.198 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | group_c200 | gin | 10 | 151.589 | 148.793–158.252 | 162.361 | 3.6% | 1.03 | Seq Scan (fallback) | 0.049 | 151.627 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | group_c200 | gist | 10 | 207.742 | 199.759–209.488 | 213.048 | 2.9% | 0.75 | Index Only Scan | 0.055 | 207.808 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | group_c200 | hash (partial) | 10 | 153.752 | 151.991–158.783 | 163.726 | 3.8% | 1.02 | Seq Scan (fallback) | 0.056 | 153.786 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | group_c200 | roaring | 10 | 3.937 | 3.850–4.264 | 4.454 | 6.4% | 39.82 | RoaringCount | 0.038 | 3.978 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | group_c200 | roaring_bitmap | 10 | 154.894 | 151.724–155.952 | 156.448 | 2.0% | 1.01 | Seq Scan (fallback) | 0.044 | 154.933 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | group_c200 | seq | 10 | 156.754 | 154.810–160.934 | 164.328 | 2.9% | 1.00 | Seq Scan | 0.038 | 156.794 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | brin | 10 | 501.059 | 481.264–508.864 | 517.846 | 3.4% | 0.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.484 | 501.556 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | btree | 10 | 3.340 | 3.164–3.457 | 3.821 | 8.0% | 23.22 | Index Only Scan | 0.445 | 3.774 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | btree_tuned | 10 | 3.212 | 3.141–3.305 | 3.432 | 4.3% | 24.14 | Index Only Scan | 0.451 | 3.725 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | gin | 10 | 99.339 | 96.565–101.084 | 105.952 | 4.1% | 0.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.639 | 99.945 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | gist | 10 | 119.044 | 116.477–126.736 | 134.823 | 6.0% | 0.65 | Index Only Scan | 0.475 | 119.504 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | hash (partial) | 10 | 98.895 | 96.446–101.601 | 104.912 | 3.6% | 0.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.475 | 99.380 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | roaring | 10 | 15.166 | 14.455–17.316 | 19.448 | 13.0% | 5.11 | RoaringCount | 0.820 | 16.044 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | roaring_bitmap | 10 | 97.634 | 94.553–100.689 | 102.084 | 3.5% | 0.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.492 | 98.130 |
| scalar | 1000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | seq | 10 | 77.557 | 73.964–79.863 | 81.596 | 4.3% | 1.00 | Seq Scan | 0.309 | 77.857 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | brin | 3 | 116.662 | 113.910–117.367 | 117.297 | 1.6% | 0.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.640 | 117.248 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | btree | 3 | 0.482 | 0.433–0.764 | 0.736 | 31.9% | 170.84 | Index Only Scan | 0.679 | 1.161 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | btree_tuned | 3 | 0.467 | 0.462–0.495 | 0.492 | 3.7% | 176.33 | Index Only Scan | 0.829 | 1.324 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | gin | 3 | 23.940 | 23.591–27.208 | 26.881 | 8.0% | 3.44 | Bitmap Heap Scan, Bitmap Index Scan | 0.728 | 24.706 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | gist | 3 | 1.172 | 1.121–1.192 | 1.190 | 3.2% | 70.26 | Index Only Scan | 0.606 | 1.777 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | hash (partial) | 3 | 23.276 | 22.925–30.124 | 29.439 | 16.0% | 3.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.519 | 23.795 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | roaring | 3 | 0.099 | 0.098–0.099 | 0.099 | 0.6% | 831.79 | RoaringCount | 0.684 | 0.782 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | roaring_bitmap | 3 | 23.091 | 22.869–23.195 | 23.185 | 0.7% | 3.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.590 | 23.660 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | seq | 3 | 82.347 | 79.907–84.670 | 84.438 | 2.9% | 1.00 | Seq Scan | 0.333 | 82.669 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | fetch_medium | brin | 3 | 117.287 | 116.206–120.242 | 119.947 | 1.8% | 0.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.727 | 117.966 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | fetch_medium | btree | 3 | 22.092 | 21.919–22.211 | 22.199 | 0.7% | 3.96 | Bitmap Heap Scan, Bitmap Index Scan | 0.813 | 22.905 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | fetch_medium | btree_tuned | 3 | 1.276 | 1.237–1.318 | 1.314 | 3.2% | 68.48 | Index Only Scan | 0.873 | 2.159 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | fetch_medium | gin | 3 | 23.593 | 23.539–23.828 | 23.805 | 0.6% | 3.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.840 | 24.578 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | fetch_medium | gist | 3 | 23.274 | 23.161–25.736 | 25.490 | 6.0% | 3.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.892 | 24.263 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | fetch_medium | hash (partial) | 3 | 23.520 | 21.474–24.718 | 24.598 | 7.1% | 3.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.694 | 24.119 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | fetch_medium | roaring | 3 | 24.033 | 22.299–27.940 | 27.549 | 11.7% | 3.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.691 | 24.702 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | fetch_medium | roaring_bitmap | 3 | 23.124 | 21.744–23.346 | 23.324 | 3.8% | 3.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.724 | 24.033 |
| scalar | 1000000 | shared_buffers_cold | default | 64MB | fetch_medium | seq | 3 | 87.383 | 86.520–90.054 | 89.787 | 2.1% | 1.00 | Seq Scan | 0.509 | 87.892 |
| scalar | 5000000 | after_maintenance | default | 64MB | and2 | brin | 10 | 583.904 | 568.263–607.678 | 658.224 | 6.4% | 1.37 | Bitmap Heap Scan, Bitmap Index Scan | 0.208 | 584.087 |
| scalar | 5000000 | after_maintenance | default | 64MB | and2 | btree | 10 | 20.285 | 19.721–20.784 | 21.273 | 9.6% | 39.44 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 20.328 |
| scalar | 5000000 | after_maintenance | default | 64MB | and2 | btree_tuned | 10 | 0.883 | 0.869–0.903 | 0.915 | 3.3% | 905.48 | Index Only Scan | 0.051 | 0.943 |
| scalar | 5000000 | after_maintenance | default | 64MB | and2 | gin | 10 | 174.310 | 172.930–177.573 | 179.901 | 1.9% | 4.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.080 | 174.391 |
| scalar | 5000000 | after_maintenance | default | 64MB | and2 | gist | 10 | 20.303 | 19.360–21.055 | 22.334 | 11.1% | 39.40 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 20.360 |
| scalar | 5000000 | after_maintenance | default | 64MB | and2 | roaring | 10 | 1.699 | 1.611–1.933 | 1.968 | 9.1% | 470.86 | RoaringCount | 0.046 | 1.747 |
| scalar | 5000000 | after_maintenance | default | 64MB | and2 | roaring_bitmap | 10 | 42.238 | 39.032–116.503 | 139.576 | 61.4% | 18.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 42.314 |
| scalar | 5000000 | after_maintenance | default | 64MB | and2 | seq | 10 | 799.995 | 772.096–861.260 | 898.387 | 6.4% | 1.00 | Seq Scan | 0.046 | 800.042 |
| scalar | 5000000 | after_maintenance | default | 64MB | eq_c200_17 | brin | 10 | 575.814 | 563.841–586.651 | 603.746 | 2.7% | 1.37 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 575.881 |
| scalar | 5000000 | after_maintenance | default | 64MB | eq_c200_17 | btree | 10 | 1.522 | 1.513–1.532 | 1.550 | 1.4% | 517.08 | Index Only Scan | 0.040 | 1.572 |
| scalar | 5000000 | after_maintenance | default | 64MB | eq_c200_17 | btree_tuned | 10 | 1.510 | 1.497–1.523 | 1.636 | 4.7% | 521.53 | Index Only Scan | 0.043 | 1.553 |
| scalar | 5000000 | after_maintenance | default | 64MB | eq_c200_17 | gin | 10 | 18.490 | 17.526–19.501 | 21.407 | 9.1% | 42.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 18.555 |
| scalar | 5000000 | after_maintenance | default | 64MB | eq_c200_17 | gist | 10 | 3.327 | 3.266–3.433 | 3.516 | 3.2% | 236.66 | Index Only Scan | 0.050 | 3.381 |
| scalar | 5000000 | after_maintenance | default | 64MB | eq_c200_17 | roaring | 10 | 0.102 | 0.101–0.103 | 0.118 | 9.0% | 7756.17 | RoaringCount | 0.036 | 0.138 |
| scalar | 5000000 | after_maintenance | default | 64MB | eq_c200_17 | roaring_bitmap | 10 | 96.266 | 33.093–177.614 | 202.964 | 76.0% | 8.18 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 96.315 |
| scalar | 5000000 | after_maintenance | default | 64MB | eq_c200_17 | seq | 10 | 787.252 | 775.320–859.280 | 888.950 | 6.0% | 1.00 | Seq Scan | 0.043 | 787.293 |
| scalar | 5000000 | after_maintenance | default | 64MB | group_c200 | brin | 10 | 850.720 | 842.196–896.506 | 951.704 | 5.5% | 1.48 | Seq Scan (fallback) | 0.060 | 850.794 |
| scalar | 5000000 | after_maintenance | default | 64MB | group_c200 | btree | 10 | 401.637 | 396.804–409.802 | 415.055 | 1.9% | 3.13 | Index Only Scan | 0.040 | 401.678 |
| scalar | 5000000 | after_maintenance | default | 64MB | group_c200 | btree_tuned | 10 | 403.191 | 395.320–412.986 | 421.909 | 2.8% | 3.12 | Index Only Scan | 0.044 | 403.233 |
| scalar | 5000000 | after_maintenance | default | 64MB | group_c200 | gin | 10 | 1358.977 | 1345.790–1376.294 | 1395.690 | 1.5% | 0.92 | Seq Scan (fallback) | 0.039 | 1359.024 |
| scalar | 5000000 | after_maintenance | default | 64MB | group_c200 | gist | 10 | 912.784 | 905.811–921.151 | 939.343 | 1.7% | 1.38 | Index Only Scan | 0.043 | 912.839 |
| scalar | 5000000 | after_maintenance | default | 64MB | group_c200 | roaring | 10 | 19.446 | 19.051–20.385 | 20.999 | 4.4% | 64.64 | RoaringCount | 0.033 | 19.477 |
| scalar | 5000000 | after_maintenance | default | 64MB | group_c200 | roaring_bitmap | 10 | 1024.034 | 996.411–1039.385 | 1060.864 | 5.5% | 1.23 | Seq Scan (fallback) | 0.059 | 1024.093 |
| scalar | 5000000 | after_maintenance | default | 64MB | group_c200 | seq | 10 | 1256.925 | 1229.884–1342.023 | 1421.889 | 6.0% | 1.00 | Seq Scan | 0.043 | 1256.968 |
| scalar | 5000000 | after_maintenance | default | 64MB | is_null | brin | 10 | 375.510 | 372.381–381.344 | 412.675 | 5.1% | 2.28 | Seq Scan (fallback) | 0.078 | 375.587 |
| scalar | 5000000 | after_maintenance | default | 64MB | is_null | btree | 10 | 32.925 | 32.560–35.547 | 37.774 | 6.6% | 26.04 | Index Only Scan | 0.033 | 32.997 |
| scalar | 5000000 | after_maintenance | default | 64MB | is_null | btree_tuned | 10 | 35.039 | 33.262–38.038 | 39.644 | 7.6% | 24.46 | Index Only Scan | 0.034 | 35.072 |
| scalar | 5000000 | after_maintenance | default | 64MB | is_null | gin | 10 | 837.877 | 832.243–866.439 | 878.128 | 2.4% | 1.02 | Seq Scan (fallback) | 0.045 | 837.923 |
| scalar | 5000000 | after_maintenance | default | 64MB | is_null | gist | 10 | 85.620 | 84.849–91.557 | 94.171 | 4.8% | 10.01 | Index Only Scan | 0.031 | 85.664 |
| scalar | 5000000 | after_maintenance | default | 64MB | is_null | roaring | 10 | 0.457 | 0.448–0.475 | 0.483 | 3.4% | 1875.72 | RoaringCount | 0.032 | 0.492 |
| scalar | 5000000 | after_maintenance | default | 64MB | is_null | roaring_bitmap | 10 | 562.043 | 490.881–607.330 | 662.200 | 16.2% | 1.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 562.090 |
| scalar | 5000000 | after_maintenance | default | 64MB | is_null | seq | 10 | 857.202 | 824.242–911.792 | 946.342 | 6.1% | 1.00 | Seq Scan | 0.036 | 857.240 |
| scalar | 5000000 | clean | default | 64MB | and2 | brin | 10 | 309.581 | 304.858–312.899 | 315.523 | 1.7% | 1.00 | Seq Scan (fallback) | 0.085 | 309.900 |
| scalar | 5000000 | clean | default | 64MB | and2 | btree | 10 | 18.529 | 17.325–19.699 | 20.409 | 10.5% | 16.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 18.581 |
| scalar | 5000000 | clean | default | 64MB | and2 | btree_tuned | 10 | 0.889 | 0.870–0.907 | 0.928 | 3.0% | 347.25 | Index Only Scan | 0.049 | 0.939 |
| scalar | 5000000 | clean | default | 64MB | and2 | gin | 10 | 223.754 | 171.144–280.388 | 293.332 | 26.2% | 1.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.095 | 223.823 |
| scalar | 5000000 | clean | default | 64MB | and2 | gist | 10 | 35.410 | 19.734–180.886 | 321.011 | 117.4% | 8.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 35.472 |
| scalar | 5000000 | clean | default | 64MB | and2 | hash (partial) | 10 | 18.526 | 17.799–20.809 | 25.882 | 18.9% | 16.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 18.577 |
| scalar | 5000000 | clean | default | 64MB | and2 | roaring | 10 | 1.817 | 1.761–3.433 | 3.599 | 37.2% | 169.85 | RoaringCount | 0.046 | 1.863 |
| scalar | 5000000 | clean | default | 64MB | and2 | roaring_bitmap | 10 | 106.459 | 46.529–154.241 | 164.940 | 55.6% | 2.90 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 106.505 |
| scalar | 5000000 | clean | default | 64MB | and2 | seq | 10 | 308.533 | 303.486–314.113 | 318.208 | 2.1% | 1.00 | Seq Scan | 0.047 | 308.581 |
| scalar | 5000000 | clean | default | 64MB | and3 | brin | 10 | 549.239 | 532.166–560.235 | 564.569 | 3.4% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.093 | 549.582 |
| scalar | 5000000 | clean | default | 64MB | and3 | btree | 10 | 13.722 | 13.046–14.508 | 14.766 | 5.5% | 22.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 13.771 |
| scalar | 5000000 | clean | default | 64MB | and3 | btree_tuned | 10 | 0.071 | 0.058–0.088 | 0.097 | 23.0% | 4355.88 | Index Only Scan | 0.052 | 0.122 |
| scalar | 5000000 | clean | default | 64MB | and3 | gin | 10 | 26.349 | 25.677–37.157 | 41.003 | 22.4% | 11.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.093 | 26.570 |
| scalar | 5000000 | clean | default | 64MB | and3 | gist | 10 | 20.687 | 18.928–24.935 | 36.372 | 32.2% | 14.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 20.739 |
| scalar | 5000000 | clean | default | 64MB | and3 | hash (partial) | 10 | 16.810 | 15.872–112.135 | 236.328 | 141.8% | 18.27 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 16.863 |
| scalar | 5000000 | clean | default | 64MB | and3 | roaring | 10 | 1.363 | 1.275–2.219 | 3.038 | 42.7% | 225.22 | RoaringCount | 0.050 | 1.459 |
| scalar | 5000000 | clean | default | 64MB | and3 | roaring_bitmap | 10 | 26.910 | 17.502–32.766 | 37.872 | 31.9% | 11.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 26.976 |
| scalar | 5000000 | clean | default | 64MB | and3 | seq | 10 | 307.090 | 295.859–310.736 | 315.019 | 2.6% | 1.00 | Seq Scan | 0.049 | 307.139 |
| scalar | 5000000 | clean | default | 64MB | count_distinct | brin | 10 | 312.503 | 307.968–316.370 | 324.147 | 2.5% | 0.98 | Seq Scan (fallback) | 0.072 | 312.574 |
| scalar | 5000000 | clean | default | 64MB | count_distinct | btree | 10 | 19.841 | 18.048–20.548 | 21.141 | 9.9% | 15.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 19.910 |
| scalar | 5000000 | clean | default | 64MB | count_distinct | btree_tuned | 10 | 120.757 | 21.463–280.743 | 318.137 | 92.6% | 2.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 120.823 |
| scalar | 5000000 | clean | default | 64MB | count_distinct | gin | 10 | 196.134 | 58.353–217.433 | 223.499 | 55.6% | 1.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 196.175 |
| scalar | 5000000 | clean | default | 64MB | count_distinct | gist | 10 | 28.974 | 19.971–328.320 | 415.533 | 117.2% | 10.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 29.022 |
| scalar | 5000000 | clean | default | 64MB | count_distinct | hash (partial) | 10 | 22.645 | 19.660–25.316 | 167.098 | 171.7% | 13.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 22.683 |
| scalar | 5000000 | clean | default | 64MB | count_distinct | roaring | 10 | 115.361 | 21.982–261.166 | 331.237 | 92.1% | 2.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 115.404 |
| scalar | 5000000 | clean | default | 64MB | count_distinct | roaring_bitmap | 10 | 218.475 | 24.492–237.178 | 248.937 | 60.5% | 1.40 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 218.528 |
| scalar | 5000000 | clean | default | 64MB | count_distinct | seq | 10 | 305.074 | 300.984–308.852 | 312.902 | 1.7% | 1.00 | Seq Scan | 0.048 | 305.121 |
| scalar | 5000000 | clean | default | 64MB | eq_absent | brin | 10 | 303.440 | 299.381–311.292 | 313.986 | 2.1% | 1.01 | Seq Scan (fallback) | 0.074 | 303.759 |
| scalar | 5000000 | clean | default | 64MB | eq_absent | btree | 10 | 0.027 | 0.017–0.030 | 0.040 | 35.0% | 11397.04 | Index Only Scan | 0.034 | 0.061 |
| scalar | 5000000 | clean | default | 64MB | eq_absent | btree_tuned | 10 | 0.021 | 0.017–0.031 | 0.039 | 38.4% | 14312.56 | Index Only Scan | 0.041 | 0.059 |
| scalar | 5000000 | clean | default | 64MB | eq_absent | gin | 10 | 0.021 | 0.018–0.023 | 0.027 | 19.8% | 14653.33 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 0.079 |
| scalar | 5000000 | clean | default | 64MB | eq_absent | gist | 10 | 0.019 | 0.017–0.022 | 0.024 | 17.6% | 16195.79 | Index Only Scan | 0.047 | 0.069 |
| scalar | 5000000 | clean | default | 64MB | eq_absent | hash (partial) | 10 | 0.025 | 0.023–0.207 | 0.282 | 111.9% | 12560.00 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 0.074 |
| scalar | 5000000 | clean | default | 64MB | eq_absent | roaring | 10 | 0.007 | 0.007–0.011 | 0.016 | 42.5% | 43960.00 | RoaringCount | 0.039 | 0.046 |
| scalar | 5000000 | clean | default | 64MB | eq_absent | roaring_bitmap | 10 | 0.030 | 0.024–0.469 | 0.530 | 123.1% | 10089.18 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 0.097 |
| scalar | 5000000 | clean | default | 64MB | eq_absent | seq | 10 | 307.720 | 301.153–314.772 | 322.913 | 3.0% | 1.00 | Seq Scan | 0.043 | 307.764 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_12345 | brin | 10 | 556.192 | 524.044–567.698 | 575.278 | 4.0% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.079 | 556.271 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_12345 | btree | 10 | 0.032 | 0.026–0.033 | 0.050 | 35.9% | 10318.30 | Index Only Scan | 0.035 | 0.065 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_12345 | btree_tuned | 10 | 0.032 | 0.024–0.033 | 0.034 | 20.8% | 10318.30 | Index Only Scan | 0.036 | 0.068 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_12345 | gin | 10 | 0.306 | 0.208–0.360 | 0.511 | 40.6% | 1060.45 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 0.381 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_12345 | gist | 10 | 0.053 | 0.048–0.059 | 0.062 | 14.6% | 6132.58 | Index Only Scan | 0.062 | 0.115 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_12345 | hash (partial) | 10 | 0.045 | 0.032–0.242 | 0.404 | 115.9% | 7222.81 | Index Scan | 0.049 | 0.100 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_12345 | roaring | 10 | 0.022 | 0.018–0.028 | 0.337 | 170.2% | 14445.62 | RoaringCount | 0.037 | 0.059 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_12345 | roaring_bitmap | 10 | 0.316 | 0.036–0.595 | 0.884 | 90.0% | 1028.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 0.364 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_12345 | seq | 10 | 325.026 | 319.800–331.458 | 339.393 | 2.7% | 1.00 | Seq Scan | 0.042 | 325.068 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_765432 | brin | 10 | 560.473 | 553.326–571.536 | 579.218 | 2.1% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.083 | 560.671 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_765432 | btree | 10 | 0.033 | 0.023–0.036 | 0.041 | 26.3% | 9998.86 | Index Only Scan | 0.036 | 0.069 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_765432 | btree_tuned | 10 | 0.032 | 0.024–0.033 | 0.036 | 20.8% | 10316.29 | Index Only Scan | 0.037 | 0.069 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_765432 | gin | 10 | 0.127 | 0.047–0.185 | 0.281 | 72.9% | 2558.76 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 0.170 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_765432 | gist | 10 | 0.058 | 0.053–0.069 | 0.080 | 16.9% | 5554.92 | Index Only Scan | 0.063 | 0.122 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_765432 | hash (partial) | 10 | 0.162 | 0.041–0.425 | 0.488 | 89.2% | 2012.15 | Index Scan | 0.057 | 0.218 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_765432 | roaring | 10 | 0.019 | 0.019–0.086 | 0.124 | 100.3% | 16664.77 | RoaringCount | 0.038 | 0.057 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_765432 | roaring_bitmap | 10 | 0.136 | 0.058–0.310 | 0.551 | 96.1% | 2398.25 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 0.186 |
| scalar | 5000000 | clean | default | 64MB | eq_c1m_765432 | seq | 10 | 324.963 | 323.063–334.164 | 348.597 | 3.2% | 1.00 | Seq Scan | 0.042 | 325.024 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_103 | brin | 10 | 310.826 | 303.965–323.609 | 336.557 | 4.5% | 1.01 | Seq Scan (fallback) | 0.067 | 311.005 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_103 | btree | 10 | 1.514 | 1.486–1.618 | 1.718 | 6.1% | 208.10 | Index Only Scan | 0.036 | 1.546 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_103 | btree_tuned | 10 | 1.530 | 1.516–1.579 | 1.605 | 2.5% | 205.92 | Index Only Scan | 0.041 | 1.575 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_103 | gin | 10 | 221.007 | 217.565–227.120 | 235.989 | 4.0% | 1.43 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 221.060 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_103 | gist | 10 | 3.543 | 3.496–3.884 | 4.721 | 14.3% | 88.89 | Index Only Scan | 0.037 | 3.580 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_103 | hash (partial) | 10 | 31.627 | 21.636–214.336 | 275.340 | 102.9% | 9.96 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 31.671 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_103 | roaring | 10 | 0.121 | 0.099–0.157 | 0.390 | 88.0% | 2602.93 | RoaringCount | 0.040 | 0.161 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_103 | roaring_bitmap | 10 | 227.568 | 138.308–239.804 | 254.249 | 44.0% | 1.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 227.631 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_103 | seq | 10 | 314.955 | 309.971–320.410 | 326.115 | 2.6% | 1.00 | Seq Scan | 0.043 | 314.998 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_17 | brin | 10 | 310.606 | 307.514–314.306 | 318.003 | 1.8% | 1.01 | Seq Scan (fallback) | 0.067 | 310.656 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_17 | btree | 10 | 1.499 | 1.480–1.532 | 1.809 | 10.8% | 209.13 | Index Only Scan | 0.037 | 1.542 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_17 | btree_tuned | 10 | 1.551 | 1.534–1.578 | 1.631 | 2.9% | 202.12 | Index Only Scan | 0.041 | 1.591 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_17 | gin | 10 | 109.315 | 22.115–217.267 | 226.384 | 73.8% | 2.87 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 109.376 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_17 | gist | 10 | 3.410 | 3.365–3.508 | 3.793 | 5.6% | 91.93 | Index Only Scan | 0.037 | 3.456 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_17 | hash (partial) | 10 | 19.033 | 17.609–19.517 | 20.848 | 10.6% | 16.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 19.090 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_17 | roaring | 10 | 0.100 | 0.097–0.108 | 0.123 | 10.6% | 3150.67 | RoaringCount | 0.040 | 0.139 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_17 | roaring_bitmap | 10 | 192.986 | 20.445–252.022 | 304.595 | 66.5% | 1.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 193.037 |
| scalar | 5000000 | clean | default | 64MB | eq_c200_17 | seq | 10 | 313.492 | 308.319–325.243 | 327.163 | 2.7% | 1.00 | Seq Scan | 0.043 | 313.536 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_17 | brin | 10 | 558.377 | 539.851–566.171 | 575.140 | 3.6% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.076 | 558.614 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_17 | btree | 10 | 15.816 | 15.282–18.123 | 19.851 | 11.8% | 19.83 | Index Only Scan | 0.042 | 15.849 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_17 | btree_tuned | 10 | 15.470 | 15.350–16.029 | 16.367 | 3.3% | 20.27 | Index Only Scan | 0.040 | 15.515 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_17 | gin | 10 | 515.219 | 420.826–554.341 | 633.492 | 19.2% | 0.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 515.273 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_17 | gist | 10 | 35.144 | 33.745–36.753 | 38.181 | 5.2% | 8.92 | Index Only Scan | 0.037 | 35.180 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_17 | hash (partial) | 10 | 718.122 | 623.625–784.327 | 797.443 | 18.1% | 0.44 | Seq Scan (fallback) | 0.049 | 718.157 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_17 | roaring | 10 | 0.277 | 0.270–0.359 | 0.455 | 24.2% | 1134.04 | RoaringCount | 0.039 | 0.322 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_17 | roaring_bitmap | 10 | 474.497 | 461.389–593.040 | 616.468 | 15.7% | 0.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 474.546 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_17 | seq | 10 | 313.562 | 311.460–319.802 | 326.756 | 2.2% | 1.00 | Seq Scan | 0.043 | 313.605 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_3 | brin | 10 | 561.648 | 551.841–571.049 | 573.062 | 3.8% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 561.709 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_3 | btree | 10 | 15.416 | 14.870–15.934 | 17.861 | 8.7% | 20.31 | Index Only Scan | 0.039 | 15.454 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_3 | btree_tuned | 10 | 15.492 | 15.027–16.197 | 16.969 | 4.9% | 20.21 | Index Only Scan | 0.040 | 15.532 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_3 | gin | 10 | 427.816 | 389.219–462.863 | 580.054 | 17.9% | 0.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 427.915 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_3 | gist | 10 | 36.160 | 33.988–38.099 | 41.614 | 9.1% | 8.66 | Index Only Scan | 0.036 | 36.196 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_3 | hash (partial) | 10 | 668.168 | 618.813–775.687 | 802.810 | 11.9% | 0.47 | Seq Scan (fallback) | 0.052 | 668.207 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_3 | roaring | 10 | 0.281 | 0.265–0.303 | 0.355 | 12.6% | 1114.44 | RoaringCount | 0.043 | 0.327 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_3 | roaring_bitmap | 10 | 398.898 | 379.409–541.991 | 603.886 | 22.0% | 0.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 398.955 |
| scalar | 5000000 | clean | default | 64MB | eq_c20_3 | seq | 10 | 313.158 | 308.190–323.640 | 332.274 | 3.5% | 1.00 | Seq Scan | 0.043 | 313.201 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_123 | brin | 10 | 553.768 | 542.649–561.294 | 565.592 | 1.9% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.082 | 553.987 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_123 | btree | 10 | 0.033 | 0.032–0.037 | 0.071 | 52.0% | 9639.92 | Index Only Scan | 0.036 | 0.068 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_123 | btree_tuned | 10 | 0.033 | 0.032–0.037 | 0.038 | 8.0% | 9493.86 | Index Only Scan | 0.050 | 0.083 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_123 | gin | 10 | 1.904 | 0.851–2.088 | 2.401 | 52.9% | 164.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 1.960 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_123 | gist | 10 | 0.084 | 0.075–0.088 | 0.090 | 8.3% | 3752.07 | Index Only Scan | 0.037 | 0.127 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_123 | hash (partial) | 10 | 1.589 | 0.855–2.045 | 2.584 | 57.2% | 197.23 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 1.635 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_123 | roaring | 10 | 0.021 | 0.020–0.024 | 0.027 | 11.3% | 14918.93 | RoaringCount | 0.037 | 0.058 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_123 | roaring_bitmap | 10 | 2.168 | 2.017–2.447 | 2.741 | 34.7% | 144.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 2.208 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_123 | seq | 10 | 313.298 | 308.926–321.530 | 328.012 | 2.6% | 1.00 | Seq Scan | 0.043 | 313.341 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_12345 | brin | 10 | 552.602 | 541.105–556.336 | 571.354 | 3.3% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.084 | 552.935 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_12345 | btree | 10 | 0.038 | 0.034–0.047 | 0.055 | 21.9% | 8273.87 | Index Only Scan | 0.036 | 0.078 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_12345 | btree_tuned | 10 | 0.044 | 0.039–0.048 | 0.066 | 27.4% | 7158.29 | Index Only Scan | 0.040 | 0.086 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_12345 | gin | 10 | 2.181 | 2.062–2.681 | 3.019 | 20.1% | 146.09 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 2.273 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_12345 | gist | 10 | 0.074 | 0.073–0.081 | 0.088 | 9.3% | 4275.76 | Index Only Scan | 0.036 | 0.111 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_12345 | hash (partial) | 10 | 2.397 | 1.604–2.773 | 2.967 | 41.1% | 132.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 2.436 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_12345 | roaring | 10 | 0.024 | 0.023–0.031 | 0.033 | 16.4% | 13272.67 | RoaringCount | 0.039 | 0.065 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_12345 | roaring_bitmap | 10 | 2.341 | 2.236–2.743 | 2.773 | 10.8% | 136.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 2.407 |
| scalar | 5000000 | clean | default | 64MB | eq_c20k_12345 | seq | 10 | 318.544 | 311.413–322.731 | 325.720 | 2.2% | 1.00 | Seq Scan | 0.044 | 318.594 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_0 | brin | 10 | 409.197 | 403.370–416.062 | 423.786 | 2.3% | 1.00 | Seq Scan (fallback) | 0.121 | 409.261 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_0 | btree | 10 | 159.250 | 157.095–161.022 | 164.908 | 2.2% | 2.56 | Index Only Scan | 0.053 | 159.305 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_0 | btree_tuned | 10 | 159.373 | 157.377–161.628 | 165.300 | 2.2% | 2.56 | Index Only Scan | 0.040 | 159.410 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_0 | gin | 10 | 802.219 | 692.102–892.773 | 969.358 | 15.0% | 0.51 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 802.497 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_0 | gist | 10 | 362.875 | 356.186–371.906 | 377.614 | 2.9% | 1.12 | Index Only Scan | 0.064 | 362.948 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_0 | hash (partial) | 10 | 831.547 | 791.666–879.868 | 902.318 | 6.5% | 0.49 | Seq Scan (fallback) | 0.029 | 831.599 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_0 | roaring | 10 | 2.123 | 2.028–3.894 | 4.491 | 39.6% | 192.00 | RoaringCount | 0.039 | 2.179 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_0 | roaring_bitmap | 10 | 515.517 | 504.781–735.323 | 784.738 | 21.7% | 0.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 515.559 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_0 | seq | 10 | 407.717 | 402.389–409.296 | 417.415 | 1.7% | 1.00 | Seq Scan | 0.044 | 407.760 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_1 | brin | 10 | 407.379 | 400.017–409.898 | 410.393 | 1.5% | 1.01 | Seq Scan (fallback) | 0.074 | 407.450 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_1 | btree | 10 | 160.881 | 152.906–164.725 | 173.067 | 5.2% | 2.56 | Index Only Scan | 0.032 | 160.915 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_1 | btree_tuned | 10 | 157.163 | 153.755–164.524 | 168.595 | 4.0% | 2.62 | Index Only Scan | 0.036 | 157.198 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_1 | gin | 10 | 703.539 | 609.580–805.016 | 893.880 | 16.5% | 0.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 703.601 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_1 | gist | 10 | 368.249 | 355.175–373.539 | 383.717 | 3.8% | 1.12 | Index Only Scan | 0.062 | 368.301 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_1 | hash (partial) | 10 | 789.958 | 674.482–879.207 | 909.239 | 14.5% | 0.52 | Seq Scan (fallback) | 0.033 | 790.015 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_1 | roaring | 10 | 2.143 | 2.029–4.302 | 4.430 | 39.3% | 192.04 | RoaringCount | 0.038 | 2.200 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_1 | roaring_bitmap | 10 | 707.627 | 627.360–778.225 | 829.017 | 15.2% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 707.675 |
| scalar | 5000000 | clean | default | 64MB | eq_c2_1 | seq | 10 | 411.629 | 406.559–417.560 | 422.200 | 1.9% | 1.00 | Seq Scan | 0.042 | 411.673 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_103 | brin | 10 | 3.650 | 3.277–3.945 | 4.529 | 15.2% | 92.96 | Bitmap Heap Scan, Bitmap Index Scan | 0.105 | 3.867 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_103 | btree | 10 | 1.531 | 1.523–1.563 | 1.596 | 2.1% | 221.54 | Index Only Scan | 0.036 | 1.584 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_103 | btree_tuned | 10 | 1.575 | 1.546–1.586 | 1.607 | 2.1% | 215.36 | Index Only Scan | 0.040 | 1.616 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_103 | gin | 10 | 5.063 | 3.603–6.176 | 6.609 | 24.4% | 67.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 5.111 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_103 | gist | 10 | 3.588 | 3.498–3.764 | 4.535 | 12.9% | 94.58 | Index Only Scan | 0.061 | 3.654 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_103 | hash (partial) | 10 | 5.881 | 4.239–7.076 | 7.972 | 24.9% | 57.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 5.928 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_103 | roaring | 10 | 0.019 | 0.016–0.022 | 0.024 | 21.6% | 17857.63 | RoaringCount | 0.040 | 0.059 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_103 | roaring_bitmap | 10 | 3.935 | 2.882–5.983 | 6.205 | 35.6% | 86.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 4.011 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_103 | seq | 10 | 339.295 | 323.063–347.481 | 356.253 | 3.7% | 1.00 | Seq Scan | 0.044 | 339.339 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_17 | brin | 10 | 4.471 | 3.970–4.598 | 4.835 | 13.1% | 74.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.075 | 4.549 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_17 | btree | 10 | 1.510 | 1.494–1.536 | 1.580 | 2.8% | 221.22 | Index Only Scan | 0.039 | 1.553 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_17 | btree_tuned | 10 | 1.581 | 1.516–1.662 | 2.009 | 13.5% | 211.42 | Index Only Scan | 0.037 | 1.623 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_17 | gin | 10 | 6.386 | 4.830–6.697 | 6.890 | 20.0% | 52.32 | Bitmap Heap Scan, Bitmap Index Scan | 0.075 | 6.492 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_17 | gist | 10 | 3.530 | 3.385–3.657 | 3.710 | 4.3% | 94.67 | Index Only Scan | 0.064 | 3.597 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_17 | hash (partial) | 10 | 5.329 | 3.629–6.352 | 6.716 | 27.6% | 62.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 5.386 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_17 | roaring | 10 | 0.019 | 0.012–0.037 | 0.050 | 60.7% | 17586.63 | RoaringCount | 0.039 | 0.057 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_17 | roaring_bitmap | 10 | 5.008 | 3.808–5.580 | 6.046 | 19.3% | 66.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 5.055 |
| scalar | 5000000 | clean | default | 64MB | eq_clustered_17 | seq | 10 | 334.146 | 328.663–336.682 | 339.530 | 1.9% | 1.00 | Seq Scan | 0.043 | 334.191 |
| scalar | 5000000 | clean | default | 64MB | eq_nullable_17 | brin | 10 | 355.897 | 348.279–358.610 | 361.001 | 2.2% | 1.00 | Seq Scan (fallback) | 0.074 | 355.971 |
| scalar | 5000000 | clean | default | 64MB | eq_nullable_17 | btree | 10 | 1.359 | 1.326–1.395 | 1.444 | 3.4% | 260.60 | Index Only Scan | 0.038 | 1.405 |
| scalar | 5000000 | clean | default | 64MB | eq_nullable_17 | btree_tuned | 10 | 1.389 | 1.359–1.408 | 1.424 | 2.3% | 254.97 | Index Only Scan | 0.044 | 1.445 |
| scalar | 5000000 | clean | default | 64MB | eq_nullable_17 | gin | 10 | 209.162 | 111.585–216.684 | 230.035 | 47.9% | 1.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.072 | 209.229 |
| scalar | 5000000 | clean | default | 64MB | eq_nullable_17 | gist | 10 | 3.064 | 3.023–3.149 | 3.246 | 3.1% | 115.59 | Index Only Scan | 0.036 | 3.115 |
| scalar | 5000000 | clean | default | 64MB | eq_nullable_17 | hash (partial) | 10 | 210.630 | 195.344–217.911 | 235.770 | 23.4% | 1.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 210.689 |
| scalar | 5000000 | clean | default | 64MB | eq_nullable_17 | roaring | 10 | 0.107 | 0.097–0.125 | 0.338 | 86.0% | 3309.91 | RoaringCount | 0.039 | 0.150 |
| scalar | 5000000 | clean | default | 64MB | eq_nullable_17 | roaring_bitmap | 10 | 214.920 | 210.699–217.275 | 218.488 | 1.5% | 1.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 215.015 |
| scalar | 5000000 | clean | default | 64MB | eq_nullable_17 | seq | 10 | 354.160 | 348.208–362.373 | 364.887 | 2.1% | 1.00 | Seq Scan | 0.044 | 354.204 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_0 | brin | 10 | 491.613 | 482.707–501.370 | 510.061 | 2.2% | 1.02 | Seq Scan (fallback) | 0.106 | 491.829 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_0 | btree | 10 | 285.022 | 276.270–298.202 | 298.932 | 3.6% | 1.76 | Index Only Scan | 0.036 | 285.056 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_0 | btree_tuned | 10 | 283.435 | 280.576–293.034 | 297.300 | 2.4% | 1.77 | Index Only Scan | 0.039 | 283.474 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_0 | gin | 10 | 700.176 | 625.467–893.481 | 921.836 | 19.5% | 0.72 | Seq Scan (fallback) | 0.071 | 700.250 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_0 | gist | 10 | 654.925 | 649.580–657.529 | 673.901 | 2.4% | 0.77 | Index Only Scan | 0.040 | 654.976 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_0 | hash (partial) | 10 | 867.320 | 815.549–937.615 | 970.559 | 8.8% | 0.58 | Seq Scan (fallback) | 0.038 | 867.361 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_0 | roaring | 10 | 1.427 | 0.866–1.615 | 1.855 | 30.3% | 351.17 | RoaringCount | 0.052 | 1.481 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_0 | roaring_bitmap | 10 | 777.908 | 726.958–800.491 | 824.785 | 8.7% | 0.64 | Seq Scan (fallback) | 0.036 | 777.957 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_0 | seq | 10 | 501.118 | 492.947–506.752 | 509.544 | 1.6% | 1.00 | Seq Scan | 0.043 | 501.161 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_17 | brin | 10 | 583.409 | 575.559–593.614 | 595.583 | 1.8% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.079 | 583.611 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_17 | btree | 10 | 0.055 | 0.047–0.060 | 0.061 | 11.6% | 6171.82 | Index Only Scan | 0.036 | 0.094 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_17 | btree_tuned | 10 | 0.060 | 0.051–0.073 | 0.098 | 28.8% | 5657.50 | Index Only Scan | 0.040 | 0.103 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_17 | gin | 10 | 4.854 | 4.691–5.144 | 5.431 | 6.9% | 69.93 | Bitmap Heap Scan, Bitmap Index Scan | 0.079 | 4.930 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_17 | gist | 10 | 0.116 | 0.110–0.120 | 0.126 | 7.1% | 2938.96 | Index Only Scan | 0.044 | 0.165 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_17 | hash (partial) | 10 | 701.694 | 641.499–797.861 | 833.873 | 12.1% | 0.48 | Seq Scan (fallback) | 0.053 | 701.736 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_17 | roaring | 10 | 0.038 | 0.031–0.123 | 0.369 | 145.4% | 8932.89 | RoaringCount | 0.039 | 0.080 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_17 | roaring_bitmap | 10 | 5.160 | 4.881–5.436 | 5.878 | 33.8% | 65.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 5.207 |
| scalar | 5000000 | clean | default | 64MB | eq_skew_17 | seq | 10 | 339.450 | 335.087–346.714 | 351.517 | 2.0% | 1.00 | Seq Scan | 0.043 | 339.493 |
| scalar | 5000000 | clean | default | 64MB | fetch_clustered | brin | 10 | 5.331 | 5.066–5.553 | 5.682 | 6.6% | 63.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.097 | 5.478 |
| scalar | 5000000 | clean | default | 64MB | fetch_clustered | btree | 10 | 4.086 | 3.246–4.272 | 4.828 | 16.3% | 82.41 | Index Scan | 0.041 | 4.125 |
| scalar | 5000000 | clean | default | 64MB | fetch_clustered | btree_tuned | 10 | 3.682 | 3.219–4.081 | 4.191 | 13.4% | 91.46 | Index Scan | 0.042 | 3.720 |
| scalar | 5000000 | clean | default | 64MB | fetch_clustered | gin | 10 | 6.738 | 5.596–7.289 | 7.561 | 14.7% | 49.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 6.807 |
| scalar | 5000000 | clean | default | 64MB | fetch_clustered | gist | 10 | 6.486 | 4.851–6.646 | 7.004 | 22.2% | 51.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 6.542 |
| scalar | 5000000 | clean | default | 64MB | fetch_clustered | hash (partial) | 10 | 7.406 | 5.105–7.772 | 7.975 | 23.6% | 45.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 7.451 |
| scalar | 5000000 | clean | default | 64MB | fetch_clustered | roaring | 10 | 5.594 | 4.299–6.592 | 7.433 | 28.9% | 60.20 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 5.633 |
| scalar | 5000000 | clean | default | 64MB | fetch_clustered | roaring_bitmap | 10 | 5.716 | 4.541–6.219 | 6.527 | 19.8% | 58.91 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 5.769 |
| scalar | 5000000 | clean | default | 64MB | fetch_clustered | seq | 10 | 336.707 | 331.420–341.608 | 342.520 | 1.6% | 1.00 | Seq Scan | 0.046 | 336.753 |
| scalar | 5000000 | clean | default | 64MB | fetch_medium | brin | 10 | 309.397 | 304.793–320.688 | 321.690 | 2.4% | 1.00 | Seq Scan (fallback) | 0.076 | 309.473 |
| scalar | 5000000 | clean | default | 64MB | fetch_medium | btree | 10 | 18.251 | 14.580–19.345 | 21.287 | 15.8% | 16.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 18.288 |
| scalar | 5000000 | clean | default | 64MB | fetch_medium | btree_tuned | 10 | 3.005 | 2.737–3.546 | 3.861 | 15.5% | 103.06 | Index Only Scan | 0.043 | 3.064 |
| scalar | 5000000 | clean | default | 64MB | fetch_medium | gin | 10 | 20.881 | 19.025–190.380 | 250.780 | 119.4% | 14.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 20.938 |
| scalar | 5000000 | clean | default | 64MB | fetch_medium | gist | 10 | 19.722 | 18.797–91.969 | 314.714 | 178.2% | 15.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 19.778 |
| scalar | 5000000 | clean | default | 64MB | fetch_medium | hash (partial) | 10 | 19.809 | 17.047–22.837 | 28.225 | 23.5% | 15.63 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 19.864 |
| scalar | 5000000 | clean | default | 64MB | fetch_medium | roaring | 10 | 19.941 | 19.040–86.401 | 207.621 | 145.6% | 15.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 19.986 |
| scalar | 5000000 | clean | default | 64MB | fetch_medium | roaring_bitmap | 10 | 178.188 | 27.479–231.368 | 250.402 | 64.5% | 1.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 178.257 |
| scalar | 5000000 | clean | default | 64MB | fetch_medium | seq | 10 | 309.698 | 306.492–315.101 | 321.555 | 2.1% | 1.00 | Seq Scan | 0.046 | 309.744 |
| scalar | 5000000 | clean | default | 64MB | fetch_rare | brin | 10 | 553.485 | 548.092–559.276 | 595.610 | 4.2% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 553.561 |
| scalar | 5000000 | clean | default | 64MB | fetch_rare | btree | 10 | 2.457 | 1.535–3.173 | 3.704 | 48.5% | 128.32 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 2.497 |
| scalar | 5000000 | clean | default | 64MB | fetch_rare | btree_tuned | 10 | 2.281 | 0.267–3.188 | 3.614 | 79.2% | 138.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 2.340 |
| scalar | 5000000 | clean | default | 64MB | fetch_rare | gin | 10 | 2.044 | 1.333–2.227 | 2.626 | 40.3% | 154.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 2.095 |
| scalar | 5000000 | clean | default | 64MB | fetch_rare | gist | 10 | 3.397 | 2.269–4.109 | 4.516 | 41.8% | 92.80 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 3.465 |
| scalar | 5000000 | clean | default | 64MB | fetch_rare | hash (partial) | 10 | 1.392 | 1.003–1.944 | 2.643 | 43.5% | 226.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 1.445 |
| scalar | 5000000 | clean | default | 64MB | fetch_rare | roaring | 10 | 1.950 | 0.359–2.838 | 3.217 | 73.7% | 161.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 1.990 |
| scalar | 5000000 | clean | default | 64MB | fetch_rare | roaring_bitmap | 10 | 2.242 | 2.153–2.665 | 3.383 | 20.4% | 140.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 2.313 |
| scalar | 5000000 | clean | default | 64MB | fetch_rare | seq | 10 | 315.207 | 309.787–322.876 | 330.301 | 3.0% | 1.00 | Seq Scan | 0.046 | 315.252 |
| scalar | 5000000 | clean | default | 64MB | group_c2 | brin | 10 | 769.001 | 754.104–791.317 | 804.789 | 3.1% | 0.93 | Seq Scan (fallback) | 0.060 | 769.061 |
| scalar | 5000000 | clean | default | 64MB | group_c2 | btree | 10 | 410.174 | 403.933–418.846 | 425.116 | 2.2% | 1.75 | Index Only Scan | 0.039 | 410.228 |
| scalar | 5000000 | clean | default | 64MB | group_c2 | btree_tuned | 10 | 410.971 | 406.368–424.445 | 435.816 | 2.9% | 1.75 | Index Only Scan | 0.043 | 411.014 |
| scalar | 5000000 | clean | default | 64MB | group_c2 | gin | 10 | 833.667 | 788.253–964.043 | 1138.197 | 16.7% | 0.86 | Seq Scan (fallback) | 0.056 | 833.727 |
| scalar | 5000000 | clean | default | 64MB | group_c2 | gist | 10 | 974.587 | 955.629–989.448 | 995.809 | 2.0% | 0.74 | Index Only Scan | 0.037 | 974.635 |
| scalar | 5000000 | clean | default | 64MB | group_c2 | hash (partial) | 10 | 1041.541 | 1009.437–1117.424 | 1188.699 | 7.4% | 0.69 | Seq Scan (fallback) | 0.043 | 1041.596 |
| scalar | 5000000 | clean | default | 64MB | group_c2 | roaring | 10 | 6.128 | 4.155–6.409 | 7.390 | 24.3% | 117.31 | RoaringCount | 0.036 | 6.162 |
| scalar | 5000000 | clean | default | 64MB | group_c2 | roaring_bitmap | 10 | 1025.438 | 901.172–1051.184 | 1063.602 | 9.3% | 0.70 | Seq Scan (fallback) | 0.042 | 1025.484 |
| scalar | 5000000 | clean | default | 64MB | group_c2 | seq | 10 | 718.946 | 709.230–743.000 | 747.380 | 2.4% | 1.00 | Seq Scan | 0.045 | 718.992 |
| scalar | 5000000 | clean | default | 64MB | group_c20 | brin | 10 | 833.553 | 795.880–836.227 | 846.244 | 2.8% | 0.95 | Seq Scan (fallback) | 0.061 | 833.612 |
| scalar | 5000000 | clean | default | 64MB | group_c20 | btree | 10 | 414.111 | 402.515–415.898 | 430.627 | 2.9% | 1.90 | Index Only Scan | 0.041 | 414.151 |
| scalar | 5000000 | clean | default | 64MB | group_c20 | btree_tuned | 10 | 413.092 | 409.536–421.264 | 428.747 | 2.0% | 1.91 | Index Only Scan | 0.042 | 413.135 |
| scalar | 5000000 | clean | default | 64MB | group_c20 | gin | 10 | 1038.106 | 988.162–1095.181 | 1112.075 | 5.7% | 0.76 | Seq Scan (fallback) | 0.035 | 1038.152 |
| scalar | 5000000 | clean | default | 64MB | group_c20 | gist | 10 | 995.077 | 966.874–1000.146 | 1008.294 | 2.0% | 0.79 | Index Only Scan | 0.058 | 995.173 |
| scalar | 5000000 | clean | default | 64MB | group_c20 | hash (partial) | 10 | 1107.371 | 1025.292–1155.048 | 1237.085 | 8.6% | 0.71 | Seq Scan (fallback) | 0.044 | 1107.421 |
| scalar | 5000000 | clean | default | 64MB | group_c20 | roaring | 10 | 5.870 | 5.335–8.295 | 8.682 | 22.3% | 134.35 | RoaringCount | 0.037 | 5.905 |
| scalar | 5000000 | clean | default | 64MB | group_c20 | roaring_bitmap | 10 | 969.578 | 848.137–981.657 | 1040.427 | 8.5% | 0.81 | Seq Scan (fallback) | 0.058 | 969.636 |
| scalar | 5000000 | clean | default | 64MB | group_c20 | seq | 10 | 788.661 | 778.074–800.831 | 810.536 | 1.8% | 1.00 | Seq Scan | 0.045 | 788.706 |
| scalar | 5000000 | clean | default | 64MB | group_c200 | brin | 10 | 862.079 | 851.755–884.160 | 895.054 | 2.6% | 0.96 | Seq Scan (fallback) | 0.061 | 862.140 |
| scalar | 5000000 | clean | default | 64MB | group_c200 | btree | 10 | 411.209 | 408.111–412.611 | 415.614 | 0.9% | 2.02 | Index Only Scan | 0.037 | 411.244 |
| scalar | 5000000 | clean | default | 64MB | group_c200 | btree_tuned | 10 | 411.875 | 404.840–415.993 | 420.002 | 1.8% | 2.01 | Index Only Scan | 0.050 | 411.928 |
| scalar | 5000000 | clean | default | 64MB | group_c200 | gin | 10 | 998.124 | 922.097–1086.399 | 1112.748 | 10.3% | 0.83 | Seq Scan (fallback) | 0.059 | 998.190 |
| scalar | 5000000 | clean | default | 64MB | group_c200 | gist | 10 | 994.946 | 981.665–1002.750 | 1008.393 | 1.4% | 0.83 | Index Only Scan | 0.037 | 994.981 |
| scalar | 5000000 | clean | default | 64MB | group_c200 | hash (partial) | 10 | 1237.843 | 1211.687–1315.847 | 1375.568 | 6.2% | 0.67 | Seq Scan (fallback) | 0.044 | 1237.898 |
| scalar | 5000000 | clean | default | 64MB | group_c200 | roaring | 10 | 25.133 | 22.331–26.999 | 29.253 | 15.2% | 33.01 | RoaringCount | 0.037 | 25.169 |
| scalar | 5000000 | clean | default | 64MB | group_c200 | roaring_bitmap | 10 | 1138.092 | 958.372–1192.293 | 1241.859 | 11.0% | 0.73 | Seq Scan (fallback) | 0.058 | 1138.152 |
| scalar | 5000000 | clean | default | 64MB | group_c200 | seq | 10 | 829.691 | 819.822–838.666 | 857.991 | 1.9% | 1.00 | Seq Scan | 0.044 | 829.735 |
| scalar | 5000000 | clean | default | 64MB | group_c20k | brin | 10 | 984.419 | 976.288–1001.078 | 1020.857 | 1.9% | 0.97 | Seq Scan (fallback) | 0.061 | 984.481 |
| scalar | 5000000 | clean | default | 64MB | group_c20k | btree | 10 | 421.274 | 410.543–431.103 | 435.271 | 2.8% | 2.26 | Index Only Scan | 0.040 | 421.325 |
| scalar | 5000000 | clean | default | 64MB | group_c20k | btree_tuned | 10 | 429.889 | 419.451–435.839 | 437.958 | 2.4% | 2.22 | Index Only Scan | 0.043 | 429.931 |
| scalar | 5000000 | clean | default | 64MB | group_c20k | gin | 10 | 1180.255 | 1089.356–1284.043 | 1349.767 | 9.1% | 0.81 | Seq Scan (fallback) | 0.042 | 1180.292 |
| scalar | 5000000 | clean | default | 64MB | group_c20k | gist | 10 | 994.955 | 970.453–1011.554 | 1027.069 | 2.7% | 0.96 | Index Only Scan | 0.037 | 994.992 |
| scalar | 5000000 | clean | default | 64MB | group_c20k | hash (partial) | 10 | 1310.804 | 1265.168–1468.022 | 1506.150 | 7.9% | 0.73 | Seq Scan (fallback) | 0.033 | 1310.846 |
| scalar | 5000000 | clean | default | 64MB | group_c20k | roaring | 10 | 255.708 | 249.727–267.968 | 274.834 | 4.2% | 3.72 | RoaringCount | 0.036 | 255.785 |
| scalar | 5000000 | clean | default | 64MB | group_c20k | roaring_bitmap | 10 | 1239.541 | 1195.454–1321.685 | 1420.703 | 8.1% | 0.77 | Seq Scan (fallback) | 0.053 | 1239.589 |
| scalar | 5000000 | clean | default | 64MB | group_c20k | seq | 10 | 952.273 | 937.285–967.438 | 981.925 | 2.0% | 1.00 | Seq Scan | 0.045 | 952.317 |
| scalar | 5000000 | clean | default | 64MB | group_filtered | brin | 10 | 312.480 | 308.407–325.502 | 331.966 | 3.1% | 1.02 | Seq Scan (fallback) | 0.084 | 312.568 |
| scalar | 5000000 | clean | default | 64MB | group_filtered | btree | 10 | 19.955 | 17.543–20.555 | 21.159 | 10.0% | 15.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.055 | 20.013 |
| scalar | 5000000 | clean | default | 64MB | group_filtered | btree_tuned | 10 | 2.160 | 2.139–2.174 | 2.226 | 2.2% | 147.47 | Index Only Scan | 0.061 | 2.234 |
| scalar | 5000000 | clean | default | 64MB | group_filtered | gin | 10 | 122.911 | 20.918–241.118 | 283.897 | 88.0% | 2.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 122.993 |
| scalar | 5000000 | clean | default | 64MB | group_filtered | gist | 10 | 141.144 | 18.993–285.038 | 308.457 | 92.5% | 2.26 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 141.202 |
| scalar | 5000000 | clean | default | 64MB | group_filtered | hash (partial) | 10 | 26.585 | 20.153–68.666 | 169.217 | 125.8% | 11.98 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 26.652 |
| scalar | 5000000 | clean | default | 64MB | group_filtered | roaring | 10 | 15.111 | 12.565–16.394 | 16.629 | 13.2% | 21.09 | RoaringCount | 0.049 | 15.162 |
| scalar | 5000000 | clean | default | 64MB | group_filtered | roaring_bitmap | 10 | 149.657 | 34.994–224.997 | 255.395 | 68.2% | 2.13 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 149.736 |
| scalar | 5000000 | clean | default | 64MB | group_filtered | seq | 10 | 318.609 | 313.942–322.704 | 332.577 | 2.8% | 1.00 | Seq Scan | 0.052 | 318.660 |
| scalar | 5000000 | clean | default | 64MB | group_nullable | brin | 10 | 912.207 | 887.286–927.183 | 943.201 | 3.4% | 0.95 | Seq Scan (fallback) | 0.061 | 912.268 |
| scalar | 5000000 | clean | default | 64MB | group_nullable | btree | 10 | 405.922 | 403.792–413.727 | 416.972 | 1.6% | 2.14 | Index Only Scan | 0.040 | 405.961 |
| scalar | 5000000 | clean | default | 64MB | group_nullable | btree_tuned | 10 | 409.916 | 399.684–417.482 | 417.547 | 2.1% | 2.12 | Index Only Scan | 0.042 | 409.958 |
| scalar | 5000000 | clean | default | 64MB | group_nullable | gin | 10 | 1079.017 | 1003.994–1135.670 | 1226.781 | 9.3% | 0.81 | Seq Scan (fallback) | 0.043 | 1079.073 |
| scalar | 5000000 | clean | default | 64MB | group_nullable | gist | 10 | 971.996 | 966.306–989.244 | 991.854 | 2.1% | 0.89 | Index Only Scan | 0.043 | 972.051 |
| scalar | 5000000 | clean | default | 64MB | group_nullable | hash (partial) | 10 | 1306.293 | 1211.490–1356.739 | 1384.132 | 6.5% | 0.67 | Seq Scan (fallback) | 0.043 | 1306.325 |
| scalar | 5000000 | clean | default | 64MB | group_nullable | roaring | 10 | 23.253 | 19.362–23.992 | 25.238 | 12.8% | 37.38 | RoaringCount | 0.037 | 23.288 |
| scalar | 5000000 | clean | default | 64MB | group_nullable | roaring_bitmap | 10 | 1083.610 | 1049.477–1210.045 | 1306.545 | 10.9% | 0.80 | Seq Scan (fallback) | 0.059 | 1083.668 |
| scalar | 5000000 | clean | default | 64MB | group_nullable | seq | 10 | 869.258 | 852.356–873.844 | 878.306 | 2.0% | 1.00 | Seq Scan | 0.044 | 869.304 |
| scalar | 5000000 | clean | default | 64MB | in_and | brin | 10 | 426.190 | 418.657–435.284 | 468.129 | 4.9% | 1.02 | Seq Scan (fallback) | 0.107 | 426.367 |
| scalar | 5000000 | clean | default | 64MB | in_and | btree | 10 | 119.703 | 74.691–128.933 | 147.457 | 35.9% | 3.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 119.751 |
| scalar | 5000000 | clean | default | 64MB | in_and | btree_tuned | 10 | 0.796 | 0.774–0.837 | 0.895 | 6.3% | 543.91 | Index Only Scan | 0.056 | 0.873 |
| scalar | 5000000 | clean | default | 64MB | in_and | gin | 10 | 150.454 | 146.161–172.016 | 180.486 | 9.6% | 2.88 | Bitmap Heap Scan, Bitmap Index Scan | 0.088 | 150.607 |
| scalar | 5000000 | clean | default | 64MB | in_and | gist | 10 | 170.479 | 149.902–203.421 | 259.608 | 36.4% | 2.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 170.541 |
| scalar | 5000000 | clean | default | 64MB | in_and | hash (partial) | 10 | 438.124 | 393.496–471.650 | 528.499 | 33.2% | 0.99 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 438.180 |
| scalar | 5000000 | clean | default | 64MB | in_and | roaring | 10 | 9.705 | 9.451–10.341 | 11.187 | 7.0% | 44.61 | RoaringCount | 0.057 | 9.773 |
| scalar | 5000000 | clean | default | 64MB | in_and | roaring_bitmap | 10 | 139.094 | 118.897–147.304 | 152.628 | 12.2% | 3.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.079 | 139.175 |
| scalar | 5000000 | clean | default | 64MB | in_and | seq | 10 | 432.956 | 422.806–440.525 | 445.827 | 2.8% | 1.00 | Seq Scan | 0.051 | 433.012 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_10 | brin | 10 | 377.838 | 373.186–385.045 | 395.901 | 2.6% | 1.09 | Bitmap Heap Scan, Bitmap Index Scan | 0.084 | 377.918 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_10 | btree | 10 | 0.168 | 0.165–0.172 | 0.179 | 3.3% | 2449.04 | Index Only Scan | 0.045 | 0.215 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_10 | btree_tuned | 10 | 0.171 | 0.168–0.174 | 0.198 | 8.7% | 2406.07 | Index Only Scan | 0.047 | 0.217 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_10 | gin | 10 | 24.065 | 23.037–24.766 | 25.965 | 32.0% | 17.10 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 24.128 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_10 | gist | 10 | 25.161 | 13.401–34.535 | 46.329 | 58.6% | 16.35 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 25.235 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_10 | hash (partial) | 10 | 18.261 | 2.715–24.139 | 32.048 | 78.0% | 22.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 18.299 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_10 | roaring | 10 | 0.220 | 0.211–0.302 | 0.388 | 28.4% | 1874.43 | RoaringCount | 0.051 | 0.273 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_10 | roaring_bitmap | 10 | 25.876 | 16.143–28.358 | 31.124 | 43.5% | 15.90 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 25.946 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_10 | seq | 10 | 411.438 | 407.257–419.969 | 428.018 | 2.2% | 1.00 | Seq Scan | 0.050 | 411.495 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_100 | brin | 10 | 482.753 | 478.032–485.889 | 495.021 | 1.6% | 0.99 | Seq Scan (fallback) | 0.117 | 482.852 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_100 | btree | 10 | 1.585 | 1.542–1.627 | 1.978 | 12.8% | 300.91 | Index Only Scan | 0.080 | 1.663 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_100 | btree_tuned | 10 | 1.541 | 1.521–1.609 | 1.740 | 6.0% | 309.50 | Index Only Scan | 0.083 | 1.624 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_100 | gin | 10 | 215.714 | 115.760–226.462 | 233.155 | 47.5% | 2.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.130 | 216.114 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_100 | gist | 10 | 308.895 | 248.387–358.657 | 382.763 | 20.8% | 1.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.094 | 308.996 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_100 | hash (partial) | 10 | 216.942 | 40.361–233.443 | 257.535 | 58.9% | 2.20 | Bitmap Heap Scan, Bitmap Index Scan | 0.093 | 217.045 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_100 | roaring | 10 | 2.510 | 2.434–2.743 | 2.850 | 6.8% | 189.98 | RoaringCount | 0.129 | 2.630 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_100 | roaring_bitmap | 10 | 233.760 | 223.555–237.858 | 238.550 | 5.4% | 2.04 | Bitmap Heap Scan, Bitmap Index Scan | 0.109 | 233.858 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_100 | seq | 10 | 476.946 | 473.128–487.354 | 501.445 | 2.5% | 1.00 | Seq Scan | 0.088 | 477.031 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_1000 | brin | 10 | 449.708 | 442.805–452.731 | 461.056 | 2.0% | 1.00 | Seq Scan (fallback) | 0.480 | 450.331 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_1000 | btree | 10 | 16.227 | 15.190–16.592 | 20.937 | 13.5% | 27.74 | Index Only Scan | 0.476 | 16.704 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_1000 | btree_tuned | 10 | 15.761 | 15.461–17.264 | 19.579 | 10.3% | 28.56 | Index Only Scan | 0.446 | 16.203 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_1000 | gin | 10 | 461.094 | 406.856–513.989 | 550.916 | 14.2% | 0.98 | Bitmap Heap Scan, Bitmap Index Scan | 0.637 | 461.725 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_1000 | gist | 10 | 524.125 | 446.637–602.440 | 680.150 | 17.3% | 0.86 | Bitmap Heap Scan, Bitmap Index Scan | 0.460 | 524.623 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_1000 | hash (partial) | 10 | 552.490 | 481.847–621.363 | 673.094 | 15.7% | 0.81 | Bitmap Heap Scan, Bitmap Index Scan | 0.457 | 552.951 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_1000 | roaring | 10 | 67.514 | 66.853–70.811 | 76.916 | 6.5% | 6.67 | RoaringCount | 0.816 | 68.316 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_1000 | roaring_bitmap | 10 | 441.822 | 402.594–508.782 | 609.413 | 17.6% | 1.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.567 | 442.284 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_1000 | seq | 10 | 450.200 | 440.126–460.367 | 470.499 | 2.6% | 1.00 | Seq Scan | 0.465 | 450.749 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_3 | brin | 10 | 132.329 | 128.749–139.153 | 145.423 | 6.6% | 3.24 | Bitmap Heap Scan, Bitmap Index Scan | 0.087 | 132.430 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_3 | btree | 10 | 0.065 | 0.063–0.080 | 0.095 | 18.4% | 6643.31 | Index Only Scan | 0.040 | 0.105 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_3 | btree_tuned | 10 | 0.070 | 0.066–0.078 | 0.089 | 12.2% | 6165.37 | Index Only Scan | 0.044 | 0.120 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_3 | gin | 10 | 6.082 | 0.655–7.259 | 7.699 | 74.7% | 70.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 6.129 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_3 | gist | 10 | 4.105 | 0.865–11.913 | 15.186 | 94.5% | 104.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 4.147 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_3 | hash (partial) | 10 | 3.772 | 2.299–5.837 | 7.719 | 56.8% | 113.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 3.820 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_3 | roaring | 10 | 0.065 | 0.060–0.071 | 0.088 | 17.0% | 6643.31 | RoaringCount | 0.058 | 0.130 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_3 | roaring_bitmap | 10 | 4.969 | 1.687–7.881 | 8.219 | 69.3% | 86.23 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 5.056 |
| scalar | 5000000 | clean | default | 64MB | in_c20k_3 | seq | 10 | 428.494 | 423.264–442.561 | 447.316 | 2.7% | 1.00 | Seq Scan | 0.048 | 428.548 |
| scalar | 5000000 | clean | default | 64MB | in_overlap | brin | 10 | 430.599 | 424.647–439.423 | 447.964 | 2.1% | 1.03 | Seq Scan (fallback) | 0.081 | 430.949 |
| scalar | 5000000 | clean | default | 64MB | in_overlap | btree | 10 | 3.059 | 3.022–3.260 | 3.436 | 5.6% | 144.56 | Index Only Scan | 0.042 | 3.110 |
| scalar | 5000000 | clean | default | 64MB | in_overlap | btree_tuned | 10 | 3.051 | 2.991–3.130 | 3.213 | 2.9% | 144.96 | Index Only Scan | 0.045 | 3.099 |
| scalar | 5000000 | clean | default | 64MB | in_overlap | gin | 10 | 331.380 | 37.963–381.223 | 384.185 | 60.7% | 1.33 | Bitmap Heap Scan, Bitmap Index Scan | 0.082 | 331.472 |
| scalar | 5000000 | clean | default | 64MB | in_overlap | gist | 10 | 388.570 | 308.586–429.862 | 539.864 | 52.1% | 1.14 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 388.628 |
| scalar | 5000000 | clean | default | 64MB | in_overlap | hash (partial) | 10 | 139.578 | 78.076–265.328 | 297.507 | 59.1% | 3.17 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 139.627 |
| scalar | 5000000 | clean | default | 64MB | in_overlap | roaring | 10 | 0.444 | 0.427–0.481 | 0.490 | 6.1% | 997.22 | RoaringCount | 0.044 | 0.489 |
| scalar | 5000000 | clean | default | 64MB | in_overlap | roaring_bitmap | 10 | 268.510 | 110.697–394.262 | 408.308 | 62.4% | 1.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 268.549 |
| scalar | 5000000 | clean | default | 64MB | in_overlap | seq | 10 | 442.267 | 437.924–455.537 | 459.808 | 2.4% | 1.00 | Seq Scan | 0.048 | 442.314 |
| scalar | 5000000 | clean | default | 64MB | is_null | brin | 10 | 355.909 | 350.626–364.203 | 369.653 | 2.5% | 1.01 | Seq Scan (fallback) | 0.066 | 355.947 |
| scalar | 5000000 | clean | default | 64MB | is_null | btree | 10 | 33.485 | 32.266–34.955 | 37.188 | 5.7% | 10.75 | Index Only Scan | 0.033 | 33.530 |
| scalar | 5000000 | clean | default | 64MB | is_null | btree_tuned | 10 | 33.101 | 32.556–34.642 | 36.752 | 5.1% | 10.87 | Index Only Scan | 0.033 | 33.134 |
| scalar | 5000000 | clean | default | 64MB | is_null | gin | 10 | 570.652 | 494.145–679.718 | 703.873 | 17.7% | 0.63 | Seq Scan (fallback) | 0.039 | 570.697 |
| scalar | 5000000 | clean | default | 64MB | is_null | gist | 10 | 116.894 | 101.294–119.600 | 121.519 | 10.9% | 3.08 | Index Only Scan | 0.038 | 116.941 |
| scalar | 5000000 | clean | default | 64MB | is_null | hash (partial) | 10 | 763.472 | 680.559–841.898 | 863.032 | 17.2% | 0.47 | Seq Scan (fallback) | 0.027 | 763.498 |
| scalar | 5000000 | clean | default | 64MB | is_null | roaring | 10 | 0.467 | 0.448–0.609 | 0.779 | 25.2% | 770.60 | RoaringCount | 0.034 | 0.516 |
| scalar | 5000000 | clean | default | 64MB | is_null | roaring_bitmap | 10 | 480.358 | 333.914–536.886 | 566.639 | 22.8% | 0.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.055 | 480.424 |
| scalar | 5000000 | clean | default | 64MB | is_null | seq | 10 | 359.868 | 354.694–364.675 | 371.153 | 2.4% | 1.00 | Seq Scan | 0.037 | 359.905 |
| scalar | 5000000 | clean | default | 64MB | not_null | brin | 10 | 483.335 | 474.103–490.946 | 499.588 | 2.2% | 0.99 | Seq Scan (fallback) | 0.098 | 483.401 |
| scalar | 5000000 | clean | default | 64MB | not_null | btree | 10 | 287.408 | 282.551–291.007 | 293.153 | 1.9% | 1.67 | Index Only Scan | 0.033 | 287.440 |
| scalar | 5000000 | clean | default | 64MB | not_null | btree_tuned | 10 | 283.365 | 278.826–289.684 | 297.461 | 2.7% | 1.69 | Index Only Scan | 0.041 | 283.416 |
| scalar | 5000000 | clean | default | 64MB | not_null | gin | 10 | 686.389 | 622.714–732.157 | 766.034 | 12.8% | 0.70 | Seq Scan (fallback) | 0.049 | 686.429 |
| scalar | 5000000 | clean | default | 64MB | not_null | gist | 10 | 563.324 | 551.448–576.978 | 589.318 | 2.6% | 0.85 | Index Only Scan | 0.036 | 563.369 |
| scalar | 5000000 | clean | default | 64MB | not_null | hash (partial) | 10 | 925.707 | 852.798–946.771 | 962.218 | 7.4% | 0.52 | Seq Scan (fallback) | 0.034 | 925.742 |
| scalar | 5000000 | clean | default | 64MB | not_null | roaring | 10 | 293.682 | 287.754–300.749 | 313.548 | 4.1% | 1.64 | RoaringCount | 0.035 | 293.716 |
| scalar | 5000000 | clean | default | 64MB | not_null | roaring_bitmap | 10 | 699.386 | 626.636–789.815 | 847.555 | 16.2% | 0.69 | Seq Scan (fallback) | 0.053 | 699.442 |
| scalar | 5000000 | clean | default | 64MB | not_null | seq | 10 | 480.194 | 474.211–485.988 | 488.303 | 1.4% | 1.00 | Seq Scan | 0.037 | 480.231 |
| scalar | 5000000 | clean | default | 64MB | null_and | brin | 10 | 347.239 | 339.647–350.778 | 351.290 | 1.6% | 1.01 | Seq Scan (fallback) | 0.147 | 347.454 |
| scalar | 5000000 | clean | default | 64MB | null_and | btree | 10 | 19.459 | 18.745–20.825 | 23.661 | 10.6% | 18.00 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 19.512 |
| scalar | 5000000 | clean | default | 64MB | null_and | btree_tuned | 10 | 19.933 | 19.300–51.096 | 65.351 | 61.2% | 17.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 19.977 |
| scalar | 5000000 | clean | default | 64MB | null_and | gin | 10 | 71.606 | 18.008–187.673 | 227.931 | 88.8% | 4.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.072 | 71.674 |
| scalar | 5000000 | clean | default | 64MB | null_and | gist | 10 | 61.968 | 60.136–92.060 | 123.404 | 34.4% | 5.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 62.005 |
| scalar | 5000000 | clean | default | 64MB | null_and | hash (partial) | 10 | 19.386 | 16.086–21.727 | 128.078 | 162.0% | 18.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 19.421 |
| scalar | 5000000 | clean | default | 64MB | null_and | roaring | 10 | 0.825 | 0.820–0.866 | 0.957 | 7.5% | 424.38 | RoaringCount | 0.044 | 0.875 |
| scalar | 5000000 | clean | default | 64MB | null_and | roaring_bitmap | 10 | 22.962 | 21.220–42.936 | 47.778 | 39.9% | 15.26 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 23.017 |
| scalar | 5000000 | clean | default | 64MB | null_and | seq | 10 | 350.327 | 340.051–358.590 | 367.367 | 3.6% | 1.00 | Seq Scan | 0.046 | 350.375 |
| scalar | 5000000 | clean | default | 64MB | or_columns | brin | 10 | 368.521 | 362.570–379.792 | 385.256 | 2.8% | 1.00 | Seq Scan (fallback) | 0.078 | 368.588 |
| scalar | 5000000 | clean | default | 64MB | or_columns | btree | 10 | 502.442 | 475.535–552.725 | 619.359 | 15.1% | 0.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 502.483 |
| scalar | 5000000 | clean | default | 64MB | or_columns | btree_tuned | 10 | 357.557 | 350.014–402.932 | 475.176 | 13.4% | 1.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 357.603 |
| scalar | 5000000 | clean | default | 64MB | or_columns | gin | 10 | 526.341 | 355.598–594.591 | 623.680 | 23.9% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.076 | 526.418 |
| scalar | 5000000 | clean | default | 64MB | or_columns | gist | 10 | 421.724 | 403.888–454.638 | 497.549 | 9.1% | 0.87 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 421.780 |
| scalar | 5000000 | clean | default | 64MB | or_columns | hash (partial) | 10 | 799.394 | 669.014–856.122 | 862.890 | 13.6% | 0.46 | Seq Scan (fallback) | 0.036 | 799.438 |
| scalar | 5000000 | clean | default | 64MB | or_columns | roaring | 10 | 521.287 | 482.069–618.600 | 659.792 | 13.5% | 0.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 521.326 |
| scalar | 5000000 | clean | default | 64MB | or_columns | roaring_bitmap | 10 | 510.145 | 427.222–626.156 | 699.390 | 23.0% | 0.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 510.216 |
| scalar | 5000000 | clean | default | 64MB | or_columns | seq | 10 | 367.709 | 363.505–374.288 | 380.093 | 2.1% | 1.00 | Seq Scan | 0.043 | 367.757 |
| scalar | 5000000 | clean | default | 64MB | ordered_limit | brin | 10 | 506.269 | 497.602–518.808 | 524.572 | 2.3% | 1.01 | Seq Scan (fallback) | 0.080 | 506.434 |
| scalar | 5000000 | clean | default | 64MB | ordered_limit | btree | 10 | 0.018 | 0.017–0.021 | 0.040 | 50.5% | 28512.94 | Index Only Scan | 0.058 | 0.077 |
| scalar | 5000000 | clean | default | 64MB | ordered_limit | btree_tuned | 10 | 0.018 | 0.017–0.018 | 0.019 | 5.5% | 29327.60 | Index Only Scan | 0.057 | 0.075 |
| scalar | 5000000 | clean | default | 64MB | ordered_limit | gin | 10 | 711.468 | 674.375–750.439 | 855.378 | 11.5% | 0.72 | Seq Scan (fallback) | 0.065 | 711.537 |
| scalar | 5000000 | clean | default | 64MB | ordered_limit | gist | 10 | 738.577 | 725.270–751.283 | 772.054 | 3.1% | 0.69 | Index Only Scan | 0.053 | 738.637 |
| scalar | 5000000 | clean | default | 64MB | ordered_limit | hash (partial) | 10 | 811.881 | 774.458–972.303 | 993.971 | 12.3% | 0.63 | Seq Scan (fallback) | 0.057 | 811.935 |
| scalar | 5000000 | clean | default | 64MB | ordered_limit | roaring | 10 | 738.303 | 725.065–764.344 | 790.190 | 3.5% | 0.70 | Seq Scan (fallback) | 0.035 | 738.336 |
| scalar | 5000000 | clean | default | 64MB | ordered_limit | roaring_bitmap | 10 | 781.076 | 601.822–813.591 | 881.434 | 15.1% | 0.66 | Seq Scan (fallback) | 0.062 | 781.130 |
| scalar | 5000000 | clean | default | 64MB | ordered_limit | seq | 10 | 513.233 | 494.902–523.782 | 527.598 | 2.8% | 1.00 | Seq Scan | 0.047 | 513.281 |
| scalar | 5000000 | clean | default | 64MB | range_broad | brin | 10 | 464.403 | 456.202–472.650 | 477.546 | 2.0% | 1.02 | Seq Scan (fallback) | 0.071 | 464.475 |
| scalar | 5000000 | clean | default | 64MB | range_broad | btree | 10 | 156.719 | 153.236–158.985 | 161.460 | 2.5% | 3.02 | Index Only Scan | 0.054 | 156.769 |
| scalar | 5000000 | clean | default | 64MB | range_broad | btree_tuned | 10 | 158.482 | 154.695–164.196 | 169.640 | 3.7% | 2.99 | Index Only Scan | 0.055 | 158.534 |
| scalar | 5000000 | clean | default | 64MB | range_broad | gin | 10 | 1358.149 | 1196.931–1445.886 | 1461.609 | 10.2% | 0.35 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 1358.216 |
| scalar | 5000000 | clean | default | 64MB | range_broad | gist | 10 | 408.388 | 398.818–413.556 | 422.976 | 2.3% | 1.16 | Index Only Scan | 0.046 | 408.436 |
| scalar | 5000000 | clean | default | 64MB | range_broad | hash (partial) | 10 | 785.413 | 750.953–889.268 | 956.197 | 10.8% | 0.60 | Seq Scan (fallback) | 0.041 | 785.460 |
| scalar | 5000000 | clean | default | 64MB | range_broad | roaring | 10 | 709.491 | 696.714–728.069 | 758.020 | 6.3% | 0.67 | Seq Scan (fallback) | 0.040 | 709.534 |
| scalar | 5000000 | clean | default | 64MB | range_broad | roaring_bitmap | 10 | 771.129 | 613.247–842.624 | 862.854 | 20.3% | 0.61 | Seq Scan (fallback) | 0.063 | 771.179 |
| scalar | 5000000 | clean | default | 64MB | range_broad | seq | 10 | 474.019 | 467.398–479.620 | 480.980 | 1.3% | 1.00 | Seq Scan | 0.046 | 474.066 |
| scalar | 5000000 | clean | default | 64MB | range_clustered | brin | 10 | 39.114 | 37.738–39.897 | 42.609 | 5.7% | 9.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.084 | 39.335 |
| scalar | 5000000 | clean | default | 64MB | range_clustered | btree | 10 | 16.137 | 15.498–16.729 | 17.431 | 5.3% | 23.46 | Index Only Scan | 0.042 | 16.175 |
| scalar | 5000000 | clean | default | 64MB | range_clustered | btree_tuned | 10 | 15.806 | 15.213–18.055 | 23.808 | 21.2% | 23.95 | Index Only Scan | 0.043 | 15.848 |
| scalar | 5000000 | clean | default | 64MB | range_clustered | gin | 10 | 115.499 | 101.615–119.901 | 123.770 | 9.5% | 3.28 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 115.573 |
| scalar | 5000000 | clean | default | 64MB | range_clustered | gist | 10 | 40.668 | 39.103–41.095 | 44.049 | 5.1% | 9.31 | Index Only Scan | 0.043 | 40.734 |
| scalar | 5000000 | clean | default | 64MB | range_clustered | hash (partial) | 10 | 699.510 | 648.518–811.769 | 837.217 | 13.5% | 0.54 | Seq Scan (fallback) | 0.057 | 699.569 |
| scalar | 5000000 | clean | default | 64MB | range_clustered | roaring | 10 | 601.216 | 582.095–620.352 | 645.073 | 6.4% | 0.63 | Seq Scan (fallback) | 0.040 | 601.269 |
| scalar | 5000000 | clean | default | 64MB | range_clustered | roaring_bitmap | 10 | 647.885 | 495.879–708.186 | 777.238 | 22.6% | 0.58 | Seq Scan (fallback) | 0.064 | 647.952 |
| scalar | 5000000 | clean | default | 64MB | range_clustered | seq | 10 | 378.500 | 368.360–379.277 | 379.886 | 1.5% | 1.00 | Seq Scan | 0.045 | 378.546 |
| scalar | 5000000 | clean | default | 64MB | range_random | brin | 10 | 354.631 | 342.688–359.512 | 361.603 | 2.7% | 0.98 | Seq Scan (fallback) | 0.079 | 354.711 |
| scalar | 5000000 | clean | default | 64MB | range_random | btree | 10 | 1.558 | 1.528–1.565 | 1.569 | 1.4% | 222.72 | Index Only Scan | 0.065 | 1.624 |
| scalar | 5000000 | clean | default | 64MB | range_random | btree_tuned | 10 | 1.542 | 1.523–1.609 | 1.675 | 3.9% | 225.10 | Index Only Scan | 0.057 | 1.613 |
| scalar | 5000000 | clean | default | 64MB | range_random | gin | 10 | 467.131 | 455.943–479.727 | 482.475 | 15.8% | 0.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 467.222 |
| scalar | 5000000 | clean | default | 64MB | range_random | gist | 10 | 3.898 | 3.862–4.011 | 4.158 | 3.0% | 89.05 | Index Only Scan | 0.069 | 3.964 |
| scalar | 5000000 | clean | default | 64MB | range_random | hash (partial) | 10 | 648.892 | 583.444–693.406 | 780.392 | 12.5% | 0.53 | Seq Scan (fallback) | 0.058 | 648.932 |
| scalar | 5000000 | clean | default | 64MB | range_random | roaring | 10 | 590.883 | 588.146–610.961 | 632.863 | 3.2% | 0.59 | Seq Scan (fallback) | 0.040 | 590.921 |
| scalar | 5000000 | clean | default | 64MB | range_random | roaring_bitmap | 10 | 600.596 | 522.358–687.686 | 733.331 | 20.3% | 0.58 | Seq Scan (fallback) | 0.060 | 600.647 |
| scalar | 5000000 | clean | default | 64MB | range_random | seq | 10 | 347.109 | 343.715–350.778 | 357.532 | 1.9% | 1.00 | Seq Scan | 0.047 | 347.161 |
| scalar | 5000000 | clean | default | 64MB | residual_filter | brin | 10 | 359.055 | 353.072–362.996 | 370.834 | 2.4% | 1.02 | Seq Scan (fallback) | 0.075 | 359.135 |
| scalar | 5000000 | clean | default | 64MB | residual_filter | btree | 10 | 19.416 | 17.311–19.943 | 20.285 | 10.3% | 18.81 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 19.469 |
| scalar | 5000000 | clean | default | 64MB | residual_filter | btree_tuned | 10 | 2.889 | 2.841–3.664 | 3.682 | 12.8% | 126.39 | Index Only Scan | 0.046 | 2.945 |
| scalar | 5000000 | clean | default | 64MB | residual_filter | gin | 10 | 99.144 | 22.093–206.273 | 228.489 | 84.3% | 3.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.076 | 99.227 |
| scalar | 5000000 | clean | default | 64MB | residual_filter | gist | 10 | 205.353 | 22.041–322.715 | 377.924 | 82.8% | 1.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 205.394 |
| scalar | 5000000 | clean | default | 64MB | residual_filter | hash (partial) | 10 | 20.051 | 16.939–21.404 | 143.859 | 171.6% | 18.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 20.117 |
| scalar | 5000000 | clean | default | 64MB | residual_filter | roaring | 10 | 22.285 | 19.647–106.584 | 249.703 | 137.3% | 16.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 22.336 |
| scalar | 5000000 | clean | default | 64MB | residual_filter | roaring_bitmap | 10 | 167.146 | 42.762–245.622 | 253.465 | 72.4% | 2.18 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 167.200 |
| scalar | 5000000 | clean | default | 64MB | residual_filter | seq | 10 | 365.138 | 354.161–371.923 | 375.191 | 2.6% | 1.00 | Seq Scan | 0.045 | 365.188 |
| scalar | 5000000 | clean | prefer_index | 64MB | and2 | brin | 10 | 609.534 | 587.835–617.004 | 620.534 | 4.0% | 0.51 | Bitmap Heap Scan, Bitmap Index Scan | 0.085 | 609.849 |
| scalar | 5000000 | clean | prefer_index | 64MB | and2 | btree | 10 | 18.586 | 16.416–19.224 | 20.896 | 12.4% | 16.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 18.655 |
| scalar | 5000000 | clean | prefer_index | 64MB | and2 | btree_tuned | 10 | 0.877 | 0.849–0.955 | 0.986 | 6.7% | 352.53 | Index Only Scan | 0.049 | 0.930 |
| scalar | 5000000 | clean | prefer_index | 64MB | and2 | gin | 10 | 175.048 | 173.558–222.188 | 278.737 | 21.8% | 1.77 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 175.109 |
| scalar | 5000000 | clean | prefer_index | 64MB | and2 | gist | 10 | 19.643 | 17.899–136.267 | 270.489 | 137.9% | 15.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 19.705 |
| scalar | 5000000 | clean | prefer_index | 64MB | and2 | hash (partial) | 10 | 19.268 | 17.413–24.927 | 92.788 | 122.3% | 16.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 19.332 |
| scalar | 5000000 | clean | prefer_index | 64MB | and2 | roaring | 10 | 1.749 | 1.605–2.692 | 3.712 | 40.7% | 176.87 | RoaringCount | 0.045 | 1.793 |
| scalar | 5000000 | clean | prefer_index | 64MB | and2 | roaring_bitmap | 10 | 46.630 | 44.645–139.430 | 192.588 | 76.9% | 6.63 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 46.687 |
| scalar | 5000000 | clean | prefer_index | 64MB | and2 | seq | 10 | 309.344 | 306.087–313.097 | 318.915 | 1.8% | 1.00 | Seq Scan | 0.047 | 309.391 |
| scalar | 5000000 | clean | prefer_index | 64MB | and3 | brin | 10 | 552.790 | 542.953–561.309 | 564.469 | 1.9% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.374 | 553.104 |
| scalar | 5000000 | clean | prefer_index | 64MB | and3 | btree | 10 | 13.253 | 13.069–13.505 | 13.724 | 2.4% | 23.24 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 13.299 |
| scalar | 5000000 | clean | prefer_index | 64MB | and3 | btree_tuned | 10 | 0.061 | 0.059–0.062 | 0.074 | 11.5% | 5048.66 | Index Only Scan | 0.050 | 0.111 |
| scalar | 5000000 | clean | prefer_index | 64MB | and3 | gin | 10 | 26.565 | 25.355–34.795 | 42.622 | 23.4% | 11.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.078 | 26.942 |
| scalar | 5000000 | clean | prefer_index | 64MB | and3 | gist | 10 | 21.329 | 19.534–33.656 | 36.783 | 29.9% | 14.44 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 21.405 |
| scalar | 5000000 | clean | prefer_index | 64MB | and3 | hash (partial) | 10 | 18.599 | 14.045–19.883 | 42.604 | 65.4% | 16.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 18.661 |
| scalar | 5000000 | clean | prefer_index | 64MB | and3 | roaring | 10 | 1.256 | 1.221–1.470 | 3.454 | 54.5% | 245.10 | RoaringCount | 0.051 | 1.312 |
| scalar | 5000000 | clean | prefer_index | 64MB | and3 | roaring_bitmap | 10 | 19.022 | 18.140–29.853 | 31.550 | 27.8% | 16.19 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 19.091 |
| scalar | 5000000 | clean | prefer_index | 64MB | and3 | seq | 10 | 307.968 | 300.810–317.636 | 319.437 | 2.9% | 1.00 | Seq Scan | 0.050 | 308.022 |
| scalar | 5000000 | clean | prefer_index | 64MB | count_distinct | brin | 10 | 556.471 | 548.696–562.108 | 570.630 | 2.0% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.082 | 556.581 |
| scalar | 5000000 | clean | prefer_index | 64MB | count_distinct | btree | 10 | 19.806 | 16.698–20.748 | 80.771 | 117.5% | 15.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 19.853 |
| scalar | 5000000 | clean | prefer_index | 64MB | count_distinct | btree_tuned | 10 | 257.572 | 135.291–299.969 | 334.616 | 50.9% | 1.23 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 257.634 |
| scalar | 5000000 | clean | prefer_index | 64MB | count_distinct | gin | 10 | 22.145 | 19.880–148.881 | 253.437 | 113.1% | 14.26 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 22.211 |
| scalar | 5000000 | clean | prefer_index | 64MB | count_distinct | gist | 10 | 127.540 | 20.280–281.467 | 327.351 | 93.4% | 2.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 127.579 |
| scalar | 5000000 | clean | prefer_index | 64MB | count_distinct | hash (partial) | 10 | 22.221 | 19.239–72.350 | 111.265 | 94.5% | 14.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 22.288 |
| scalar | 5000000 | clean | prefer_index | 64MB | count_distinct | roaring | 10 | 22.067 | 20.276–219.742 | 235.716 | 120.0% | 14.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 22.107 |
| scalar | 5000000 | clean | prefer_index | 64MB | count_distinct | roaring_bitmap | 10 | 153.151 | 36.053–228.651 | 245.538 | 73.0% | 2.06 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 153.221 |
| scalar | 5000000 | clean | prefer_index | 64MB | count_distinct | seq | 10 | 315.760 | 312.633–321.639 | 323.745 | 2.3% | 1.00 | Seq Scan | 0.047 | 315.816 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_absent | brin | 10 | 0.389 | 0.348–0.517 | 0.767 | 38.1% | 783.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 0.467 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_absent | btree | 10 | 0.018 | 0.017–0.028 | 0.056 | 73.3% | 16470.76 | Index Only Scan | 0.038 | 0.062 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_absent | btree_tuned | 10 | 0.019 | 0.018–0.027 | 0.031 | 25.1% | 16037.32 | Index Only Scan | 0.043 | 0.066 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_absent | gin | 10 | 0.025 | 0.019–0.028 | 0.032 | 21.6% | 12437.10 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 0.082 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_absent | gist | 10 | 0.021 | 0.017–0.022 | 0.025 | 16.3% | 14863.85 | Index Only Scan | 0.065 | 0.085 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_absent | hash (partial) | 10 | 0.134 | 0.027–0.483 | 0.560 | 101.6% | 2282.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 0.206 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_absent | roaring | 10 | 0.007 | 0.007–0.009 | 0.010 | 15.2% | 40627.87 | RoaringCount | 0.039 | 0.046 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_absent | roaring_bitmap | 10 | 0.041 | 0.027–0.519 | 0.565 | 117.0% | 7342.39 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 0.105 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_absent | seq | 10 | 304.709 | 300.624–310.897 | 320.260 | 2.8% | 1.00 | Seq Scan | 0.043 | 304.758 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_12345 | brin | 10 | 563.161 | 551.028–570.317 | 573.657 | 2.6% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.076 | 563.234 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_12345 | btree | 10 | 0.033 | 0.028–0.033 | 0.039 | 18.6% | 9937.18 | Index Only Scan | 0.035 | 0.067 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_12345 | btree_tuned | 10 | 0.025 | 0.021–0.034 | 0.035 | 23.2% | 13384.78 | Index Only Scan | 0.039 | 0.069 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_12345 | gin | 10 | 0.302 | 0.238–0.395 | 0.478 | 44.4% | 1085.85 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 0.390 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_12345 | gist | 10 | 0.051 | 0.051–0.056 | 0.060 | 7.3% | 6429.94 | Index Only Scan | 0.035 | 0.087 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_12345 | hash (partial) | 10 | 0.235 | 0.043–0.498 | 0.532 | 90.5% | 1395.43 | Index Scan | 0.056 | 0.292 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_12345 | roaring | 10 | 0.018 | 0.013–0.019 | 0.046 | 76.6% | 18218.17 | RoaringCount | 0.037 | 0.053 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_12345 | roaring_bitmap | 10 | 0.368 | 0.327–0.702 | 0.905 | 49.6% | 889.90 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 0.429 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_12345 | seq | 10 | 327.927 | 323.464–330.859 | 348.469 | 3.8% | 1.00 | Seq Scan | 0.042 | 327.968 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_765432 | brin | 10 | 556.001 | 537.889–560.973 | 564.954 | 2.7% | 0.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 556.225 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_765432 | btree | 10 | 0.035 | 0.030–0.040 | 0.054 | 30.7% | 9377.83 | Index Only Scan | 0.038 | 0.076 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_765432 | btree_tuned | 10 | 0.022 | 0.020–0.050 | 0.066 | 55.4% | 14587.73 | Index Only Scan | 0.038 | 0.066 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_765432 | gin | 10 | 0.128 | 0.044–0.135 | 0.141 | 41.9% | 2574.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.055 | 0.175 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_765432 | gist | 10 | 0.052 | 0.045–0.058 | 0.060 | 15.5% | 6251.89 | Index Only Scan | 0.035 | 0.090 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_765432 | hash (partial) | 10 | 0.417 | 0.039–0.510 | 0.564 | 64.4% | 786.17 | Index Scan | 0.057 | 0.464 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_765432 | roaring | 10 | 0.019 | 0.014–0.046 | 0.080 | 84.8% | 16832.00 | RoaringCount | 0.040 | 0.067 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_765432 | roaring_bitmap | 10 | 0.135 | 0.125–0.227 | 0.453 | 88.4% | 2431.29 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 0.198 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c1m_765432 | seq | 10 | 328.224 | 321.639–333.183 | 336.002 | 2.0% | 1.00 | Seq Scan | 0.043 | 328.270 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_103 | brin | 10 | 555.996 | 544.756–574.650 | 597.665 | 3.8% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 556.070 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_103 | btree | 10 | 1.518 | 1.477–1.675 | 1.697 | 6.3% | 202.48 | Index Only Scan | 0.040 | 1.571 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_103 | btree_tuned | 10 | 1.527 | 1.509–1.573 | 1.727 | 6.4% | 201.16 | Index Only Scan | 0.040 | 1.581 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_103 | gin | 10 | 217.634 | 207.135–234.320 | 249.938 | 25.2% | 1.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 217.707 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_103 | gist | 10 | 3.580 | 3.453–3.980 | 4.134 | 8.2% | 85.83 | Index Only Scan | 0.059 | 3.645 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_103 | hash (partial) | 10 | 162.603 | 29.587–225.809 | 242.802 | 73.1% | 1.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 162.636 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_103 | roaring | 10 | 0.107 | 0.102–0.130 | 0.142 | 14.7% | 2858.29 | RoaringCount | 0.051 | 0.168 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_103 | roaring_bitmap | 10 | 216.772 | 72.524–225.887 | 237.955 | 55.4% | 1.42 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 216.834 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_103 | seq | 10 | 307.267 | 303.477–314.651 | 317.400 | 2.1% | 1.00 | Seq Scan | 0.043 | 307.309 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_17 | brin | 10 | 558.010 | 541.917–560.655 | 563.045 | 3.4% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 558.217 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_17 | btree | 10 | 1.538 | 1.498–1.564 | 1.577 | 2.6% | 203.75 | Index Only Scan | 0.037 | 1.575 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_17 | btree_tuned | 10 | 1.522 | 1.496–1.533 | 1.647 | 4.7% | 205.89 | Index Only Scan | 0.039 | 1.562 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_17 | gin | 10 | 212.914 | 46.449–222.920 | 269.071 | 65.8% | 1.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 212.976 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_17 | gist | 10 | 3.418 | 3.346–3.491 | 3.690 | 4.0% | 91.71 | Index Only Scan | 0.037 | 3.457 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_17 | hash (partial) | 10 | 19.025 | 15.320–27.444 | 57.036 | 71.8% | 16.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 19.069 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_17 | roaring | 10 | 0.102 | 0.097–0.120 | 0.129 | 12.3% | 3058.28 | RoaringCount | 0.040 | 0.163 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_17 | roaring_bitmap | 10 | 99.337 | 17.847–226.056 | 237.857 | 87.7% | 3.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 99.387 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c200_17 | seq | 10 | 313.474 | 308.998–316.901 | 319.645 | 1.7% | 1.00 | Seq Scan | 0.044 | 313.518 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_17 | brin | 10 | 557.791 | 545.282–566.709 | 583.313 | 3.0% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.087 | 557.875 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_17 | btree | 10 | 15.380 | 15.094–16.331 | 20.207 | 15.5% | 20.47 | Index Only Scan | 0.037 | 15.427 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_17 | btree_tuned | 10 | 15.222 | 15.029–15.642 | 17.346 | 7.2% | 20.68 | Index Only Scan | 0.039 | 15.261 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_17 | gin | 10 | 431.772 | 385.197–520.612 | 551.597 | 15.9% | 0.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 432.096 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_17 | gist | 10 | 37.514 | 34.841–41.741 | 46.135 | 12.2% | 8.39 | Index Only Scan | 0.064 | 37.563 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_17 | hash (partial) | 10 | 673.514 | 636.936–794.243 | 808.664 | 11.6% | 0.47 | Seq Scan (fallback) | 0.053 | 673.569 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_17 | roaring | 10 | 0.401 | 0.320–0.453 | 0.677 | 40.3% | 784.98 | RoaringCount | 0.039 | 0.444 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_17 | roaring_bitmap | 10 | 506.877 | 446.575–594.579 | 651.972 | 18.8% | 0.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 506.913 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_17 | seq | 10 | 314.777 | 309.141–318.255 | 326.560 | 2.3% | 1.00 | Seq Scan | 0.044 | 314.829 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_3 | brin | 10 | 563.546 | 531.959–568.996 | 576.913 | 5.3% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.076 | 563.622 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_3 | btree | 10 | 15.364 | 14.884–15.700 | 15.864 | 2.7% | 20.06 | Index Only Scan | 0.037 | 15.412 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_3 | btree_tuned | 10 | 15.431 | 15.231–15.774 | 17.246 | 6.0% | 19.97 | Index Only Scan | 0.039 | 15.470 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_3 | gin | 10 | 521.418 | 450.530–557.996 | 598.366 | 14.2% | 0.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 521.476 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_3 | gist | 10 | 35.659 | 33.733–37.328 | 41.644 | 9.5% | 8.64 | Index Only Scan | 0.055 | 35.727 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_3 | hash (partial) | 10 | 674.964 | 639.483–784.262 | 812.449 | 11.1% | 0.46 | Seq Scan (fallback) | 0.052 | 675.006 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_3 | roaring | 10 | 0.273 | 0.261–0.289 | 0.653 | 61.6% | 1128.78 | RoaringCount | 0.040 | 0.328 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_3 | roaring_bitmap | 10 | 500.087 | 376.386–550.976 | 581.879 | 17.6% | 0.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 500.137 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20_3 | seq | 10 | 308.156 | 305.753–313.073 | 318.100 | 2.2% | 1.00 | Seq Scan | 0.043 | 308.212 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_123 | brin | 10 | 558.822 | 548.645–570.920 | 597.661 | 3.8% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.076 | 558.894 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_123 | btree | 10 | 0.037 | 0.033–0.040 | 0.052 | 21.1% | 8662.01 | Index Only Scan | 0.051 | 0.086 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_123 | btree_tuned | 10 | 0.033 | 0.031–0.037 | 0.047 | 20.3% | 9711.95 | Index Only Scan | 0.037 | 0.071 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_123 | gin | 10 | 1.511 | 0.272–2.132 | 2.426 | 64.2% | 212.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 1.585 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_123 | gist | 10 | 0.075 | 0.071–0.080 | 0.091 | 10.9% | 4244.96 | Index Only Scan | 0.037 | 0.115 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_123 | hash (partial) | 10 | 2.244 | 0.703–2.678 | 2.915 | 53.7% | 142.85 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 2.298 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_123 | roaring | 10 | 0.023 | 0.022–0.034 | 0.057 | 47.9% | 13934.54 | RoaringCount | 0.040 | 0.063 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_123 | roaring_bitmap | 10 | 2.275 | 1.813–2.782 | 2.971 | 25.3% | 140.88 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 2.339 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_123 | seq | 10 | 320.495 | 312.274–326.338 | 334.568 | 3.1% | 1.00 | Seq Scan | 0.043 | 320.537 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_12345 | brin | 10 | 546.959 | 543.856–564.110 | 569.865 | 2.5% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 547.012 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_12345 | btree | 10 | 0.043 | 0.039–0.047 | 0.048 | 12.0% | 7328.85 | Index Only Scan | 0.038 | 0.083 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_12345 | btree_tuned | 10 | 0.036 | 0.033–0.042 | 0.051 | 20.4% | 8855.69 | Index Only Scan | 0.034 | 0.072 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_12345 | gin | 10 | 2.140 | 1.960–2.785 | 3.265 | 24.2% | 148.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 2.197 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_12345 | gist | 10 | 0.082 | 0.073–0.096 | 0.109 | 17.7% | 3887.87 | Index Only Scan | 0.060 | 0.144 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_12345 | hash (partial) | 10 | 2.496 | 2.315–2.846 | 3.030 | 27.3% | 127.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 2.554 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_12345 | roaring | 10 | 0.024 | 0.022–0.027 | 0.030 | 12.4% | 13566.17 | RoaringCount | 0.042 | 0.066 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_12345 | roaring_bitmap | 10 | 2.332 | 2.184–2.609 | 2.649 | 10.1% | 136.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 2.380 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c20k_12345 | seq | 10 | 318.805 | 313.357–325.985 | 332.622 | 2.8% | 1.00 | Seq Scan | 0.044 | 318.849 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_0 | brin | 10 | 670.011 | 658.259–678.569 | 700.265 | 2.9% | 0.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.075 | 670.453 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_0 | btree | 10 | 156.185 | 152.482–162.040 | 167.929 | 4.3% | 2.60 | Index Only Scan | 0.035 | 156.219 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_0 | btree_tuned | 10 | 159.456 | 154.612–163.767 | 167.420 | 3.3% | 2.54 | Index Only Scan | 0.040 | 159.499 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_0 | gin | 10 | 763.157 | 619.336–864.681 | 899.779 | 15.7% | 0.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 763.232 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_0 | gist | 10 | 364.153 | 354.684–371.904 | 378.578 | 3.3% | 1.11 | Index Only Scan | 0.038 | 364.191 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_0 | hash (partial) | 10 | 760.576 | 723.239–822.914 | 881.553 | 8.8% | 0.53 | Seq Scan (fallback) | 0.052 | 760.628 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_0 | roaring | 10 | 3.250 | 2.209–4.465 | 5.174 | 38.5% | 124.74 | RoaringCount | 0.056 | 3.306 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_0 | roaring_bitmap | 10 | 716.087 | 673.945–786.378 | 846.177 | 14.5% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 716.135 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_0 | seq | 10 | 405.406 | 403.666–415.556 | 430.461 | 3.3% | 1.00 | Seq Scan | 0.043 | 405.448 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_1 | brin | 10 | 662.363 | 657.152–672.023 | 683.484 | 2.0% | 0.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.098 | 662.564 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_1 | btree | 10 | 159.178 | 152.899–163.003 | 164.916 | 3.8% | 2.58 | Index Only Scan | 0.036 | 159.215 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_1 | btree_tuned | 10 | 160.571 | 154.560–163.649 | 170.006 | 4.3% | 2.55 | Index Only Scan | 0.042 | 160.619 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_1 | gin | 10 | 788.304 | 714.529–818.206 | 869.670 | 10.7% | 0.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 788.359 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_1 | gist | 10 | 366.244 | 359.589–374.317 | 386.325 | 3.2% | 1.12 | Index Only Scan | 0.045 | 366.297 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_1 | hash (partial) | 10 | 739.053 | 686.068–850.304 | 885.118 | 14.0% | 0.55 | Seq Scan (fallback) | 0.053 | 739.107 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_1 | roaring | 10 | 2.085 | 1.996–3.372 | 3.980 | 32.6% | 196.69 | RoaringCount | 0.041 | 2.137 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_1 | roaring_bitmap | 10 | 588.257 | 515.763–658.258 | 785.387 | 17.5% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 588.318 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_c2_1 | seq | 10 | 410.008 | 405.790–415.465 | 422.809 | 1.7% | 1.00 | Seq Scan | 0.043 | 410.050 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_103 | brin | 10 | 3.372 | 3.188–3.543 | 3.761 | 7.9% | 102.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 3.446 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_103 | btree | 10 | 1.562 | 1.522–1.597 | 1.762 | 7.4% | 222.18 | Index Only Scan | 0.036 | 1.607 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_103 | btree_tuned | 10 | 1.546 | 1.496–1.568 | 1.621 | 3.3% | 224.48 | Index Only Scan | 0.038 | 1.584 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_103 | gin | 10 | 5.028 | 3.997–6.469 | 7.091 | 25.1% | 69.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 5.124 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_103 | gist | 10 | 3.570 | 3.533–3.673 | 3.774 | 2.7% | 97.21 | Index Only Scan | 0.037 | 3.618 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_103 | hash (partial) | 10 | 4.403 | 3.585–6.780 | 7.166 | 30.7% | 78.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 4.463 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_103 | roaring | 10 | 0.018 | 0.017–0.024 | 0.287 | 229.6% | 19280.58 | RoaringCount | 0.035 | 0.053 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_103 | roaring_bitmap | 10 | 3.591 | 2.236–5.131 | 6.361 | 41.8% | 96.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 3.644 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_103 | seq | 10 | 347.050 | 337.751–352.342 | 354.302 | 2.6% | 1.00 | Seq Scan | 0.043 | 347.093 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_17 | brin | 10 | 4.526 | 3.582–4.748 | 5.051 | 16.3% | 73.98 | Bitmap Heap Scan, Bitmap Index Scan | 0.092 | 4.615 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_17 | btree | 10 | 1.531 | 1.492–1.585 | 2.003 | 16.0% | 218.69 | Index Only Scan | 0.037 | 1.581 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_17 | btree_tuned | 10 | 1.523 | 1.500–1.563 | 1.593 | 2.8% | 219.84 | Index Only Scan | 0.037 | 1.584 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_17 | gin | 10 | 4.752 | 3.451–6.331 | 6.513 | 30.3% | 70.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 4.800 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_17 | gist | 10 | 3.469 | 3.371–3.574 | 3.662 | 3.6% | 96.53 | Index Only Scan | 0.058 | 3.531 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_17 | hash (partial) | 10 | 5.089 | 3.670–6.801 | 7.632 | 33.1% | 65.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.033 | 5.134 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_17 | roaring | 10 | 0.018 | 0.014–0.021 | 0.043 | 64.2% | 18600.69 | RoaringCount | 0.041 | 0.059 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_17 | roaring_bitmap | 10 | 5.335 | 4.180–5.715 | 6.745 | 23.2% | 62.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 5.370 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_clustered_17 | seq | 10 | 334.812 | 326.987–338.889 | 341.589 | 1.9% | 1.00 | Seq Scan | 0.043 | 334.861 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_nullable_17 | brin | 10 | 592.587 | 587.857–603.893 | 613.024 | 1.8% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.080 | 592.770 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_nullable_17 | btree | 10 | 1.386 | 1.344–1.405 | 1.443 | 3.3% | 258.36 | Index Only Scan | 0.037 | 1.432 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_nullable_17 | btree_tuned | 10 | 1.422 | 1.410–1.442 | 1.544 | 5.0% | 251.91 | Index Only Scan | 0.039 | 1.468 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_nullable_17 | gin | 10 | 204.991 | 200.628–209.748 | 221.036 | 4.9% | 1.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 205.053 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_nullable_17 | gist | 10 | 3.149 | 3.070–3.180 | 3.250 | 2.7% | 113.74 | Index Only Scan | 0.049 | 3.197 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_nullable_17 | hash (partial) | 10 | 213.340 | 116.059–217.488 | 250.757 | 48.6% | 1.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 213.394 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_nullable_17 | roaring | 10 | 0.101 | 0.097–0.161 | 0.440 | 99.0% | 3564.30 | RoaringCount | 0.039 | 0.144 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_nullable_17 | roaring_bitmap | 10 | 212.021 | 202.511–224.735 | 226.108 | 32.5% | 1.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 212.071 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_nullable_17 | seq | 10 | 358.212 | 343.005–360.514 | 374.733 | 4.0% | 1.00 | Seq Scan | 0.043 | 358.256 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_0 | brin | 10 | 763.172 | 738.802–769.679 | 777.159 | 2.6% | 0.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.203 | 763.393 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_0 | btree | 10 | 285.095 | 279.881–288.418 | 292.484 | 2.1% | 1.75 | Index Only Scan | 0.036 | 285.130 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_0 | btree_tuned | 10 | 287.774 | 282.005–291.231 | 291.846 | 1.9% | 1.73 | Index Only Scan | 0.038 | 287.810 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_0 | gin | 10 | 929.977 | 867.515–1149.206 | 1157.215 | 13.4% | 0.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 930.049 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_0 | gist | 10 | 660.551 | 629.361–671.117 | 674.067 | 3.4% | 0.76 | Index Only Scan | 0.065 | 660.605 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_0 | hash (partial) | 10 | 931.570 | 828.862–991.528 | 998.159 | 13.8% | 0.54 | Seq Scan (fallback) | 0.031 | 931.620 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_0 | roaring | 10 | 1.482 | 0.809–1.706 | 2.007 | 38.2% | 336.77 | RoaringCount | 0.046 | 1.535 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_0 | roaring_bitmap | 10 | 716.834 | 691.198–834.611 | 852.019 | 10.1% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 716.883 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_0 | seq | 10 | 499.259 | 483.397–507.127 | 508.857 | 2.3% | 1.00 | Seq Scan | 0.043 | 499.310 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_17 | brin | 10 | 580.465 | 568.186–592.341 | 597.301 | 2.2% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.118 | 580.741 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_17 | btree | 10 | 0.061 | 0.056–0.065 | 0.068 | 10.4% | 5669.90 | Index Only Scan | 0.048 | 0.111 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_17 | btree_tuned | 10 | 0.057 | 0.055–0.061 | 0.077 | 18.9% | 6067.79 | Index Only Scan | 0.039 | 0.097 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_17 | gin | 10 | 4.869 | 4.769–4.948 | 5.072 | 32.4% | 71.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 4.966 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_17 | gist | 10 | 0.116 | 0.114–0.117 | 0.125 | 5.6% | 2994.49 | Index Only Scan | 0.039 | 0.158 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_17 | hash (partial) | 10 | 666.580 | 612.774–810.356 | 831.303 | 14.8% | 0.52 | Seq Scan (fallback) | 0.030 | 666.620 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_17 | roaring | 10 | 0.040 | 0.031–0.092 | 0.333 | 152.8% | 8756.05 | RoaringCount | 0.056 | 0.106 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_17 | roaring_bitmap | 10 | 4.949 | 4.681–5.657 | 5.912 | 34.2% | 69.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.038 | 4.997 |
| scalar | 5000000 | clean | prefer_index | 64MB | eq_skew_17 | seq | 10 | 345.864 | 340.566–352.199 | 355.734 | 1.8% | 1.00 | Seq Scan | 0.043 | 345.906 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_clustered | brin | 10 | 4.960 | 4.915–5.083 | 5.609 | 7.0% | 68.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.086 | 5.074 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_clustered | btree | 10 | 3.922 | 3.210–4.072 | 4.247 | 12.4% | 86.51 | Index Scan | 0.040 | 3.964 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_clustered | btree_tuned | 10 | 4.216 | 3.238–4.476 | 4.805 | 15.6% | 80.49 | Index Scan | 0.041 | 4.263 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_clustered | gin | 10 | 6.178 | 5.221–7.619 | 8.621 | 24.8% | 54.93 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 6.271 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_clustered | gist | 10 | 6.396 | 5.017–6.857 | 7.225 | 21.5% | 53.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 6.450 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_clustered | hash (partial) | 10 | 4.485 | 4.024–6.144 | 7.230 | 25.3% | 75.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 4.535 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_clustered | roaring | 10 | 5.748 | 2.996–5.932 | 6.294 | 30.2% | 59.04 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 5.807 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_clustered | roaring_bitmap | 10 | 5.796 | 4.583–6.555 | 6.804 | 21.7% | 58.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 5.865 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_clustered | seq | 10 | 339.341 | 329.425–346.933 | 349.875 | 2.6% | 1.00 | Seq Scan | 0.046 | 339.386 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_medium | brin | 10 | 554.600 | 546.940–564.705 | 571.224 | 1.7% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.078 | 554.775 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_medium | btree | 10 | 19.453 | 16.850–20.617 | 62.862 | 94.7% | 16.23 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 19.491 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_medium | btree_tuned | 10 | 2.838 | 2.772–2.901 | 3.455 | 12.0% | 111.30 | Index Only Scan | 0.045 | 2.885 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_medium | gin | 10 | 20.127 | 18.762–217.291 | 246.255 | 106.1% | 15.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 20.193 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_medium | gist | 10 | 24.255 | 21.256–282.118 | 306.325 | 107.6% | 13.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 24.294 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_medium | hash (partial) | 10 | 21.344 | 17.863–22.400 | 136.767 | 160.9% | 14.80 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 21.396 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_medium | roaring | 10 | 20.462 | 18.253–107.844 | 211.364 | 140.8% | 15.43 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 20.516 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_medium | roaring_bitmap | 10 | 28.945 | 19.856–234.471 | 278.515 | 113.0% | 10.91 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 29.013 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_medium | seq | 10 | 315.810 | 310.731–324.247 | 329.236 | 2.8% | 1.00 | Seq Scan | 0.046 | 315.856 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_rare | brin | 10 | 553.688 | 546.535–574.007 | 595.966 | 5.1% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.081 | 553.774 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_rare | btree | 10 | 0.286 | 0.248–2.903 | 3.459 | 107.3% | 1084.85 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 0.345 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_rare | btree_tuned | 10 | 1.436 | 0.267–2.701 | 2.907 | 72.0% | 216.44 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 1.477 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_rare | gin | 10 | 1.776 | 1.536–1.994 | 2.542 | 39.8% | 175.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.079 | 1.855 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_rare | gist | 10 | 3.771 | 2.157–4.580 | 4.989 | 51.3% | 82.42 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.814 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_rare | hash (partial) | 10 | 2.247 | 0.524–2.800 | 3.012 | 58.8% | 138.32 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 2.308 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_rare | roaring | 10 | 1.988 | 0.288–2.698 | 2.861 | 63.5% | 156.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 2.038 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_rare | roaring_bitmap | 10 | 2.128 | 0.482–2.660 | 3.494 | 66.5% | 146.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 2.168 |
| scalar | 5000000 | clean | prefer_index | 64MB | fetch_rare | seq | 10 | 310.809 | 306.767–317.692 | 319.179 | 1.9% | 1.00 | Seq Scan | 0.045 | 310.856 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c2 | brin | 10 | 782.268 | 745.842–797.277 | 828.003 | 5.0% | 0.93 | Seq Scan (fallback) | 0.061 | 782.329 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c2 | btree | 10 | 414.132 | 409.605–419.345 | 423.315 | 1.9% | 1.75 | Index Only Scan | 0.040 | 414.196 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c2 | btree_tuned | 10 | 412.649 | 410.540–416.126 | 420.704 | 2.2% | 1.75 | Index Only Scan | 0.043 | 412.691 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c2 | gin | 10 | 1014.523 | 915.875–1064.473 | 1170.227 | 10.8% | 0.71 | Seq Scan (fallback) | 0.054 | 1014.578 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c2 | gist | 10 | 963.116 | 946.803–973.959 | 997.535 | 2.4% | 0.75 | Index Only Scan | 0.038 | 963.165 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c2 | hash (partial) | 10 | 1105.054 | 1029.036–1190.446 | 1216.273 | 8.0% | 0.66 | Seq Scan (fallback) | 0.034 | 1105.088 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c2 | roaring | 10 | 4.395 | 4.223–6.985 | 8.151 | 30.3% | 164.75 | RoaringCount | 0.036 | 4.431 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c2 | roaring_bitmap | 10 | 984.459 | 829.711–1109.491 | 1137.482 | 15.3% | 0.74 | Seq Scan (fallback) | 0.050 | 984.510 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c2 | seq | 10 | 724.062 | 718.589–735.352 | 753.633 | 2.1% | 1.00 | Seq Scan | 0.044 | 724.106 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20 | brin | 10 | 826.808 | 814.158–843.359 | 860.273 | 3.1% | 0.96 | Seq Scan (fallback) | 0.062 | 826.858 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20 | btree | 10 | 413.234 | 407.374–418.506 | 426.513 | 1.9% | 1.92 | Index Only Scan | 0.040 | 413.278 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20 | btree_tuned | 10 | 415.038 | 409.092–421.351 | 425.368 | 1.6% | 1.91 | Index Only Scan | 0.044 | 415.089 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20 | gin | 10 | 975.471 | 905.564–1125.160 | 1181.528 | 13.7% | 0.81 | Seq Scan (fallback) | 0.057 | 975.518 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20 | gist | 10 | 989.003 | 967.762–1000.310 | 1010.540 | 1.9% | 0.80 | Index Only Scan | 0.051 | 989.065 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20 | hash (partial) | 10 | 1214.517 | 1062.425–1288.527 | 1300.396 | 9.8% | 0.65 | Seq Scan (fallback) | 0.053 | 1214.571 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20 | roaring | 10 | 8.412 | 5.367–8.992 | 9.905 | 26.1% | 94.44 | RoaringCount | 0.036 | 8.445 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20 | roaring_bitmap | 10 | 1013.936 | 854.121–1110.981 | 1157.572 | 12.8% | 0.78 | Seq Scan (fallback) | 0.050 | 1013.983 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20 | seq | 10 | 794.389 | 790.242–801.865 | 809.745 | 1.1% | 1.00 | Seq Scan | 0.044 | 794.433 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c200 | brin | 10 | 880.404 | 858.661–910.642 | 917.549 | 2.9% | 0.94 | Seq Scan (fallback) | 0.061 | 880.486 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c200 | btree | 10 | 412.351 | 404.475–418.661 | 432.879 | 2.9% | 2.00 | Index Only Scan | 0.052 | 412.413 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c200 | btree_tuned | 10 | 420.100 | 412.369–425.671 | 427.492 | 2.1% | 1.97 | Index Only Scan | 0.045 | 420.162 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c200 | gin | 10 | 1057.870 | 985.612–1163.182 | 1265.698 | 11.2% | 0.78 | Seq Scan (fallback) | 0.059 | 1057.926 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c200 | gist | 10 | 982.465 | 969.194–989.553 | 993.230 | 1.8% | 0.84 | Index Only Scan | 0.036 | 982.500 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c200 | hash (partial) | 10 | 1189.109 | 1074.037–1326.889 | 1365.269 | 10.3% | 0.69 | Seq Scan (fallback) | 0.050 | 1189.153 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c200 | roaring | 10 | 21.992 | 19.319–22.773 | 23.582 | 9.6% | 37.57 | RoaringCount | 0.036 | 22.027 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c200 | roaring_bitmap | 10 | 1069.809 | 981.519–1153.315 | 1287.096 | 12.8% | 0.77 | Seq Scan (fallback) | 0.054 | 1069.845 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c200 | seq | 10 | 826.193 | 817.068–854.505 | 871.481 | 2.7% | 1.00 | Seq Scan | 0.045 | 826.241 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20k | brin | 10 | 984.957 | 967.626–1006.728 | 1066.785 | 4.3% | 0.96 | Seq Scan (fallback) | 0.061 | 985.003 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20k | btree | 10 | 423.481 | 417.065–433.469 | 442.056 | 2.6% | 2.23 | Index Only Scan | 0.045 | 423.526 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20k | btree_tuned | 10 | 423.838 | 416.160–433.793 | 442.094 | 2.6% | 2.23 | Index Only Scan | 0.048 | 423.908 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20k | gin | 10 | 1201.959 | 1018.166–1294.043 | 1434.326 | 16.2% | 0.79 | Seq Scan (fallback) | 0.056 | 1202.001 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20k | gist | 10 | 991.837 | 986.390–999.601 | 1013.568 | 1.3% | 0.95 | Index Only Scan | 0.061 | 991.885 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20k | hash (partial) | 10 | 1298.178 | 1243.267–1431.566 | 1469.287 | 8.2% | 0.73 | Seq Scan (fallback) | 0.053 | 1298.224 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20k | roaring | 10 | 255.516 | 251.350–265.632 | 270.605 | 3.4% | 3.70 | RoaringCount | 0.036 | 255.552 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20k | roaring_bitmap | 10 | 1298.395 | 1236.398–1368.235 | 1428.957 | 6.7% | 0.73 | Seq Scan (fallback) | 0.049 | 1298.446 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_c20k | seq | 10 | 944.920 | 937.391–953.680 | 958.401 | 1.1% | 1.00 | Seq Scan | 0.044 | 944.964 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_filtered | brin | 10 | 560.008 | 549.060–569.398 | 572.134 | 1.9% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 560.090 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_filtered | btree | 10 | 20.909 | 20.073–22.522 | 149.984 | 166.5% | 14.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 20.957 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_filtered | btree_tuned | 10 | 2.165 | 2.118–2.216 | 2.352 | 4.7% | 141.21 | Index Only Scan | 0.054 | 2.220 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_filtered | gin | 10 | 70.772 | 19.077–218.636 | 241.829 | 92.3% | 4.32 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 70.835 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_filtered | gist | 10 | 22.546 | 21.632–176.126 | 340.093 | 136.1% | 13.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 22.605 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_filtered | hash (partial) | 10 | 23.925 | 20.236–82.003 | 167.390 | 116.0% | 12.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 23.985 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_filtered | roaring | 10 | 13.389 | 11.945–16.562 | 16.935 | 15.4% | 22.83 | RoaringCount | 0.055 | 13.438 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_filtered | roaring_bitmap | 10 | 214.450 | 116.437–230.585 | 241.403 | 49.7% | 1.43 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 214.558 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_filtered | seq | 10 | 305.711 | 303.966–312.924 | 317.076 | 1.8% | 1.00 | Seq Scan | 0.052 | 305.762 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_nullable | brin | 10 | 899.606 | 882.691–912.775 | 927.160 | 2.4% | 0.95 | Seq Scan (fallback) | 0.061 | 899.668 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_nullable | btree | 10 | 412.625 | 401.496–422.048 | 425.275 | 2.7% | 2.06 | Index Only Scan | 0.042 | 412.663 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_nullable | btree_tuned | 10 | 413.308 | 404.807–424.166 | 430.350 | 2.8% | 2.06 | Index Only Scan | 0.042 | 413.352 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_nullable | gin | 10 | 1121.778 | 1088.087–1193.657 | 1315.158 | 10.3% | 0.76 | Seq Scan (fallback) | 0.058 | 1121.814 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_nullable | gist | 10 | 981.079 | 958.379–991.902 | 997.545 | 2.2% | 0.87 | Index Only Scan | 0.036 | 981.112 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_nullable | hash (partial) | 10 | 1338.098 | 1293.008–1384.437 | 1398.039 | 4.2% | 0.64 | Seq Scan (fallback) | 0.043 | 1338.162 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_nullable | roaring | 10 | 21.498 | 19.287–23.145 | 25.040 | 11.9% | 39.62 | RoaringCount | 0.038 | 21.548 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_nullable | roaring_bitmap | 10 | 1110.912 | 1043.562–1225.718 | 1316.871 | 10.4% | 0.77 | Seq Scan (fallback) | 0.058 | 1110.958 |
| scalar | 5000000 | clean | prefer_index | 64MB | group_nullable | seq | 10 | 851.766 | 842.010–872.322 | 874.322 | 1.7% | 1.00 | Seq Scan | 0.044 | 851.809 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_and | brin | 10 | 687.017 | 674.857–694.235 | 706.547 | 2.5% | 0.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.092 | 687.095 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_and | btree | 10 | 75.619 | 39.304–136.585 | 145.159 | 58.0% | 5.66 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 75.668 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_and | btree_tuned | 10 | 0.809 | 0.792–0.852 | 0.884 | 4.8% | 529.42 | Index Only Scan | 0.054 | 0.883 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_and | gin | 10 | 148.214 | 142.268–169.063 | 179.530 | 19.9% | 2.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.085 | 148.288 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_and | gist | 10 | 194.406 | 119.503–210.096 | 218.022 | 36.1% | 2.20 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 194.480 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_and | hash (partial) | 10 | 432.004 | 135.900–448.788 | 457.308 | 45.3% | 0.99 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 432.060 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_and | roaring | 10 | 9.583 | 9.374–9.867 | 10.208 | 3.4% | 44.69 | RoaringCount | 0.057 | 9.643 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_and | roaring_bitmap | 10 | 131.000 | 84.709–141.958 | 150.734 | 35.1% | 3.27 | Bitmap Heap Scan, Bitmap Index Scan | 0.078 | 131.065 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_and | seq | 10 | 428.304 | 426.134–432.628 | 435.504 | 1.2% | 1.00 | Seq Scan | 0.051 | 428.355 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_10 | brin | 10 | 379.467 | 371.279–391.367 | 407.183 | 4.2% | 1.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 379.654 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_10 | btree | 10 | 0.172 | 0.167–0.181 | 0.191 | 6.4% | 2446.27 | Index Only Scan | 0.045 | 0.226 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_10 | btree_tuned | 10 | 0.174 | 0.170–0.182 | 0.194 | 5.8% | 2425.18 | Index Only Scan | 0.045 | 0.222 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_10 | gin | 10 | 24.619 | 24.178–25.331 | 27.360 | 32.6% | 17.14 | Bitmap Heap Scan, Bitmap Index Scan | 0.080 | 24.700 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_10 | gist | 10 | 33.880 | 25.102–40.476 | 47.618 | 43.2% | 12.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 33.951 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_10 | hash (partial) | 10 | 14.027 | 4.619–24.430 | 26.972 | 72.3% | 30.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 14.066 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_10 | roaring | 10 | 0.219 | 0.215–0.230 | 0.250 | 6.9% | 1926.85 | RoaringCount | 0.048 | 0.267 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_10 | roaring_bitmap | 10 | 22.058 | 4.999–26.066 | 26.627 | 61.5% | 19.13 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 22.108 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_10 | seq | 10 | 421.981 | 409.700–434.198 | 442.472 | 3.5% | 1.00 | Seq Scan | 0.050 | 422.031 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_100 | brin | 10 | 1050.964 | 1019.908–1066.337 | 1081.281 | 3.0% | 0.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.109 | 1051.345 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_100 | btree | 10 | 1.558 | 1.520–1.570 | 1.614 | 2.6% | 308.93 | Index Only Scan | 0.083 | 1.638 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_100 | btree_tuned | 10 | 1.572 | 1.534–1.613 | 1.818 | 8.3% | 306.08 | Index Only Scan | 0.084 | 1.663 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_100 | gin | 10 | 223.877 | 212.105–233.644 | 239.124 | 32.7% | 2.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.125 | 224.002 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_100 | gist | 10 | 381.526 | 353.990–394.500 | 439.705 | 10.1% | 1.26 | Bitmap Heap Scan, Bitmap Index Scan | 0.090 | 381.626 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_100 | hash (partial) | 10 | 217.969 | 153.177–236.127 | 237.571 | 35.7% | 2.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.091 | 218.070 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_100 | roaring | 10 | 2.425 | 2.358–2.757 | 3.036 | 11.0% | 198.41 | RoaringCount | 0.115 | 2.536 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_100 | roaring_bitmap | 10 | 228.370 | 124.320–237.115 | 245.681 | 47.3% | 2.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.108 | 228.466 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_100 | seq | 10 | 481.151 | 472.115–489.277 | 498.445 | 2.3% | 1.00 | Seq Scan | 0.089 | 481.240 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_1000 | brin | 10 | 3735.411 | 3702.305–3770.989 | 3857.411 | 2.0% | 0.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.495 | 3735.932 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_1000 | btree | 10 | 15.521 | 15.355–16.105 | 16.673 | 3.5% | 29.06 | Index Only Scan | 0.452 | 16.002 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_1000 | btree_tuned | 10 | 16.046 | 15.542–16.543 | 18.796 | 8.9% | 28.11 | Index Only Scan | 0.468 | 16.511 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_1000 | gin | 10 | 487.630 | 416.435–635.728 | 669.539 | 22.1% | 0.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.633 | 488.293 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_1000 | gist | 10 | 505.483 | 409.163–585.889 | 626.797 | 17.7% | 0.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.458 | 505.915 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_1000 | hash (partial) | 10 | 561.328 | 482.022–606.792 | 676.636 | 17.2% | 0.80 | Bitmap Heap Scan, Bitmap Index Scan | 0.447 | 561.774 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_1000 | roaring | 10 | 71.166 | 69.148–78.046 | 86.808 | 9.8% | 6.34 | RoaringCount | 0.792 | 71.951 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_1000 | roaring_bitmap | 10 | 515.416 | 423.234–631.532 | 678.668 | 19.9% | 0.88 | Bitmap Heap Scan, Bitmap Index Scan | 0.579 | 515.876 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_1000 | seq | 10 | 451.027 | 446.548–456.528 | 460.129 | 1.4% | 1.00 | Seq Scan | 0.470 | 451.490 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_3 | brin | 10 | 133.186 | 126.502–137.507 | 140.815 | 6.8% | 3.24 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 133.257 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_3 | btree | 10 | 0.068 | 0.065–0.080 | 0.092 | 15.7% | 6397.91 | Index Only Scan | 0.042 | 0.111 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_3 | btree_tuned | 10 | 0.068 | 0.065–0.071 | 0.074 | 5.2% | 6397.91 | Index Only Scan | 0.043 | 0.113 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_3 | gin | 10 | 2.764 | 0.626–6.837 | 7.575 | 89.9% | 156.24 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 2.827 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_3 | gist | 10 | 8.655 | 0.790–12.506 | 13.577 | 81.1% | 49.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 8.725 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_3 | hash (partial) | 10 | 3.080 | 1.935–6.698 | 7.999 | 70.0% | 140.24 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 3.119 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_3 | roaring | 10 | 0.061 | 0.059–0.070 | 0.322 | 133.9% | 7022.10 | RoaringCount | 0.045 | 0.107 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_3 | roaring_bitmap | 10 | 7.453 | 0.792–8.128 | 8.236 | 74.2% | 57.95 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 7.508 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_c20k_3 | seq | 10 | 431.859 | 419.096–439.026 | 448.429 | 3.0% | 1.00 | Seq Scan | 0.047 | 431.915 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_overlap | brin | 10 | 688.421 | 675.516–700.001 | 721.551 | 4.4% | 0.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 688.515 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_overlap | btree | 10 | 3.029 | 2.988–3.089 | 3.139 | 2.1% | 144.96 | Index Only Scan | 0.041 | 3.080 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_overlap | btree_tuned | 10 | 3.036 | 2.994–3.088 | 3.666 | 11.1% | 144.60 | Index Only Scan | 0.045 | 3.091 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_overlap | gin | 10 | 271.678 | 233.321–387.885 | 414.288 | 26.0% | 1.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 271.743 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_overlap | gist | 10 | 393.538 | 335.237–401.245 | 408.000 | 32.7% | 1.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 393.601 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_overlap | hash (partial) | 10 | 151.716 | 40.188–295.663 | 312.841 | 74.7% | 2.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 151.775 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_overlap | roaring | 10 | 0.457 | 0.440–0.562 | 0.691 | 20.4% | 960.65 | RoaringCount | 0.043 | 0.499 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_overlap | roaring_bitmap | 10 | 297.186 | 196.762–425.573 | 473.441 | 46.5% | 1.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 297.255 |
| scalar | 5000000 | clean | prefer_index | 64MB | in_overlap | seq | 10 | 439.015 | 432.507–449.858 | 459.098 | 2.5% | 1.00 | Seq Scan | 0.048 | 439.071 |
| scalar | 5000000 | clean | prefer_index | 64MB | is_null | brin | 10 | 606.814 | 594.714–613.163 | 627.802 | 2.4% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.072 | 606.877 |
| scalar | 5000000 | clean | prefer_index | 64MB | is_null | btree | 10 | 33.950 | 32.683–34.812 | 36.715 | 5.4% | 10.65 | Index Only Scan | 0.033 | 33.980 |
| scalar | 5000000 | clean | prefer_index | 64MB | is_null | btree_tuned | 10 | 33.165 | 32.519–35.726 | 38.121 | 6.7% | 10.90 | Index Only Scan | 0.034 | 33.197 |
| scalar | 5000000 | clean | prefer_index | 64MB | is_null | gin | 10 | 579.910 | 455.458–645.110 | 738.129 | 20.7% | 0.62 | Seq Scan (fallback) | 0.051 | 579.963 |
| scalar | 5000000 | clean | prefer_index | 64MB | is_null | gist | 10 | 100.931 | 91.041–116.282 | 117.543 | 11.8% | 3.58 | Index Only Scan | 0.056 | 100.981 |
| scalar | 5000000 | clean | prefer_index | 64MB | is_null | hash (partial) | 10 | 763.598 | 704.975–813.587 | 821.585 | 10.7% | 0.47 | Seq Scan (fallback) | 0.041 | 763.652 |
| scalar | 5000000 | clean | prefer_index | 64MB | is_null | roaring | 10 | 0.477 | 0.459–0.493 | 0.634 | 17.4% | 758.13 | RoaringCount | 0.037 | 0.512 |
| scalar | 5000000 | clean | prefer_index | 64MB | is_null | roaring_bitmap | 10 | 578.958 | 398.886–672.784 | 721.905 | 25.8% | 0.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 579.011 |
| scalar | 5000000 | clean | prefer_index | 64MB | is_null | seq | 10 | 361.630 | 355.834–368.215 | 375.108 | 2.4% | 1.00 | Seq Scan | 0.036 | 361.666 |
| scalar | 5000000 | clean | prefer_index | 64MB | not_null | brin | 10 | 735.133 | 723.245–744.589 | 760.391 | 2.6% | 0.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 735.189 |
| scalar | 5000000 | clean | prefer_index | 64MB | not_null | btree | 10 | 283.505 | 279.584–288.258 | 294.699 | 2.2% | 1.67 | Index Only Scan | 0.032 | 283.536 |
| scalar | 5000000 | clean | prefer_index | 64MB | not_null | btree_tuned | 10 | 282.062 | 279.656–288.257 | 295.361 | 2.5% | 1.68 | Index Only Scan | 0.033 | 282.094 |
| scalar | 5000000 | clean | prefer_index | 64MB | not_null | gin | 10 | 636.618 | 535.030–696.573 | 748.096 | 15.4% | 0.74 | Seq Scan (fallback) | 0.042 | 636.658 |
| scalar | 5000000 | clean | prefer_index | 64MB | not_null | gist | 10 | 579.076 | 563.047–595.377 | 607.256 | 3.7% | 0.82 | Index Only Scan | 0.053 | 579.119 |
| scalar | 5000000 | clean | prefer_index | 64MB | not_null | hash (partial) | 10 | 877.370 | 786.767–930.280 | 959.760 | 9.3% | 0.54 | Seq Scan (fallback) | 0.043 | 877.406 |
| scalar | 5000000 | clean | prefer_index | 64MB | not_null | roaring | 10 | 289.231 | 284.489–292.608 | 294.113 | 1.5% | 1.63 | RoaringCount | 0.034 | 289.285 |
| scalar | 5000000 | clean | prefer_index | 64MB | not_null | roaring_bitmap | 10 | 982.922 | 882.800–1053.271 | 1124.452 | 11.7% | 0.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 982.961 |
| scalar | 5000000 | clean | prefer_index | 64MB | not_null | seq | 10 | 472.769 | 468.445–484.458 | 499.129 | 2.6% | 1.00 | Seq Scan | 0.036 | 472.806 |
| scalar | 5000000 | clean | prefer_index | 64MB | null_and | brin | 10 | 591.875 | 579.745–598.212 | 602.394 | 1.8% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.084 | 591.925 |
| scalar | 5000000 | clean | prefer_index | 64MB | null_and | btree | 10 | 19.892 | 18.762–21.196 | 24.531 | 11.5% | 17.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 19.948 |
| scalar | 5000000 | clean | prefer_index | 64MB | null_and | btree_tuned | 10 | 19.507 | 18.910–20.011 | 20.469 | 3.1% | 17.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 19.578 |
| scalar | 5000000 | clean | prefer_index | 64MB | null_and | gin | 10 | 18.687 | 17.491–219.778 | 229.125 | 107.5% | 18.50 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 18.726 |
| scalar | 5000000 | clean | prefer_index | 64MB | null_and | gist | 10 | 90.480 | 83.737–102.712 | 116.592 | 18.6% | 3.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 90.541 |
| scalar | 5000000 | clean | prefer_index | 64MB | null_and | hash (partial) | 10 | 19.992 | 17.160–27.996 | 145.667 | 159.7% | 17.29 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 20.027 |
| scalar | 5000000 | clean | prefer_index | 64MB | null_and | roaring | 10 | 0.867 | 0.823–1.044 | 1.337 | 22.5% | 398.51 | RoaringCount | 0.043 | 0.910 |
| scalar | 5000000 | clean | prefer_index | 64MB | null_and | roaring_bitmap | 10 | 32.630 | 21.914–42.401 | 46.201 | 35.9% | 10.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 32.699 |
| scalar | 5000000 | clean | prefer_index | 64MB | null_and | seq | 10 | 345.706 | 340.916–350.824 | 358.786 | 2.2% | 1.00 | Seq Scan | 0.045 | 345.750 |
| scalar | 5000000 | clean | prefer_index | 64MB | or_columns | brin | 10 | 619.940 | 611.306–626.470 | 631.779 | 1.4% | 0.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.087 | 620.447 |
| scalar | 5000000 | clean | prefer_index | 64MB | or_columns | btree | 10 | 514.470 | 504.251–538.745 | 572.132 | 5.7% | 0.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 514.510 |
| scalar | 5000000 | clean | prefer_index | 64MB | or_columns | btree_tuned | 10 | 508.408 | 403.282–530.556 | 586.732 | 18.1% | 0.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 508.457 |
| scalar | 5000000 | clean | prefer_index | 64MB | or_columns | gin | 10 | 415.171 | 358.012–519.781 | 529.743 | 17.1% | 0.91 | Bitmap Heap Scan, Bitmap Index Scan | 0.080 | 415.233 |
| scalar | 5000000 | clean | prefer_index | 64MB | or_columns | gist | 10 | 482.049 | 417.037–556.663 | 605.840 | 17.5% | 0.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 482.115 |
| scalar | 5000000 | clean | prefer_index | 64MB | or_columns | hash (partial) | 10 | 722.561 | 644.320–830.541 | 856.207 | 16.3% | 0.53 | Seq Scan (fallback) | 0.058 | 722.663 |
| scalar | 5000000 | clean | prefer_index | 64MB | or_columns | roaring | 10 | 514.605 | 456.716–596.793 | 638.990 | 16.1% | 0.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 514.659 |
| scalar | 5000000 | clean | prefer_index | 64MB | or_columns | roaring_bitmap | 10 | 517.892 | 465.884–580.195 | 662.910 | 17.3% | 0.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 517.933 |
| scalar | 5000000 | clean | prefer_index | 64MB | or_columns | seq | 10 | 379.805 | 356.786–383.225 | 386.578 | 3.6% | 1.00 | Seq Scan | 0.043 | 379.848 |
| scalar | 5000000 | clean | prefer_index | 64MB | ordered_limit | brin | 10 | 706.612 | 699.321–724.867 | 736.867 | 3.6% | 0.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.080 | 706.692 |
| scalar | 5000000 | clean | prefer_index | 64MB | ordered_limit | btree | 10 | 0.018 | 0.017–0.018 | 0.022 | 14.5% | 28036.00 | Index Only Scan | 0.054 | 0.072 |
| scalar | 5000000 | clean | prefer_index | 64MB | ordered_limit | btree_tuned | 10 | 0.018 | 0.017–0.018 | 0.023 | 16.0% | 28036.00 | Index Only Scan | 0.059 | 0.078 |
| scalar | 5000000 | clean | prefer_index | 64MB | ordered_limit | gin | 10 | 1268.456 | 1195.625–1346.302 | 1419.389 | 7.1% | 0.40 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 1268.506 |
| scalar | 5000000 | clean | prefer_index | 64MB | ordered_limit | gist | 10 | 731.849 | 704.012–748.095 | 765.592 | 3.6% | 0.69 | Index Only Scan | 0.066 | 731.914 |
| scalar | 5000000 | clean | prefer_index | 64MB | ordered_limit | hash (partial) | 10 | 910.208 | 839.189–961.971 | 1000.587 | 7.1% | 0.55 | Seq Scan (fallback) | 0.048 | 910.256 |
| scalar | 5000000 | clean | prefer_index | 64MB | ordered_limit | roaring | 10 | 748.725 | 734.856–766.629 | 791.748 | 5.1% | 0.67 | Seq Scan (fallback) | 0.039 | 748.761 |
| scalar | 5000000 | clean | prefer_index | 64MB | ordered_limit | roaring_bitmap | 10 | 751.777 | 676.783–819.507 | 919.723 | 16.1% | 0.67 | Seq Scan (fallback) | 0.041 | 751.837 |
| scalar | 5000000 | clean | prefer_index | 64MB | ordered_limit | seq | 10 | 504.648 | 500.756–510.962 | 528.115 | 2.3% | 1.00 | Seq Scan | 0.047 | 504.695 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_broad | brin | 10 | 731.662 | 725.690–738.728 | 748.466 | 1.5% | 0.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.133 | 732.125 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_broad | btree | 10 | 156.345 | 154.031–160.908 | 166.945 | 3.3% | 2.98 | Index Only Scan | 0.063 | 156.408 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_broad | btree_tuned | 10 | 161.337 | 158.537–165.689 | 170.025 | 3.3% | 2.89 | Index Only Scan | 0.059 | 161.397 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_broad | gin | 10 | 1249.595 | 1143.227–1377.782 | 1421.243 | 9.1% | 0.37 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 1249.640 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_broad | gist | 10 | 411.238 | 400.643–415.490 | 417.433 | 2.3% | 1.13 | Index Only Scan | 0.042 | 411.293 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_broad | hash (partial) | 10 | 888.693 | 785.589–964.365 | 973.414 | 9.8% | 0.52 | Seq Scan (fallback) | 0.036 | 888.751 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_broad | roaring | 10 | 712.266 | 697.673–727.231 | 747.721 | 3.9% | 0.65 | Seq Scan (fallback) | 0.043 | 712.303 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_broad | roaring_bitmap | 10 | 695.851 | 674.442–763.208 | 880.143 | 14.3% | 0.67 | Seq Scan (fallback) | 0.063 | 695.913 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_broad | seq | 10 | 466.086 | 461.150–478.220 | 489.368 | 2.4% | 1.00 | Seq Scan | 0.046 | 466.133 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_clustered | brin | 10 | 38.726 | 37.421–41.079 | 44.495 | 9.1% | 9.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.079 | 38.802 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_clustered | btree | 10 | 15.495 | 15.403–16.098 | 17.084 | 4.8% | 23.98 | Index Only Scan | 0.042 | 15.546 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_clustered | btree_tuned | 10 | 15.643 | 15.335–15.927 | 16.314 | 2.6% | 23.76 | Index Only Scan | 0.044 | 15.684 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_clustered | gin | 10 | 110.756 | 102.906–118.356 | 119.757 | 8.8% | 3.36 | Bitmap Heap Scan, Bitmap Index Scan | 0.081 | 110.803 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_clustered | gist | 10 | 40.112 | 39.168–40.908 | 46.003 | 8.1% | 9.26 | Index Only Scan | 0.057 | 40.166 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_clustered | hash (partial) | 10 | 778.371 | 677.520–843.172 | 847.841 | 9.6% | 0.48 | Seq Scan (fallback) | 0.058 | 778.418 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_clustered | roaring | 10 | 601.380 | 592.897–607.721 | 609.148 | 6.6% | 0.62 | Seq Scan (fallback) | 0.039 | 601.433 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_clustered | roaring_bitmap | 10 | 661.892 | 558.223–707.514 | 727.204 | 13.7% | 0.56 | Seq Scan (fallback) | 0.064 | 661.931 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_clustered | seq | 10 | 371.600 | 366.654–373.905 | 377.195 | 1.7% | 1.00 | Seq Scan | 0.046 | 371.647 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_random | brin | 10 | 597.665 | 586.376–604.466 | 607.222 | 1.6% | 0.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 597.739 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_random | btree | 10 | 1.570 | 1.506–1.593 | 1.609 | 3.1% | 224.16 | Index Only Scan | 0.057 | 1.627 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_random | btree_tuned | 10 | 1.547 | 1.535–1.565 | 1.652 | 3.7% | 227.42 | Index Only Scan | 0.059 | 1.609 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_random | gin | 10 | 472.612 | 464.974–490.506 | 496.706 | 3.1% | 0.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 472.661 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_random | gist | 10 | 3.875 | 3.795–4.034 | 4.808 | 12.4% | 90.79 | Index Only Scan | 0.043 | 3.925 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_random | hash (partial) | 10 | 709.674 | 647.601–770.686 | 808.510 | 9.6% | 0.50 | Seq Scan (fallback) | 0.035 | 709.719 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_random | roaring | 10 | 598.703 | 573.437–633.699 | 668.364 | 11.2% | 0.59 | Seq Scan (fallback) | 0.037 | 598.740 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_random | roaring_bitmap | 10 | 561.471 | 435.939–631.124 | 677.861 | 21.3% | 0.63 | Seq Scan (fallback) | 0.050 | 561.512 |
| scalar | 5000000 | clean | prefer_index | 64MB | range_random | seq | 10 | 351.823 | 342.957–357.328 | 364.630 | 2.6% | 1.00 | Seq Scan | 0.047 | 351.898 |
| scalar | 5000000 | clean | prefer_index | 64MB | residual_filter | brin | 10 | 557.556 | 552.941–567.594 | 572.389 | 1.5% | 0.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.076 | 557.644 |
| scalar | 5000000 | clean | prefer_index | 64MB | residual_filter | btree | 10 | 19.609 | 19.389–19.848 | 21.867 | 8.3% | 18.51 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 19.652 |
| scalar | 5000000 | clean | prefer_index | 64MB | residual_filter | btree_tuned | 10 | 3.048 | 2.848–3.616 | 3.743 | 12.2% | 119.05 | Index Only Scan | 0.046 | 3.109 |
| scalar | 5000000 | clean | prefer_index | 64MB | residual_filter | gin | 10 | 151.975 | 28.473–219.735 | 239.405 | 70.1% | 2.39 | Bitmap Heap Scan, Bitmap Index Scan | 0.075 | 152.055 |
| scalar | 5000000 | clean | prefer_index | 64MB | residual_filter | gist | 10 | 20.952 | 18.547–27.203 | 149.483 | 162.1% | 17.32 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 21.010 |
| scalar | 5000000 | clean | prefer_index | 64MB | residual_filter | hash (partial) | 10 | 21.200 | 20.826–21.921 | 23.585 | 9.8% | 17.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 21.264 |
| scalar | 5000000 | clean | prefer_index | 64MB | residual_filter | roaring | 10 | 20.383 | 19.098–110.130 | 225.670 | 139.7% | 17.80 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 20.437 |
| scalar | 5000000 | clean | prefer_index | 64MB | residual_filter | roaring_bitmap | 10 | 185.886 | 24.228–242.726 | 271.923 | 76.4% | 1.95 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 185.941 |
| scalar | 5000000 | clean | prefer_index | 64MB | residual_filter | seq | 10 | 362.877 | 353.488–369.643 | 371.484 | 2.1% | 1.00 | Seq Scan | 0.046 | 362.924 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and2 | brin | 10 | 576.798 | 562.334–585.753 | 592.686 | 2.6% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.131 | 577.040 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and2 | btree | 10 | 17.254 | 16.561–18.520 | 19.681 | 7.2% | 18.27 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 17.310 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and2 | btree_tuned | 10 | 1.337 | 1.289–1.388 | 1.447 | 5.0% | 235.74 | Index Only Scan | 0.048 | 1.387 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and2 | gin | 10 | 198.870 | 186.459–283.815 | 292.284 | 21.0% | 1.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 198.921 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and2 | gist | 10 | 45.131 | 19.020–319.803 | 413.774 | 113.2% | 6.98 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 45.199 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and2 | hash (partial) | 10 | 21.456 | 19.416–48.474 | 167.694 | 143.1% | 14.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 21.502 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and2 | roaring | 10 | 2.103 | 2.015–2.145 | 2.219 | 4.3% | 149.91 | RoaringCount | 0.046 | 2.147 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and2 | roaring_bitmap | 10 | 45.171 | 40.993–159.759 | 188.159 | 77.2% | 6.98 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 45.242 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and2 | seq | 10 | 315.185 | 310.626–318.936 | 327.658 | 2.4% | 1.00 | Seq Scan | 0.046 | 315.231 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and3 | brin | 10 | 562.935 | 555.827–572.718 | 579.851 | 1.9% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.092 | 563.029 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and3 | btree | 10 | 16.055 | 14.110–17.952 | 18.721 | 11.7% | 19.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 16.116 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and3 | btree_tuned | 10 | 0.097 | 0.089–0.102 | 0.107 | 7.3% | 3274.55 | Index Only Scan | 0.053 | 0.149 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and3 | gin | 10 | 29.623 | 28.260–34.985 | 40.372 | 15.4% | 10.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.089 | 29.847 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and3 | gist | 10 | 24.941 | 23.847–27.444 | 38.284 | 24.3% | 12.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 24.990 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and3 | hash (partial) | 10 | 19.590 | 16.986–128.082 | 241.031 | 148.4% | 16.13 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 19.639 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and3 | roaring | 10 | 1.292 | 1.247–1.354 | 1.456 | 6.8% | 244.48 | RoaringCount | 0.051 | 1.343 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and3 | roaring_bitmap | 10 | 14.296 | 13.822–20.039 | 24.652 | 28.0% | 22.10 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 14.377 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | and3 | seq | 10 | 315.994 | 309.731–318.032 | 323.145 | 1.9% | 1.00 | Seq Scan | 0.048 | 316.042 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | brin | 10 | 572.667 | 567.942–578.995 | 589.883 | 1.9% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.072 | 572.737 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | btree | 10 | 0.024 | 0.024–0.026 | 0.028 | 6.9% | 13927.50 | Index Only Scan | 0.034 | 0.058 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | btree_tuned | 10 | 0.025 | 0.023–0.028 | 0.036 | 23.0% | 13370.40 | Index Only Scan | 0.037 | 0.061 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | gin | 10 | 0.760 | 0.707–0.913 | 1.164 | 23.4% | 439.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.075 | 0.855 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | gist | 10 | 0.054 | 0.050–0.084 | 0.288 | 125.6% | 6190.00 | Index Only Scan | 0.059 | 0.113 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | hash (partial) | 10 | 0.159 | 0.035–0.435 | 0.498 | 94.7% | 2102.26 | Index Scan | 0.036 | 0.199 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | roaring | 10 | 0.014 | 0.013–0.015 | 0.025 | 40.0% | 23052.41 | RoaringCount | 0.038 | 0.053 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | roaring_bitmap | 10 | 0.342 | 0.284–0.383 | 0.600 | 38.1% | 978.80 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 0.396 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c1m_12345 | seq | 10 | 334.260 | 331.916–345.409 | 368.591 | 4.7% | 1.00 | Seq Scan | 0.042 | 334.301 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | brin | 10 | 569.671 | 557.288–577.000 | 583.035 | 1.9% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 569.735 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | btree | 10 | 2.026 | 1.991–2.080 | 2.120 | 3.5% | 161.72 | Index Only Scan | 0.035 | 2.061 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | btree_tuned | 10 | 2.673 | 2.567–2.779 | 2.908 | 5.5% | 122.60 | Index Only Scan | 0.040 | 2.721 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | gin | 10 | 235.830 | 18.410–252.613 | 269.677 | 75.9% | 1.39 | Bitmap Heap Scan, Bitmap Index Scan | 0.055 | 235.953 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | gist | 10 | 3.896 | 3.787–4.126 | 4.328 | 5.7% | 84.12 | Index Only Scan | 0.039 | 3.939 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | hash (partial) | 10 | 19.603 | 16.752–149.577 | 277.304 | 153.6% | 16.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 19.662 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | roaring | 10 | 0.668 | 0.652–0.715 | 0.753 | 6.0% | 490.60 | RoaringCount | 0.038 | 0.709 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | roaring_bitmap | 10 | 236.673 | 80.008–245.048 | 250.752 | 55.2% | 1.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 236.721 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c200_17 | seq | 10 | 327.723 | 318.080–329.972 | 331.913 | 2.3% | 1.00 | Seq Scan | 0.042 | 327.764 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | brin | 10 | 324.509 | 321.691–328.148 | 334.354 | 1.9% | 1.00 | Seq Scan (fallback) | 0.077 | 324.649 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | btree | 10 | 18.630 | 17.869–20.262 | 23.191 | 11.1% | 17.40 | Index Only Scan | 0.035 | 18.679 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | btree_tuned | 10 | 19.245 | 18.918–21.418 | 24.626 | 11.6% | 16.84 | Index Only Scan | 0.040 | 19.287 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | gin | 10 | 540.345 | 398.021–596.328 | 647.943 | 21.7% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 540.402 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | gist | 10 | 41.258 | 38.435–43.424 | 46.292 | 7.9% | 7.85 | Index Only Scan | 0.038 | 41.295 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | hash (partial) | 10 | 628.608 | 533.382–767.196 | 816.897 | 19.0% | 0.52 | Seq Scan (fallback) | 0.051 | 628.649 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | roaring | 10 | 4.010 | 3.277–4.196 | 5.006 | 18.7% | 80.81 | RoaringCount | 0.045 | 4.069 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | roaring_bitmap | 10 | 553.547 | 437.700–589.397 | 638.617 | 16.2% | 0.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 553.599 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20_3 | seq | 10 | 324.063 | 317.487–328.423 | 329.449 | 1.9% | 1.00 | Seq Scan | 0.042 | 324.111 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | brin | 10 | 567.908 | 555.478–581.427 | 591.505 | 3.2% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 567.976 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | btree | 10 | 0.044 | 0.043–0.047 | 0.051 | 7.6% | 7419.37 | Index Only Scan | 0.036 | 0.079 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | btree_tuned | 10 | 0.047 | 0.043–0.051 | 0.055 | 10.9% | 7024.72 | Index Only Scan | 0.041 | 0.088 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | gin | 10 | 2.284 | 0.664–2.833 | 3.380 | 57.7% | 144.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 2.353 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | gist | 10 | 0.089 | 0.079–0.098 | 0.101 | 11.4% | 3709.69 | Index Only Scan | 0.035 | 0.135 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | hash (partial) | 10 | 2.896 | 2.362–3.189 | 3.313 | 21.5% | 114.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 2.941 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | roaring | 10 | 0.035 | 0.033–0.041 | 0.049 | 19.4% | 9433.20 | RoaringCount | 0.041 | 0.077 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | roaring_bitmap | 10 | 2.637 | 2.398–2.708 | 2.914 | 13.3% | 125.20 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 2.689 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c20k_123 | seq | 10 | 330.162 | 325.565–334.750 | 352.722 | 3.8% | 1.00 | Seq Scan | 0.043 | 330.230 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | brin | 10 | 434.572 | 423.562–442.627 | 447.400 | 2.3% | 0.94 | Seq Scan (fallback) | 0.186 | 434.645 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | btree | 10 | 169.281 | 166.756–172.957 | 173.884 | 2.2% | 2.42 | Index Only Scan | 0.036 | 169.315 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | btree_tuned | 10 | 172.642 | 169.956–176.315 | 180.841 | 2.5% | 2.37 | Index Only Scan | 0.040 | 172.695 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | gin | 10 | 813.442 | 747.323–962.558 | 1025.193 | 15.5% | 0.50 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 813.485 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | gist | 10 | 410.072 | 367.466–420.723 | 430.300 | 7.1% | 1.00 | Index Only Scan | 0.035 | 410.103 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | hash (partial) | 10 | 772.467 | 636.689–882.458 | 923.472 | 17.1% | 0.53 | Seq Scan (fallback) | 0.052 | 772.512 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | roaring | 10 | 13.665 | 12.684–14.817 | 16.713 | 12.8% | 29.96 | RoaringCount | 0.039 | 13.705 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | roaring_bitmap | 10 | 720.237 | 631.711–831.637 | 859.936 | 16.8% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 720.274 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_c2_0 | seq | 10 | 409.466 | 407.206–419.058 | 430.545 | 2.3% | 1.00 | Seq Scan | 0.042 | 409.508 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | brin | 10 | 21.516 | 20.759–22.275 | 25.015 | 8.6% | 16.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 21.824 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | btree | 10 | 1.512 | 1.501–1.548 | 1.554 | 1.8% | 232.58 | Index Only Scan | 0.036 | 1.550 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | btree_tuned | 10 | 1.510 | 1.499–1.556 | 1.581 | 2.6% | 232.81 | Index Only Scan | 0.039 | 1.566 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | gin | 10 | 6.056 | 5.587–7.270 | 7.927 | 15.5% | 58.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 6.183 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | gist | 10 | 3.370 | 3.273–3.437 | 3.504 | 3.1% | 104.35 | Index Only Scan | 0.035 | 3.408 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | hash (partial) | 10 | 7.441 | 6.330–8.105 | 9.307 | 25.0% | 47.26 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 7.484 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | roaring | 10 | 0.012 | 0.012–0.013 | 0.013 | 7.5% | 29304.58 | RoaringCount | 0.037 | 0.050 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | roaring_bitmap | 10 | 4.386 | 3.723–5.054 | 5.390 | 16.5% | 80.17 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 4.434 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_clustered_17 | seq | 10 | 351.655 | 347.222–386.874 | 452.480 | 11.9% | 1.00 | Seq Scan | 0.043 | 351.697 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | brin | 10 | 374.068 | 361.076–376.436 | 377.685 | 2.2% | 0.99 | Seq Scan (fallback) | 0.084 | 374.152 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | btree | 10 | 2.082 | 1.941–2.164 | 2.222 | 6.2% | 178.29 | Index Only Scan | 0.036 | 2.120 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | btree_tuned | 10 | 2.231 | 1.991–2.287 | 2.301 | 7.2% | 166.38 | Index Only Scan | 0.038 | 2.277 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | gin | 10 | 224.849 | 209.790–233.342 | 235.755 | 32.7% | 1.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.075 | 224.925 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | gist | 10 | 3.697 | 3.593–3.940 | 4.216 | 7.7% | 100.42 | Index Only Scan | 0.046 | 3.731 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | hash (partial) | 10 | 158.675 | 23.038–239.610 | 248.349 | 76.6% | 2.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.055 | 158.706 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | roaring | 10 | 0.671 | 0.633–0.694 | 0.882 | 17.4% | 552.80 | RoaringCount | 0.039 | 0.719 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | roaring_bitmap | 10 | 235.204 | 231.137–248.146 | 261.745 | 5.5% | 1.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 235.277 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_nullable_17 | seq | 10 | 371.203 | 362.324–378.240 | 378.681 | 2.2% | 1.00 | Seq Scan | 0.042 | 371.246 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | brin | 10 | 519.264 | 505.488–536.183 | 552.695 | 4.0% | 0.97 | Seq Scan (fallback) | 0.074 | 519.601 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | btree | 10 | 304.822 | 294.990–310.701 | 312.532 | 2.6% | 1.65 | Index Only Scan | 0.037 | 304.868 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | btree_tuned | 10 | 307.552 | 302.883–315.701 | 321.394 | 2.7% | 1.64 | Index Only Scan | 0.038 | 307.597 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | gin | 10 | 730.853 | 684.310–827.834 | 903.109 | 16.1% | 0.69 | Seq Scan (fallback) | 0.049 | 730.938 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | gist | 10 | 711.010 | 638.130–818.914 | 851.426 | 14.3% | 0.71 | Seq Scan (fallback) | 0.049 | 711.042 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | hash (partial) | 10 | 969.976 | 760.964–1006.845 | 1030.962 | 14.2% | 0.52 | Seq Scan (fallback) | 0.052 | 970.016 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | roaring | 10 | 14.674 | 13.724–16.268 | 17.038 | 9.5% | 34.37 | RoaringCount | 0.038 | 14.710 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | roaring_bitmap | 10 | 735.127 | 629.297–759.045 | 804.301 | 15.6% | 0.69 | Seq Scan (fallback) | 0.049 | 735.208 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | eq_skew_0 | seq | 10 | 504.300 | 494.435–513.245 | 580.161 | 8.3% | 1.00 | Seq Scan | 0.042 | 504.341 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | brin | 10 | 567.019 | 541.322–580.486 | 595.519 | 4.6% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.080 | 567.107 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | btree | 10 | 17.482 | 13.982–18.571 | 19.705 | 14.7% | 18.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 17.525 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | btree_tuned | 10 | 3.187 | 3.144–3.385 | 3.743 | 7.8% | 101.36 | Index Only Scan | 0.045 | 3.237 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | gin | 10 | 88.485 | 20.440–236.838 | 309.059 | 95.9% | 3.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 88.561 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | gist | 10 | 105.251 | 19.383–286.365 | 354.346 | 94.2% | 3.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 105.303 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | hash (partial) | 10 | 20.716 | 18.919–22.315 | 23.837 | 11.2% | 15.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 20.768 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | roaring | 10 | 18.543 | 18.051–19.410 | 19.738 | 3.7% | 17.42 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 18.581 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | roaring_bitmap | 10 | 152.385 | 19.032–246.399 | 260.275 | 78.7% | 2.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 152.457 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | fetch_medium | seq | 10 | 323.042 | 320.231–328.796 | 332.656 | 2.1% | 1.00 | Seq Scan | 0.044 | 323.086 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c2 | brin | 10 | 735.093 | 715.053–741.942 | 757.926 | 2.5% | 0.99 | Seq Scan (fallback) | 0.060 | 735.152 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c2 | btree | 10 | 433.265 | 429.349–436.706 | 438.782 | 1.3% | 1.68 | Index Only Scan | 0.038 | 433.304 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c2 | btree_tuned | 10 | 453.639 | 447.046–468.048 | 470.972 | 2.4% | 1.61 | Index Only Scan | 0.043 | 453.697 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c2 | gin | 10 | 945.312 | 929.204–1093.159 | 1124.270 | 9.1% | 0.77 | Seq Scan (fallback) | 0.048 | 945.361 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c2 | gist | 10 | 977.645 | 852.066–1063.848 | 1116.189 | 11.8% | 0.75 | Seq Scan (fallback) | 0.044 | 977.688 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c2 | hash (partial) | 10 | 1156.818 | 990.711–1195.451 | 1242.287 | 10.5% | 0.63 | Seq Scan (fallback) | 0.052 | 1156.883 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c2 | roaring | 10 | 25.902 | 24.003–26.373 | 27.063 | 5.4% | 28.17 | RoaringCount | 0.036 | 25.938 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c2 | roaring_bitmap | 10 | 905.053 | 824.766–987.760 | 1067.442 | 12.5% | 0.81 | Seq Scan (fallback) | 0.049 | 905.111 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c2 | seq | 10 | 729.727 | 722.206–743.952 | 752.404 | 1.7% | 1.00 | Seq Scan | 0.044 | 729.770 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c200 | brin | 10 | 835.906 | 820.051–850.008 | 853.396 | 1.8% | 1.00 | Seq Scan (fallback) | 0.060 | 835.987 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c200 | btree | 10 | 535.218 | 523.718–537.782 | 540.934 | 1.8% | 1.57 | Index Only Scan | 0.041 | 535.274 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c200 | btree_tuned | 10 | 614.604 | 606.053–637.142 | 643.093 | 2.6% | 1.36 | Index Only Scan | 0.045 | 614.656 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c200 | gin | 10 | 1121.336 | 1030.871–1181.975 | 1231.725 | 8.6% | 0.75 | Seq Scan (fallback) | 0.053 | 1121.385 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c200 | gist | 10 | 1185.967 | 1089.035–1199.748 | 1217.312 | 9.0% | 0.71 | Seq Scan (fallback) | 0.058 | 1186.012 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c200 | hash (partial) | 10 | 1311.746 | 1126.182–1353.464 | 1396.829 | 10.6% | 0.64 | Seq Scan (fallback) | 0.043 | 1311.799 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c200 | roaring | 10 | 1173.510 | 1145.111–1185.898 | 1198.505 | 2.0% | 0.71 | Seq Scan (fallback) | 0.037 | 1173.548 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c200 | roaring_bitmap | 10 | 1060.037 | 974.169–1107.375 | 1155.876 | 9.8% | 0.79 | Seq Scan (fallback) | 0.056 | 1060.094 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_c200 | seq | 10 | 838.029 | 828.726–844.347 | 850.243 | 1.4% | 1.00 | Seq Scan | 0.044 | 838.072 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_filtered | brin | 10 | 571.850 | 548.953–578.822 | 584.095 | 3.4% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.082 | 571.930 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_filtered | btree | 10 | 18.383 | 18.108–18.880 | 19.741 | 7.4% | 17.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 18.446 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_filtered | btree_tuned | 10 | 3.020 | 2.952–3.153 | 3.232 | 3.8% | 108.29 | Index Only Scan | 0.056 | 3.077 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_filtered | gin | 10 | 94.864 | 23.290–251.579 | 265.171 | 85.8% | 3.45 | Bitmap Heap Scan, Bitmap Index Scan | 0.075 | 94.919 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_filtered | gist | 10 | 131.195 | 19.235–364.618 | 430.759 | 100.4% | 2.49 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 131.257 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_filtered | hash (partial) | 10 | 22.122 | 19.968–23.204 | 180.297 | 181.9% | 14.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 22.178 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_filtered | roaring | 10 | 13.931 | 13.561–15.035 | 15.796 | 6.5% | 23.48 | RoaringCount | 0.048 | 14.014 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_filtered | roaring_bitmap | 10 | 170.330 | 22.994–247.039 | 272.025 | 77.6% | 1.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 170.399 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | group_filtered | seq | 10 | 327.038 | 317.733–334.312 | 363.394 | 6.2% | 1.00 | Seq Scan | 0.050 | 327.087 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_and | brin | 10 | 445.154 | 440.460–455.271 | 463.150 | 2.6% | 0.98 | Seq Scan (fallback) | 0.101 | 445.687 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_and | btree | 10 | 51.933 | 50.559–54.128 | 55.681 | 5.7% | 8.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 51.980 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_and | btree_tuned | 10 | 1.218 | 1.189–1.312 | 1.363 | 5.8% | 358.52 | Index Only Scan | 0.054 | 1.279 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_and | gin | 10 | 176.088 | 167.581–190.358 | 195.726 | 7.0% | 2.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.088 | 176.161 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_and | gist | 10 | 201.269 | 162.806–218.262 | 226.920 | 34.6% | 2.17 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 201.337 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_and | hash (partial) | 10 | 483.965 | 238.393–557.004 | 580.147 | 48.7% | 0.90 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 484.020 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_and | roaring | 10 | 10.659 | 10.169–11.537 | 12.294 | 7.7% | 40.95 | RoaringCount | 0.054 | 10.718 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_and | roaring_bitmap | 10 | 124.138 | 122.782–145.665 | 151.200 | 9.9% | 3.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.075 | 124.269 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_and | seq | 10 | 436.501 | 431.186–458.297 | 483.406 | 5.2% | 1.00 | Seq Scan | 0.051 | 436.552 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | brin | 10 | 403.773 | 393.606–414.919 | 421.016 | 3.0% | 1.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.079 | 403.981 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | btree | 10 | 0.294 | 0.276–0.310 | 0.338 | 9.5% | 1442.06 | Index Only Scan | 0.044 | 0.354 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | btree_tuned | 10 | 0.287 | 0.272–0.310 | 0.313 | 6.9% | 1477.18 | Index Only Scan | 0.046 | 0.349 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | gin | 10 | 31.183 | 29.376–31.608 | 32.510 | 21.4% | 13.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.083 | 31.233 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | gist | 10 | 26.461 | 13.307–41.792 | 49.320 | 63.9% | 16.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 26.505 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | hash (partial) | 10 | 27.546 | 13.956–28.090 | 33.133 | 52.1% | 15.42 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 27.596 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | roaring | 10 | 0.342 | 0.309–0.347 | 0.365 | 7.3% | 1241.78 | RoaringCount | 0.049 | 0.391 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | roaring_bitmap | 10 | 26.848 | 14.924–29.098 | 32.931 | 47.1% | 15.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 26.916 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_10 | seq | 10 | 424.688 | 420.623–444.567 | 577.862 | 18.0% | 1.00 | Seq Scan | 0.050 | 424.737 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | brin | 10 | 463.344 | 460.031–469.307 | 475.728 | 1.6% | 1.01 | Seq Scan (fallback) | 0.479 | 463.966 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | btree | 10 | 24.067 | 23.080–24.698 | 25.357 | 3.9% | 19.41 | Index Only Scan | 0.448 | 24.556 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | btree_tuned | 10 | 24.530 | 24.156–25.538 | 27.886 | 6.5% | 19.05 | Index Only Scan | 0.445 | 24.967 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | gin | 10 | 899.403 | 870.250–954.378 | 991.955 | 6.8% | 0.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.639 | 900.014 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | gist | 10 | 446.883 | 390.484–541.121 | 679.926 | 24.1% | 1.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.485 | 447.392 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | hash (partial) | 10 | 568.616 | 533.981–681.785 | 747.648 | 15.4% | 0.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.449 | 569.077 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | roaring | 10 | 71.145 | 67.450–74.810 | 76.725 | 5.7% | 6.57 | RoaringCount | 0.772 | 71.942 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | roaring_bitmap | 10 | 515.603 | 402.853–565.243 | 653.375 | 20.0% | 0.91 | Bitmap Heap Scan, Bitmap Index Scan | 0.472 | 516.052 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | in_c20k_1000 | seq | 10 | 467.230 | 462.691–485.062 | 500.839 | 3.5% | 1.00 | Seq Scan | 0.454 | 467.684 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | is_null | brin | 10 | 379.601 | 378.418–385.480 | 387.500 | 1.7% | 0.99 | Seq Scan (fallback) | 0.066 | 379.668 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | is_null | btree | 10 | 37.947 | 36.978–39.123 | 45.988 | 11.0% | 9.91 | Index Only Scan | 0.032 | 37.979 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | is_null | btree_tuned | 10 | 39.351 | 38.030–39.998 | 44.668 | 7.8% | 9.56 | Index Only Scan | 0.033 | 39.397 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | is_null | gin | 10 | 613.480 | 552.010–718.181 | 765.836 | 15.2% | 0.61 | Seq Scan (fallback) | 0.051 | 613.524 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | is_null | gist | 10 | 153.979 | 148.238–160.532 | 165.279 | 11.1% | 2.44 | Index Only Scan | 0.043 | 154.022 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | is_null | hash (partial) | 10 | 617.039 | 585.820–810.998 | 854.719 | 17.2% | 0.61 | Seq Scan (fallback) | 0.028 | 617.067 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | is_null | roaring | 10 | 4.704 | 4.582–5.896 | 6.759 | 18.2% | 79.94 | RoaringCount | 0.033 | 4.742 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | is_null | roaring_bitmap | 10 | 560.209 | 442.889–617.355 | 666.233 | 21.5% | 0.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 560.253 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | is_null | seq | 10 | 376.057 | 366.833–386.565 | 392.242 | 2.9% | 1.00 | Seq Scan | 0.036 | 376.093 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | range_random | brin | 10 | 618.786 | 614.313–624.615 | 630.227 | 1.8% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 618.939 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | range_random | btree | 10 | 2.548 | 2.330–2.652 | 2.732 | 7.0% | 141.99 | Index Only Scan | 0.067 | 2.612 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | range_random | btree_tuned | 10 | 2.490 | 2.397–2.526 | 2.548 | 3.0% | 145.27 | Index Only Scan | 0.059 | 2.546 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | range_random | gin | 10 | 446.797 | 439.969–459.129 | 469.192 | 2.8% | 0.81 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 446.880 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | range_random | gist | 10 | 4.517 | 4.475–4.855 | 6.531 | 18.3% | 80.09 | Index Only Scan | 0.044 | 4.561 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | range_random | hash (partial) | 10 | 798.281 | 635.412–849.863 | 901.247 | 15.4% | 0.45 | Seq Scan (fallback) | 0.035 | 798.314 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | range_random | roaring | 10 | 662.055 | 643.702–679.008 | 682.366 | 2.7% | 0.55 | Seq Scan (fallback) | 0.040 | 662.095 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | range_random | roaring_bitmap | 10 | 566.137 | 503.898–614.924 | 658.303 | 12.2% | 0.64 | Seq Scan (fallback) | 0.063 | 566.202 |
| scalar | 5000000 | dirty_clustered_5pct | default | 64MB | range_random | seq | 10 | 361.716 | 354.102–364.871 | 368.226 | 1.9% | 1.00 | Seq Scan | 0.046 | 361.776 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | brin | 10 | 573.570 | 557.586–582.970 | 597.594 | 3.2% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.101 | 573.640 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | btree | 10 | 16.709 | 15.217–17.322 | 18.361 | 10.8% | 19.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 16.757 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | btree_tuned | 10 | 1.323 | 1.257–1.449 | 1.458 | 7.2% | 241.47 | Index Only Scan | 0.050 | 1.385 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | gin | 10 | 263.990 | 183.794–303.331 | 312.497 | 24.5% | 1.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.082 | 264.061 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | gist | 10 | 18.611 | 17.459–20.156 | 248.912 | 220.0% | 17.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 18.666 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | hash (partial) | 10 | 21.142 | 20.008–118.611 | 227.326 | 140.1% | 15.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 21.248 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | roaring | 10 | 2.037 | 1.976–2.156 | 2.299 | 6.6% | 156.81 | RoaringCount | 0.045 | 2.081 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | roaring_bitmap | 10 | 73.316 | 43.199–169.037 | 186.890 | 63.5% | 4.36 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 73.370 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and2 | seq | 10 | 319.346 | 312.208–324.888 | 332.161 | 2.7% | 1.00 | Seq Scan | 0.046 | 319.407 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | brin | 10 | 569.542 | 567.200–573.958 | 580.384 | 1.2% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.094 | 569.639 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | btree | 10 | 15.245 | 13.436–17.791 | 20.165 | 17.1% | 20.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 15.310 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | btree_tuned | 10 | 0.094 | 0.087–0.100 | 0.106 | 7.8% | 3392.48 | Index Only Scan | 0.058 | 0.154 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | gin | 10 | 36.624 | 31.764–41.643 | 43.186 | 15.6% | 8.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.078 | 36.711 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | gist | 10 | 24.632 | 23.788–26.404 | 29.920 | 10.2% | 12.95 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 24.693 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | hash (partial) | 10 | 19.236 | 18.439–20.167 | 160.268 | 181.7% | 16.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 19.313 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | roaring | 10 | 1.286 | 1.270–1.314 | 1.437 | 6.5% | 247.97 | RoaringCount | 0.058 | 1.351 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | roaring_bitmap | 10 | 15.124 | 13.468–23.980 | 25.024 | 29.5% | 21.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 15.179 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | and3 | seq | 10 | 318.894 | 313.989–324.836 | 387.144 | 11.0% | 1.00 | Seq Scan | 0.048 | 318.942 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | brin | 10 | 571.579 | 564.910–582.982 | 588.099 | 3.7% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.083 | 571.796 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | btree | 10 | 0.025 | 0.024–0.027 | 0.029 | 12.4% | 13215.70 | Index Only Scan | 0.036 | 0.060 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | btree_tuned | 10 | 0.025 | 0.024–0.027 | 0.028 | 7.0% | 13215.70 | Index Only Scan | 0.037 | 0.063 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | gin | 10 | 0.777 | 0.666–0.846 | 0.880 | 18.5% | 425.22 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 0.850 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | gist | 10 | 0.058 | 0.052–0.082 | 0.148 | 61.6% | 5745.96 | Index Only Scan | 0.059 | 0.118 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | hash (partial) | 10 | 0.048 | 0.038–0.201 | 0.308 | 105.7% | 6883.18 | Index Scan | 0.055 | 0.096 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | roaring | 10 | 0.015 | 0.014–0.015 | 0.032 | 55.5% | 22026.17 | RoaringCount | 0.037 | 0.052 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | roaring_bitmap | 10 | 0.317 | 0.173–0.491 | 0.814 | 73.6% | 1043.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 0.364 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c1m_12345 | seq | 10 | 330.393 | 325.757–334.635 | 341.246 | 2.0% | 1.00 | Seq Scan | 0.041 | 330.433 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | brin | 10 | 574.995 | 564.425–579.861 | 583.309 | 1.9% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 575.060 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | btree | 10 | 1.998 | 1.980–2.024 | 2.134 | 3.7% | 161.89 | Index Only Scan | 0.034 | 2.033 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | btree_tuned | 10 | 2.614 | 2.509–2.669 | 3.184 | 12.3% | 123.79 | Index Only Scan | 0.041 | 2.654 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | gin | 10 | 79.438 | 19.441–239.480 | 255.661 | 92.4% | 4.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 79.517 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | gist | 10 | 3.832 | 3.725–3.928 | 3.974 | 3.0% | 84.43 | Index Only Scan | 0.037 | 3.881 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | hash (partial) | 10 | 74.394 | 19.943–265.067 | 339.666 | 100.7% | 4.35 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 74.424 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | roaring | 10 | 0.693 | 0.657–0.904 | 0.911 | 16.5% | 467.20 | RoaringCount | 0.040 | 0.738 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | roaring_bitmap | 10 | 135.846 | 21.387–246.861 | 253.331 | 88.6% | 2.38 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 135.893 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c200_17 | seq | 10 | 323.538 | 319.446–326.995 | 338.671 | 2.5% | 1.00 | Seq Scan | 0.041 | 323.578 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | brin | 10 | 577.494 | 565.070–582.766 | 584.650 | 1.8% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.085 | 577.883 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | btree | 10 | 18.720 | 17.958–20.741 | 20.949 | 7.3% | 16.97 | Index Only Scan | 0.051 | 18.823 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | btree_tuned | 10 | 19.517 | 19.347–20.569 | 21.548 | 4.6% | 16.27 | Index Only Scan | 0.048 | 19.559 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | gin | 10 | 518.181 | 470.276–590.599 | 644.120 | 15.4% | 0.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 518.274 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | gist | 10 | 40.425 | 38.230–42.503 | 43.103 | 5.9% | 7.86 | Index Only Scan | 0.053 | 40.490 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | hash (partial) | 10 | 750.514 | 573.132–767.077 | 795.919 | 15.8% | 0.42 | Seq Scan (fallback) | 0.051 | 750.566 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | roaring | 10 | 3.546 | 3.449–3.855 | 4.835 | 18.2% | 89.55 | RoaringCount | 0.036 | 3.596 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | roaring_bitmap | 10 | 417.483 | 388.742–516.401 | 623.558 | 21.7% | 0.76 | Bitmap Heap Scan, Bitmap Index Scan | 0.063 | 417.547 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20_3 | seq | 10 | 317.587 | 312.765–326.028 | 339.272 | 3.5% | 1.00 | Seq Scan | 0.042 | 317.636 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | brin | 10 | 568.783 | 560.843–579.245 | 581.405 | 3.3% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 568.839 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | btree | 10 | 0.048 | 0.043–0.053 | 0.072 | 28.0% | 6727.62 | Index Only Scan | 0.036 | 0.084 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | btree_tuned | 10 | 0.046 | 0.044–0.050 | 0.052 | 7.7% | 6872.30 | Index Only Scan | 0.050 | 0.095 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | gin | 10 | 2.583 | 1.841–2.780 | 3.072 | 29.7% | 123.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 2.655 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | gist | 10 | 0.079 | 0.070–0.116 | 0.186 | 51.0% | 4070.85 | Index Only Scan | 0.040 | 0.115 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | hash (partial) | 10 | 2.305 | 1.026–2.683 | 3.125 | 49.8% | 138.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 2.362 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | roaring | 10 | 0.033 | 0.033–0.038 | 0.045 | 13.9% | 9683.70 | RoaringCount | 0.038 | 0.073 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | roaring_bitmap | 10 | 2.534 | 2.294–2.955 | 3.265 | 23.9% | 126.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 2.588 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c20k_123 | seq | 10 | 319.562 | 316.509–327.517 | 328.630 | 2.0% | 1.00 | Seq Scan | 0.042 | 319.604 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | brin | 10 | 678.178 | 670.058–688.807 | 694.994 | 1.9% | 0.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.080 | 678.247 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | btree | 10 | 174.358 | 170.947–180.161 | 184.455 | 3.5% | 2.36 | Index Only Scan | 0.037 | 174.394 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | btree_tuned | 10 | 176.718 | 171.379–185.675 | 193.786 | 5.4% | 2.33 | Index Only Scan | 0.040 | 176.758 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | gin | 10 | 875.882 | 700.286–956.981 | 1035.985 | 17.1% | 0.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 875.935 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | gist | 10 | 397.226 | 384.838–406.374 | 407.251 | 3.7% | 1.04 | Index Only Scan | 0.038 | 397.262 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | hash (partial) | 10 | 704.971 | 642.620–867.040 | 904.907 | 15.8% | 0.58 | Seq Scan (fallback) | 0.035 | 705.012 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | roaring | 10 | 13.494 | 11.156–15.167 | 16.311 | 16.2% | 30.54 | RoaringCount | 0.040 | 13.537 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | roaring_bitmap | 10 | 654.511 | 512.121–711.091 | 812.448 | 19.2% | 0.63 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 654.571 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_c2_0 | seq | 10 | 412.143 | 406.984–416.907 | 422.946 | 1.7% | 1.00 | Seq Scan | 0.042 | 412.193 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | brin | 10 | 21.938 | 21.116–22.973 | 24.195 | 5.6% | 15.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.169 | 22.258 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | btree | 10 | 1.526 | 1.513–1.574 | 2.222 | 22.8% | 227.61 | Index Only Scan | 0.036 | 1.562 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | btree_tuned | 10 | 1.519 | 1.490–1.556 | 1.793 | 9.2% | 228.58 | Index Only Scan | 0.038 | 1.556 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | gin | 10 | 6.617 | 5.780–7.158 | 7.402 | 17.6% | 52.50 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 6.679 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | gist | 10 | 3.418 | 3.407–3.457 | 3.505 | 1.2% | 101.60 | Index Only Scan | 0.041 | 3.463 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | hash (partial) | 10 | 6.860 | 3.349–7.139 | 7.398 | 34.9% | 50.63 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 6.917 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | roaring | 10 | 0.013 | 0.011–0.015 | 0.019 | 20.7% | 26718.00 | RoaringCount | 0.043 | 0.056 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | roaring_bitmap | 10 | 3.689 | 2.864–4.409 | 4.952 | 26.7% | 94.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 3.737 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_clustered_17 | seq | 10 | 347.334 | 339.140–353.230 | 360.222 | 2.9% | 1.00 | Seq Scan | 0.043 | 347.376 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | brin | 10 | 609.264 | 580.889–617.487 | 641.454 | 4.4% | 0.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 609.344 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | btree | 10 | 2.128 | 1.956–2.213 | 2.251 | 6.1% | 169.06 | Index Only Scan | 0.036 | 2.178 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | btree_tuned | 10 | 2.134 | 2.047–2.279 | 2.404 | 7.2% | 168.58 | Index Only Scan | 0.040 | 2.179 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | gin | 10 | 226.076 | 28.495–241.394 | 243.426 | 70.7% | 1.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 226.128 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | gist | 10 | 3.968 | 3.678–4.128 | 4.239 | 6.8% | 90.68 | Index Only Scan | 0.053 | 4.016 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | hash (partial) | 10 | 232.784 | 142.659–242.990 | 246.505 | 34.2% | 1.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 232.859 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | roaring | 10 | 0.682 | 0.636–0.723 | 1.003 | 24.0% | 527.50 | RoaringCount | 0.039 | 0.721 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | roaring_bitmap | 10 | 232.192 | 122.018–236.074 | 267.114 | 48.8% | 1.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 232.226 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_nullable_17 | seq | 10 | 359.755 | 355.386–364.486 | 370.994 | 1.7% | 1.00 | Seq Scan | 0.042 | 359.798 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | brin | 10 | 791.551 | 779.842–799.443 | 806.322 | 1.7% | 0.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.161 | 791.710 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | btree | 10 | 300.368 | 296.670–304.776 | 314.262 | 2.4% | 1.68 | Index Only Scan | 0.036 | 300.404 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | btree_tuned | 10 | 309.084 | 306.640–311.373 | 320.962 | 2.4% | 1.64 | Index Only Scan | 0.038 | 309.135 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | gin | 10 | 1074.078 | 972.940–1141.093 | 1161.105 | 8.8% | 0.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 1074.519 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | gist | 10 | 728.615 | 719.128–732.466 | 741.109 | 1.5% | 0.69 | Index Only Scan | 0.037 | 728.670 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | hash (partial) | 10 | 897.299 | 751.567–951.532 | 1009.546 | 13.6% | 0.56 | Seq Scan (fallback) | 0.051 | 897.328 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | roaring | 10 | 14.901 | 13.772–16.173 | 17.132 | 10.0% | 33.92 | RoaringCount | 0.037 | 14.950 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | roaring_bitmap | 10 | 856.795 | 685.553–919.919 | 939.053 | 14.9% | 0.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 856.851 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | eq_skew_0 | seq | 10 | 505.502 | 497.681–517.511 | 521.408 | 2.1% | 1.00 | Seq Scan | 0.043 | 505.553 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | brin | 10 | 580.572 | 569.418–592.117 | 594.677 | 2.2% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.080 | 580.674 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | btree | 10 | 16.421 | 14.859–17.570 | 18.045 | 8.6% | 19.87 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 16.476 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | btree_tuned | 10 | 3.244 | 3.144–3.398 | 3.664 | 6.7% | 100.58 | Index Only Scan | 0.045 | 3.288 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | gin | 10 | 77.590 | 20.472–189.688 | 272.054 | 95.3% | 4.21 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 77.661 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | gist | 10 | 122.053 | 15.647–232.547 | 260.354 | 92.4% | 2.67 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 122.129 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | hash (partial) | 10 | 21.588 | 19.639–22.877 | 24.188 | 11.0% | 15.11 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 21.652 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | roaring | 10 | 18.816 | 17.983–19.645 | 20.418 | 5.1% | 17.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 18.874 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | roaring_bitmap | 10 | 20.371 | 17.439–142.235 | 236.812 | 119.2% | 16.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 20.410 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | fetch_medium | seq | 10 | 326.294 | 321.326–334.009 | 334.096 | 2.0% | 1.00 | Seq Scan | 0.043 | 326.340 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | brin | 10 | 732.414 | 721.323–742.773 | 754.108 | 1.8% | 1.00 | Seq Scan (fallback) | 0.058 | 732.474 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | btree | 10 | 440.356 | 433.849–445.723 | 450.190 | 2.0% | 1.67 | Index Only Scan | 0.039 | 440.434 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | btree_tuned | 10 | 448.090 | 441.525–453.658 | 458.582 | 1.7% | 1.64 | Index Only Scan | 0.043 | 448.134 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | gin | 10 | 957.812 | 920.118–1039.453 | 1104.803 | 12.0% | 0.77 | Seq Scan (fallback) | 0.053 | 957.866 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | gist | 10 | 1043.085 | 1032.742–1049.255 | 1091.935 | 2.6% | 0.70 | Index Only Scan | 0.036 | 1043.130 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | hash (partial) | 10 | 1029.115 | 961.927–1212.261 | 1253.024 | 12.2% | 0.71 | Seq Scan (fallback) | 0.052 | 1029.150 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | roaring | 10 | 25.044 | 23.759–26.657 | 27.853 | 6.8% | 29.28 | RoaringCount | 0.036 | 25.080 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | roaring_bitmap | 10 | 957.198 | 853.058–1009.583 | 1061.289 | 12.5% | 0.77 | Seq Scan (fallback) | 0.057 | 957.246 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c2 | seq | 10 | 733.391 | 722.728–749.526 | 754.845 | 2.3% | 1.00 | Seq Scan | 0.043 | 733.434 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | brin | 10 | 837.788 | 827.190–844.587 | 848.855 | 1.4% | 1.01 | Seq Scan (fallback) | 0.061 | 837.851 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | btree | 10 | 528.613 | 520.977–545.663 | 549.025 | 2.5% | 1.60 | Index Only Scan | 0.050 | 528.654 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | btree_tuned | 10 | 618.848 | 611.637–623.424 | 627.802 | 1.7% | 1.37 | Index Only Scan | 0.044 | 618.891 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | gin | 10 | 1103.822 | 1022.516–1248.856 | 1273.673 | 10.3% | 0.77 | Seq Scan (fallback) | 0.050 | 1103.868 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | gist | 10 | 1096.582 | 1089.742–1105.872 | 1121.577 | 1.5% | 0.77 | Index Only Scan | 0.039 | 1096.631 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | hash (partial) | 10 | 1221.917 | 1084.165–1314.491 | 1319.201 | 9.9% | 0.69 | Seq Scan (fallback) | 0.043 | 1221.961 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | roaring | 10 | 148.085 | 139.272–154.811 | 162.941 | 6.6% | 5.72 | RoaringCount | 0.037 | 148.123 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | roaring_bitmap | 10 | 1071.932 | 938.377–1158.644 | 1165.017 | 11.3% | 0.79 | Seq Scan (fallback) | 0.036 | 1071.990 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_c200 | seq | 10 | 846.830 | 832.127–868.079 | 880.026 | 2.7% | 1.00 | Seq Scan | 0.043 | 846.873 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | brin | 10 | 581.337 | 572.352–587.375 | 592.880 | 1.9% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.085 | 581.525 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | btree | 10 | 18.507 | 16.846–19.392 | 20.169 | 10.8% | 17.45 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 18.577 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | btree_tuned | 10 | 3.074 | 2.880–3.206 | 3.288 | 5.6% | 105.07 | Index Only Scan | 0.057 | 3.130 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | gin | 10 | 196.188 | 26.328–270.126 | 275.822 | 66.0% | 1.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.083 | 196.495 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | gist | 10 | 116.007 | 41.877–283.878 | 388.903 | 84.2% | 2.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 116.081 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | hash (partial) | 10 | 21.287 | 17.717–24.331 | 144.623 | 163.1% | 15.17 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 21.352 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | roaring | 10 | 13.835 | 13.590–14.327 | 14.734 | 3.7% | 23.34 | RoaringCount | 0.049 | 13.886 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | roaring_bitmap | 10 | 177.072 | 29.458–257.674 | 262.567 | 74.5% | 1.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.072 | 177.131 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | group_filtered | seq | 10 | 322.947 | 321.606–326.895 | 335.343 | 2.0% | 1.00 | Seq Scan | 0.050 | 322.996 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | brin | 10 | 698.741 | 692.334–707.803 | 711.204 | 1.7% | 0.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.102 | 699.196 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | btree | 10 | 47.879 | 46.194–50.532 | 52.283 | 5.6% | 9.28 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 47.936 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | btree_tuned | 10 | 1.202 | 1.181–1.236 | 1.265 | 3.6% | 369.78 | Index Only Scan | 0.054 | 1.257 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | gin | 10 | 173.709 | 129.832–194.929 | 202.491 | 25.0% | 2.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.084 | 173.782 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | gist | 10 | 159.398 | 85.973–235.464 | 298.011 | 52.7% | 2.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 159.448 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | hash (partial) | 10 | 489.714 | 58.611–568.250 | 611.731 | 60.3% | 0.91 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 489.768 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | roaring | 10 | 10.418 | 10.170–10.751 | 11.023 | 3.6% | 42.66 | RoaringCount | 0.057 | 10.488 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | roaring_bitmap | 10 | 126.021 | 109.537–143.904 | 151.932 | 18.6% | 3.53 | Bitmap Heap Scan, Bitmap Index Scan | 0.075 | 126.097 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_and | seq | 10 | 444.472 | 441.500–453.581 | 611.583 | 19.3% | 1.00 | Seq Scan | 0.051 | 444.524 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | brin | 10 | 400.188 | 393.549–406.027 | 413.139 | 6.5% | 1.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.091 | 400.498 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | btree | 10 | 0.310 | 0.275–0.319 | 0.344 | 9.6% | 1353.79 | Index Only Scan | 0.046 | 0.352 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | btree_tuned | 10 | 0.287 | 0.274–0.305 | 0.324 | 7.5% | 1462.28 | Index Only Scan | 0.048 | 0.339 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | gin | 10 | 30.000 | 27.852–31.147 | 31.554 | 28.2% | 13.99 | Bitmap Heap Scan, Bitmap Index Scan | 0.078 | 30.069 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | gist | 10 | 26.570 | 24.117–44.480 | 50.219 | 48.1% | 15.80 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 26.613 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | hash (partial) | 10 | 25.261 | 4.298–27.415 | 28.638 | 61.6% | 16.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 25.316 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | roaring | 10 | 0.322 | 0.311–0.368 | 0.420 | 13.2% | 1305.37 | RoaringCount | 0.051 | 0.374 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | roaring_bitmap | 10 | 27.253 | 25.379–28.809 | 28.952 | 32.3% | 15.40 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 27.320 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_10 | seq | 10 | 419.675 | 416.991–433.018 | 447.269 | 3.0% | 1.00 | Seq Scan | 0.049 | 419.724 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | brin | 10 | 3998.066 | 3956.026–4036.034 | 4051.490 | 1.1% | 0.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.482 | 3998.589 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | btree | 10 | 24.575 | 23.998–24.897 | 25.867 | 3.8% | 19.03 | Index Only Scan | 0.438 | 25.012 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | btree_tuned | 10 | 24.615 | 24.135–26.098 | 27.262 | 5.4% | 18.99 | Index Only Scan | 0.459 | 25.064 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | gin | 10 | 872.898 | 822.710–1000.161 | 1018.729 | 10.1% | 0.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.682 | 873.624 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | gist | 10 | 514.505 | 429.311–583.605 | 611.095 | 15.5% | 0.91 | Bitmap Heap Scan, Bitmap Index Scan | 0.452 | 514.973 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | hash (partial) | 10 | 565.519 | 511.732–610.534 | 635.287 | 12.5% | 0.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.454 | 566.043 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | roaring | 10 | 68.535 | 66.707–74.149 | 79.678 | 7.5% | 6.82 | RoaringCount | 0.775 | 69.302 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | roaring_bitmap | 10 | 461.502 | 428.536–532.339 | 563.554 | 12.4% | 1.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.453 | 461.981 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | in_c20k_1000 | seq | 10 | 467.534 | 461.281–470.791 | 487.696 | 2.7% | 1.00 | Seq Scan | 0.446 | 467.979 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | brin | 10 | 615.220 | 614.309–620.688 | 625.464 | 2.7% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.195 | 615.372 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | btree | 10 | 38.939 | 37.822–41.430 | 45.430 | 7.8% | 9.55 | Index Only Scan | 0.045 | 38.975 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | btree_tuned | 10 | 39.662 | 38.910–40.779 | 43.722 | 5.1% | 9.38 | Index Only Scan | 0.045 | 39.697 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | gin | 10 | 654.111 | 601.393–739.599 | 813.874 | 14.7% | 0.57 | Seq Scan (fallback) | 0.053 | 654.169 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | gist | 10 | 152.218 | 149.930–155.546 | 158.386 | 2.5% | 2.44 | Index Only Scan | 0.035 | 152.278 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | hash (partial) | 10 | 738.457 | 575.053–856.391 | 897.118 | 19.6% | 0.50 | Seq Scan (fallback) | 0.028 | 738.479 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | roaring | 10 | 5.324 | 4.531–6.708 | 6.994 | 19.6% | 69.86 | RoaringCount | 0.034 | 5.359 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | roaring_bitmap | 10 | 347.430 | 330.018–444.794 | 571.079 | 24.9% | 1.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 347.495 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | is_null | seq | 10 | 371.876 | 370.385–378.155 | 394.198 | 2.9% | 1.00 | Seq Scan | 0.036 | 371.912 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | brin | 10 | 609.186 | 601.088–623.862 | 624.865 | 2.1% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.084 | 609.270 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | btree | 10 | 2.441 | 2.387–2.793 | 3.113 | 12.4% | 149.42 | Index Only Scan | 0.069 | 2.519 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | btree_tuned | 10 | 2.627 | 2.422–2.716 | 2.808 | 6.6% | 138.84 | Index Only Scan | 0.066 | 2.720 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | gin | 10 | 416.344 | 193.639–455.525 | 473.731 | 37.6% | 0.88 | Bitmap Heap Scan, Bitmap Index Scan | 0.076 | 416.591 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | gist | 10 | 4.681 | 4.248–4.962 | 5.614 | 11.6% | 77.92 | Index Only Scan | 0.067 | 4.736 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | hash (partial) | 10 | 794.080 | 616.478–852.058 | 898.181 | 17.2% | 0.46 | Seq Scan (fallback) | 0.045 | 794.125 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | roaring | 10 | 661.793 | 640.685–675.733 | 679.379 | 3.1% | 0.55 | Seq Scan (fallback) | 0.038 | 661.867 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | roaring_bitmap | 10 | 552.201 | 482.331–660.416 | 696.828 | 19.7% | 0.66 | Seq Scan (fallback) | 0.062 | 552.255 |
| scalar | 5000000 | dirty_clustered_5pct | prefer_index | 64MB | range_random | seq | 10 | 364.732 | 361.016–376.457 | 413.347 | 6.6% | 1.00 | Seq Scan | 0.047 | 364.778 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and2 | brin | 10 | 568.648 | 564.387–578.885 | 592.607 | 2.1% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.202 | 568.923 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and2 | btree | 10 | 111.412 | 19.727–236.790 | 240.124 | 83.0% | 2.93 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 111.470 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and2 | btree_tuned | 10 | 8.694 | 4.718–12.290 | 12.985 | 46.1% | 37.53 | Index Only Scan | 0.067 | 8.761 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and2 | gin | 10 | 285.707 | 182.963–319.225 | 343.215 | 26.1% | 1.14 | Bitmap Heap Scan, Bitmap Index Scan | 0.084 | 285.778 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and2 | gist | 10 | 19.994 | 17.024–205.994 | 212.976 | 105.1% | 16.32 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 20.054 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and2 | hash (partial) | 10 | 25.154 | 18.830–136.721 | 244.612 | 124.3% | 12.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 25.222 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and2 | roaring | 10 | 4.270 | 3.892–5.534 | 6.159 | 26.9% | 76.42 | RoaringCount | 0.052 | 4.331 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and2 | roaring_bitmap | 10 | 106.227 | 45.127–157.187 | 161.515 | 56.0% | 3.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 106.282 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and2 | seq | 10 | 326.293 | 317.244–394.995 | 627.724 | 37.4% | 1.00 | Seq Scan | 0.046 | 326.340 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and3 | brin | 10 | 566.199 | 554.666–571.095 | 580.757 | 2.8% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.094 | 566.534 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and3 | btree | 10 | 16.730 | 15.718–17.969 | 22.385 | 19.2% | 18.87 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 16.850 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and3 | btree_tuned | 10 | 0.257 | 0.215–0.596 | 0.791 | 61.2% | 1230.99 | Index Only Scan | 0.061 | 0.314 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and3 | gin | 10 | 29.017 | 27.570–31.166 | 33.853 | 8.8% | 10.88 | Bitmap Heap Scan, Bitmap Index Scan | 0.085 | 29.116 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and3 | gist | 10 | 30.335 | 21.509–33.846 | 38.685 | 26.0% | 10.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 30.383 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and3 | hash (partial) | 10 | 23.776 | 20.331–144.757 | 274.688 | 128.0% | 13.28 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 23.840 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and3 | roaring | 10 | 3.458 | 2.488–3.725 | 3.985 | 31.6% | 91.31 | RoaringCount | 0.082 | 3.525 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and3 | roaring_bitmap | 10 | 19.096 | 12.329–26.476 | 29.990 | 37.1% | 16.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 19.170 |
| scalar | 5000000 | dirty_scattered | default | 64MB | and3 | seq | 10 | 315.748 | 311.876–444.721 | 677.011 | 40.3% | 1.00 | Seq Scan | 0.048 | 315.796 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | brin | 10 | 584.942 | 576.506–588.605 | 596.579 | 2.4% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.072 | 585.031 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | btree | 10 | 0.042 | 0.035–0.047 | 0.309 | 171.0% | 7919.90 | Index Only Scan | 0.062 | 0.104 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | btree_tuned | 10 | 0.041 | 0.037–0.050 | 0.054 | 19.7% | 8213.23 | Index Only Scan | 0.068 | 0.104 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | gin | 10 | 0.808 | 0.756–0.859 | 0.885 | 13.3% | 411.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 0.894 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | gist | 10 | 0.055 | 0.048–0.081 | 0.331 | 142.2% | 6047.93 | Index Only Scan | 0.052 | 0.116 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | hash (partial) | 10 | 0.048 | 0.024–0.293 | 0.520 | 116.1% | 6929.92 | Index Scan | 0.037 | 0.080 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | roaring | 10 | 0.026 | 0.022–0.117 | 0.356 | 168.3% | 13044.55 | RoaringCount | 0.041 | 0.065 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | roaring_bitmap | 10 | 0.336 | 0.134–0.488 | 0.826 | 81.9% | 991.46 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 0.385 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c1m_12345 | seq | 10 | 332.636 | 326.326–391.675 | 597.070 | 32.9% | 1.00 | Seq Scan | 0.041 | 332.677 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c200_17 | brin | 10 | 573.048 | 533.323–582.922 | 592.202 | 5.2% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 573.114 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c200_17 | btree | 10 | 2.435 | 2.054–3.374 | 4.467 | 35.6% | 131.03 | Index Only Scan | 0.055 | 2.500 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c200_17 | btree_tuned | 10 | 16.188 | 13.019–21.823 | 24.116 | 30.8% | 19.71 | Index Only Scan | 0.043 | 16.232 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c200_17 | gin | 10 | 64.061 | 24.197–215.212 | 245.274 | 92.1% | 4.98 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 64.100 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c200_17 | gist | 10 | 3.929 | 3.719–4.289 | 5.565 | 20.0% | 81.22 | Index Only Scan | 0.061 | 3.963 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c200_17 | hash (partial) | 10 | 20.147 | 19.642–77.674 | 183.165 | 137.1% | 15.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 20.194 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c200_17 | roaring | 10 | 1.325 | 0.699–3.182 | 3.635 | 71.3% | 240.89 | RoaringCount | 0.071 | 1.396 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c200_17 | roaring_bitmap | 10 | 72.153 | 24.001–242.719 | 246.447 | 89.8% | 4.42 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 72.203 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c200_17 | seq | 10 | 319.062 | 313.706–433.709 | 687.145 | 41.5% | 1.00 | Seq Scan | 0.043 | 319.104 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20_3 | brin | 10 | 320.982 | 316.848–326.157 | 339.319 | 3.1% | 1.00 | Seq Scan (fallback) | 0.073 | 321.168 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20_3 | btree | 10 | 474.132 | 397.667–582.003 | 634.924 | 20.6% | 0.68 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 474.179 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20_3 | btree_tuned | 10 | 528.045 | 439.436–755.335 | 1007.163 | 39.9% | 0.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 528.095 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20_3 | gin | 10 | 549.769 | 473.475–612.647 | 662.053 | 17.3% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 549.821 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20_3 | gist | 10 | 393.697 | 384.892–518.396 | 609.733 | 22.0% | 0.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.048 | 393.745 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20_3 | hash (partial) | 10 | 831.005 | 704.685–845.648 | 864.236 | 13.4% | 0.39 | Seq Scan (fallback) | 0.031 | 831.034 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20_3 | roaring | 10 | 398.706 | 383.020–420.353 | 454.070 | 7.5% | 0.81 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 398.744 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20_3 | roaring_bitmap | 10 | 504.614 | 403.701–563.167 | 579.417 | 16.4% | 0.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 504.679 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20_3 | seq | 10 | 321.371 | 314.175–497.862 | 700.590 | 40.7% | 1.00 | Seq Scan | 0.042 | 321.414 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20k_123 | brin | 10 | 576.132 | 573.163–586.668 | 591.390 | 1.4% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 576.219 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20k_123 | btree | 10 | 0.073 | 0.052–0.082 | 0.101 | 30.7% | 4479.26 | Index Only Scan | 0.066 | 0.137 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20k_123 | btree_tuned | 10 | 0.251 | 0.203–0.730 | 0.772 | 71.1% | 1296.39 | Index Only Scan | 0.068 | 0.296 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20k_123 | gin | 10 | 2.282 | 0.671–2.634 | 3.360 | 52.6% | 142.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.072 | 2.321 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20k_123 | gist | 10 | 0.094 | 0.085–0.102 | 0.361 | 109.7% | 3454.74 | Index Only Scan | 0.049 | 0.145 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20k_123 | hash (partial) | 10 | 2.613 | 1.563–3.107 | 3.143 | 37.5% | 124.28 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 2.644 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20k_123 | roaring | 10 | 0.058 | 0.037–0.181 | 0.464 | 136.8% | 5599.07 | RoaringCount | 0.039 | 0.096 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20k_123 | roaring_bitmap | 10 | 2.369 | 1.236–2.540 | 2.622 | 47.6% | 137.08 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 2.420 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c20k_123 | seq | 10 | 324.746 | 319.041–455.487 | 683.517 | 39.2% | 1.00 | Seq Scan | 0.042 | 324.795 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c2_0 | brin | 10 | 415.159 | 413.311–425.631 | 430.834 | 2.4% | 0.99 | Seq Scan (fallback) | 0.075 | 415.491 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c2_0 | btree | 10 | 549.602 | 530.280–697.582 | 722.504 | 14.5% | 0.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 549.667 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c2_0 | btree_tuned | 10 | 728.374 | 539.765–1382.759 | 1417.680 | 43.9% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 728.413 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c2_0 | gin | 10 | 786.759 | 664.412–966.963 | 984.100 | 17.7% | 0.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.072 | 786.820 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c2_0 | gist | 10 | 548.176 | 404.726–602.228 | 646.427 | 19.9% | 0.75 | Seq Scan (fallback) | 0.046 | 548.207 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c2_0 | hash (partial) | 10 | 872.558 | 642.032–919.195 | 943.174 | 16.8% | 0.47 | Seq Scan (fallback) | 0.052 | 872.601 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c2_0 | roaring | 10 | 522.885 | 513.048–539.909 | 614.097 | 8.8% | 0.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 522.939 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c2_0 | roaring_bitmap | 10 | 668.373 | 580.489–734.027 | 788.010 | 14.3% | 0.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 668.419 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_c2_0 | seq | 10 | 409.870 | 405.331–570.840 | 796.115 | 33.4% | 1.00 | Seq Scan | 0.043 | 409.913 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_clustered_17 | brin | 10 | 21.745 | 20.876–22.586 | 25.111 | 7.9% | 16.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.189 | 22.206 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_clustered_17 | btree | 10 | 1.566 | 1.542–1.634 | 1.882 | 9.4% | 223.79 | Index Only Scan | 0.038 | 1.632 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_clustered_17 | btree_tuned | 10 | 2.727 | 2.426–2.904 | 3.126 | 12.4% | 128.51 | Index Only Scan | 0.055 | 2.782 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_clustered_17 | gin | 10 | 6.256 | 4.582–6.832 | 8.006 | 25.1% | 56.01 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 6.319 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_clustered_17 | gist | 10 | 3.529 | 3.328–3.901 | 4.228 | 10.5% | 99.31 | Index Only Scan | 0.046 | 3.580 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_clustered_17 | hash (partial) | 10 | 6.524 | 3.597–6.691 | 6.978 | 30.0% | 53.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 6.577 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_clustered_17 | roaring | 10 | 0.019 | 0.012–0.025 | 0.027 | 34.1% | 18445.00 | RoaringCount | 0.045 | 0.063 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_clustered_17 | roaring_bitmap | 10 | 4.491 | 3.482–5.642 | 6.282 | 29.4% | 78.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 4.541 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_clustered_17 | seq | 10 | 350.455 | 342.495–482.889 | 712.000 | 36.7% | 1.00 | Seq Scan | 0.043 | 350.497 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_nullable_17 | brin | 10 | 363.554 | 357.767–372.668 | 378.531 | 2.4% | 1.02 | Seq Scan (fallback) | 0.072 | 363.624 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_nullable_17 | btree | 10 | 2.093 | 1.855–3.493 | 4.346 | 40.1% | 176.41 | Index Only Scan | 0.053 | 2.158 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_nullable_17 | btree_tuned | 10 | 19.267 | 7.843–20.968 | 21.756 | 38.9% | 19.16 | Index Only Scan | 0.070 | 19.345 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_nullable_17 | gin | 10 | 229.072 | 220.690–235.855 | 236.199 | 32.3% | 1.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 229.118 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_nullable_17 | gist | 10 | 3.941 | 3.510–3.990 | 4.238 | 10.2% | 93.69 | Index Only Scan | 0.039 | 3.998 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_nullable_17 | hash (partial) | 10 | 229.560 | 89.397–244.707 | 259.088 | 55.7% | 1.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 229.594 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_nullable_17 | roaring | 10 | 2.551 | 0.848–3.040 | 3.277 | 50.1% | 144.74 | RoaringCount | 0.068 | 2.590 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_nullable_17 | roaring_bitmap | 10 | 228.290 | 173.463–239.664 | 240.470 | 36.2% | 1.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 228.339 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_nullable_17 | seq | 10 | 369.234 | 363.024–481.426 | 719.335 | 35.7% | 1.00 | Seq Scan | 0.042 | 369.277 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_skew_0 | brin | 10 | 507.277 | 491.832–519.522 | 539.125 | 3.6% | 0.99 | Seq Scan (fallback) | 0.075 | 507.361 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_skew_0 | btree | 10 | 666.997 | 636.600–708.453 | 732.815 | 12.4% | 0.75 | Seq Scan (fallback) | 0.045 | 667.048 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_skew_0 | btree_tuned | 10 | 751.385 | 656.907–820.298 | 869.077 | 14.5% | 0.67 | Seq Scan (fallback) | 0.042 | 751.424 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_skew_0 | gin | 10 | 759.546 | 682.122–825.327 | 847.448 | 11.6% | 0.66 | Seq Scan (fallback) | 0.073 | 759.623 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_skew_0 | gist | 10 | 596.733 | 516.829–648.375 | 717.234 | 14.3% | 0.84 | Seq Scan (fallback) | 0.040 | 596.773 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_skew_0 | hash (partial) | 10 | 844.728 | 786.935–995.228 | 1042.829 | 13.2% | 0.59 | Seq Scan (fallback) | 0.041 | 844.767 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_skew_0 | roaring | 10 | 651.253 | 631.548–697.743 | 749.652 | 7.4% | 0.77 | Seq Scan (fallback) | 0.069 | 651.324 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_skew_0 | roaring_bitmap | 10 | 700.504 | 585.959–835.272 | 886.400 | 19.3% | 0.72 | Seq Scan (fallback) | 0.054 | 700.563 |
| scalar | 5000000 | dirty_scattered | default | 64MB | eq_skew_0 | seq | 10 | 501.154 | 491.895–584.338 | 830.937 | 26.9% | 1.00 | Seq Scan | 0.043 | 501.196 |
| scalar | 5000000 | dirty_scattered | default | 64MB | fetch_medium | brin | 10 | 565.979 | 554.637–570.406 | 602.527 | 4.0% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.081 | 566.058 |
| scalar | 5000000 | dirty_scattered | default | 64MB | fetch_medium | btree | 10 | 117.585 | 16.108–244.415 | 267.726 | 92.2% | 2.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 117.624 |
| scalar | 5000000 | dirty_scattered | default | 64MB | fetch_medium | btree_tuned | 10 | 11.561 | 8.444–20.869 | 23.882 | 44.4% | 28.28 | Index Only Scan | 0.063 | 11.639 |
| scalar | 5000000 | dirty_scattered | default | 64MB | fetch_medium | gin | 10 | 206.673 | 22.488–257.909 | 261.228 | 74.6% | 1.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 206.766 |
| scalar | 5000000 | dirty_scattered | default | 64MB | fetch_medium | gist | 10 | 207.038 | 37.205–212.633 | 216.164 | 58.3% | 1.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 207.105 |
| scalar | 5000000 | dirty_scattered | default | 64MB | fetch_medium | hash (partial) | 10 | 20.669 | 19.572–22.795 | 33.494 | 28.6% | 15.81 | Bitmap Heap Scan, Bitmap Index Scan | 0.044 | 20.709 |
| scalar | 5000000 | dirty_scattered | default | 64MB | fetch_medium | roaring | 10 | 250.079 | 236.337–256.682 | 266.880 | 32.1% | 1.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 250.147 |
| scalar | 5000000 | dirty_scattered | default | 64MB | fetch_medium | roaring_bitmap | 10 | 212.912 | 26.042–258.024 | 278.130 | 62.6% | 1.54 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 212.966 |
| scalar | 5000000 | dirty_scattered | default | 64MB | fetch_medium | seq | 10 | 326.877 | 319.120–474.342 | 709.568 | 41.2% | 1.00 | Seq Scan | 0.045 | 326.923 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c2 | brin | 10 | 724.752 | 714.255–733.717 | 753.647 | 2.4% | 1.01 | Seq Scan (fallback) | 0.060 | 724.812 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c2 | btree | 10 | 865.091 | 740.458–946.402 | 959.043 | 11.1% | 0.85 | Seq Scan (fallback) | 0.055 | 865.159 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c2 | btree_tuned | 10 | 923.780 | 861.257–1005.794 | 1349.791 | 22.8% | 0.79 | Seq Scan (fallback) | 0.048 | 923.856 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c2 | gin | 10 | 939.886 | 918.494–1014.530 | 1120.386 | 9.9% | 0.78 | Seq Scan (fallback) | 0.039 | 939.919 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c2 | gist | 10 | 835.179 | 787.898–903.033 | 943.562 | 9.9% | 0.88 | Seq Scan (fallback) | 0.060 | 835.234 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c2 | hash (partial) | 10 | 1189.653 | 928.015–1251.881 | 1264.805 | 14.5% | 0.62 | Seq Scan (fallback) | 0.040 | 1189.687 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c2 | roaring | 10 | 875.507 | 736.749–900.263 | 902.767 | 9.8% | 0.84 | Seq Scan (fallback) | 0.066 | 875.572 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c2 | roaring_bitmap | 10 | 919.433 | 873.688–990.027 | 1134.435 | 12.4% | 0.80 | Seq Scan (fallback) | 0.051 | 919.479 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c2 | seq | 10 | 732.083 | 720.640–881.742 | 1040.016 | 16.7% | 1.00 | Seq Scan | 0.043 | 732.126 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c200 | brin | 10 | 842.337 | 834.373–854.952 | 864.705 | 1.5% | 1.00 | Seq Scan (fallback) | 0.061 | 842.398 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c200 | btree | 10 | 1015.885 | 967.070–1090.346 | 1148.970 | 9.0% | 0.83 | Seq Scan (fallback) | 0.051 | 1015.952 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c200 | btree_tuned | 10 | 1218.251 | 1108.442–1581.422 | 1965.799 | 27.2% | 0.69 | Seq Scan (fallback) | 0.051 | 1218.307 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c200 | gin | 10 | 1125.695 | 1001.744–1213.915 | 1296.047 | 13.2% | 0.75 | Seq Scan (fallback) | 0.059 | 1125.753 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c200 | gist | 10 | 933.752 | 811.671–959.676 | 1004.930 | 9.0% | 0.91 | Seq Scan (fallback) | 0.057 | 933.809 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c200 | hash (partial) | 10 | 1305.455 | 1093.208–1387.044 | 1408.457 | 13.1% | 0.65 | Seq Scan (fallback) | 0.037 | 1305.499 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c200 | roaring | 10 | 892.878 | 855.946–1025.624 | 1087.407 | 10.1% | 0.95 | Seq Scan (fallback) | 0.056 | 892.924 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c200 | roaring_bitmap | 10 | 1052.287 | 995.288–1107.758 | 1176.035 | 7.6% | 0.80 | Seq Scan (fallback) | 0.056 | 1052.343 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_c200 | seq | 10 | 845.372 | 838.660–1011.573 | 1254.816 | 18.8% | 1.00 | Seq Scan | 0.044 | 845.432 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_filtered | brin | 10 | 581.801 | 579.208–588.559 | 599.928 | 1.5% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.082 | 582.061 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_filtered | btree | 10 | 246.811 | 22.498–253.377 | 268.036 | 61.1% | 1.33 | Bitmap Heap Scan, Bitmap Index Scan | 0.081 | 246.876 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_filtered | btree_tuned | 10 | 15.966 | 9.496–21.549 | 24.526 | 40.7% | 20.59 | Index Only Scan | 0.086 | 16.040 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_filtered | gin | 10 | 94.194 | 23.416–212.160 | 248.643 | 84.2% | 3.49 | Bitmap Heap Scan, Bitmap Index Scan | 0.078 | 94.272 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_filtered | gist | 10 | 209.791 | 19.559–217.874 | 219.642 | 65.3% | 1.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.050 | 209.839 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_filtered | hash (partial) | 10 | 22.232 | 20.712–23.029 | 183.459 | 128.0% | 14.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 22.286 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_filtered | roaring | 10 | 18.548 | 16.841–18.928 | 19.940 | 7.5% | 17.72 | RoaringCount | 0.049 | 18.594 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_filtered | roaring_bitmap | 10 | 245.226 | 27.197–262.405 | 311.989 | 64.5% | 1.34 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 245.331 |
| scalar | 5000000 | dirty_scattered | default | 64MB | group_filtered | seq | 10 | 328.752 | 321.287–460.640 | 694.198 | 39.5% | 1.00 | Seq Scan | 0.051 | 328.817 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_and | brin | 10 | 448.525 | 438.415–455.431 | 462.661 | 2.9% | 0.97 | Seq Scan (fallback) | 0.097 | 448.846 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_and | btree | 10 | 147.148 | 133.163–168.527 | 184.260 | 14.6% | 2.96 | Bitmap Heap Scan, Bitmap Index Scan | 0.065 | 147.213 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_and | btree_tuned | 10 | 10.987 | 9.427–12.146 | 13.602 | 29.5% | 39.60 | Index Only Scan | 0.071 | 11.072 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_and | gin | 10 | 177.589 | 171.207–192.514 | 200.192 | 7.2% | 2.45 | Bitmap Heap Scan, Bitmap Index Scan | 0.090 | 177.678 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_and | gist | 10 | 149.674 | 142.572–165.075 | 176.181 | 22.5% | 2.91 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 149.736 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_and | hash (partial) | 10 | 511.294 | 206.675–584.514 | 589.057 | 47.0% | 0.85 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 511.346 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_and | roaring | 10 | 12.200 | 10.443–12.730 | 13.072 | 10.1% | 35.66 | RoaringCount | 0.084 | 12.271 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_and | roaring_bitmap | 10 | 145.969 | 125.133–147.524 | 153.390 | 9.5% | 2.98 | Bitmap Heap Scan, Bitmap Index Scan | 0.082 | 146.047 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_and | seq | 10 | 435.032 | 430.860–575.444 | 800.476 | 30.9% | 1.00 | Seq Scan | 0.051 | 435.082 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_10 | brin | 10 | 404.610 | 399.103–412.329 | 435.165 | 4.0% | 1.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.081 | 404.686 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_10 | btree | 10 | 0.318 | 0.280–0.580 | 0.639 | 39.7% | 1335.53 | Index Only Scan | 0.070 | 0.390 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_10 | btree_tuned | 10 | 2.500 | 1.945–2.682 | 2.870 | 21.2% | 169.61 | Index Only Scan | 0.053 | 2.546 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_10 | gin | 10 | 29.640 | 5.738–31.005 | 32.746 | 52.9% | 14.31 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 29.732 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_10 | gist | 10 | 24.984 | 1.871–26.354 | 27.025 | 76.3% | 16.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 25.049 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_10 | hash (partial) | 10 | 26.186 | 2.865–28.018 | 28.392 | 73.8% | 16.19 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 26.238 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_10 | roaring | 10 | 0.565 | 0.399–0.607 | 0.684 | 21.5% | 751.16 | RoaringCount | 0.062 | 0.614 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_10 | roaring_bitmap | 10 | 27.750 | 27.389–28.101 | 29.273 | 28.9% | 15.28 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 27.826 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_10 | seq | 10 | 424.032 | 420.135–556.541 | 788.020 | 31.4% | 1.00 | Seq Scan | 0.050 | 424.081 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_1000 | brin | 10 | 460.607 | 453.147–470.281 | 481.694 | 2.7% | 1.02 | Seq Scan (fallback) | 0.477 | 461.228 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_1000 | btree | 10 | 431.767 | 407.596–561.672 | 689.887 | 23.8% | 1.09 | Bitmap Heap Scan, Bitmap Index Scan | 0.449 | 432.237 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_1000 | btree_tuned | 10 | 446.913 | 385.164–718.567 | 938.639 | 42.1% | 1.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.479 | 447.480 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_1000 | gin | 10 | 896.795 | 802.246–989.452 | 996.321 | 9.6% | 0.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.625 | 897.639 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_1000 | gist | 10 | 446.282 | 403.024–531.931 | 547.022 | 13.8% | 1.05 | Bitmap Heap Scan, Bitmap Index Scan | 0.472 | 446.721 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_1000 | hash (partial) | 10 | 524.041 | 498.831–590.496 | 694.953 | 15.2% | 0.90 | Bitmap Heap Scan, Bitmap Index Scan | 0.458 | 524.541 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_1000 | roaring | 10 | 411.590 | 393.451–421.873 | 583.477 | 17.7% | 1.14 | Bitmap Heap Scan, Bitmap Index Scan | 0.800 | 412.362 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_1000 | roaring_bitmap | 10 | 502.984 | 411.822–573.271 | 623.136 | 17.3% | 0.93 | Bitmap Heap Scan, Bitmap Index Scan | 0.455 | 503.464 |
| scalar | 5000000 | dirty_scattered | default | 64MB | in_c20k_1000 | seq | 10 | 469.738 | 463.865–516.111 | 759.070 | 27.4% | 1.00 | Seq Scan | 0.448 | 470.193 |
| scalar | 5000000 | dirty_scattered | default | 64MB | is_null | brin | 10 | 378.695 | 369.374–385.748 | 405.051 | 4.0% | 0.98 | Seq Scan (fallback) | 0.070 | 378.769 |
| scalar | 5000000 | dirty_scattered | default | 64MB | is_null | btree | 10 | 467.785 | 366.069–555.098 | 608.451 | 22.0% | 0.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 467.843 |
| scalar | 5000000 | dirty_scattered | default | 64MB | is_null | btree_tuned | 10 | 472.457 | 356.495–560.260 | 886.001 | 44.0% | 0.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.037 | 472.498 |
| scalar | 5000000 | dirty_scattered | default | 64MB | is_null | gin | 10 | 655.554 | 602.327–682.499 | 773.915 | 14.6% | 0.56 | Seq Scan (fallback) | 0.047 | 655.600 |
| scalar | 5000000 | dirty_scattered | default | 64MB | is_null | gist | 10 | 464.870 | 452.754–521.746 | 554.977 | 8.9% | 0.80 | Bitmap Heap Scan, Bitmap Index Scan | 0.032 | 464.913 |
| scalar | 5000000 | dirty_scattered | default | 64MB | is_null | hash (partial) | 10 | 831.005 | 602.644–886.042 | 902.712 | 18.4% | 0.45 | Seq Scan (fallback) | 0.045 | 831.041 |
| scalar | 5000000 | dirty_scattered | default | 64MB | is_null | roaring | 10 | 361.108 | 348.852–368.384 | 509.275 | 22.2% | 1.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 361.157 |
| scalar | 5000000 | dirty_scattered | default | 64MB | is_null | roaring_bitmap | 10 | 360.364 | 346.511–483.059 | 499.304 | 17.1% | 1.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 360.409 |
| scalar | 5000000 | dirty_scattered | default | 64MB | is_null | seq | 10 | 369.899 | 363.215–549.434 | 786.127 | 38.5% | 1.00 | Seq Scan | 0.036 | 369.935 |
| scalar | 5000000 | dirty_scattered | default | 64MB | range_random | brin | 10 | 362.093 | 353.163–367.730 | 370.307 | 2.2% | 0.99 | Seq Scan (fallback) | 0.077 | 362.166 |
| scalar | 5000000 | dirty_scattered | default | 64MB | range_random | btree | 10 | 2.652 | 2.419–4.634 | 5.009 | 36.3% | 135.54 | Index Only Scan | 0.111 | 2.928 |
| scalar | 5000000 | dirty_scattered | default | 64MB | range_random | btree_tuned | 10 | 21.601 | 15.951–23.748 | 25.538 | 29.4% | 16.64 | Index Only Scan | 0.092 | 21.681 |
| scalar | 5000000 | dirty_scattered | default | 64MB | range_random | gin | 10 | 445.031 | 407.126–471.650 | 477.803 | 16.8% | 0.81 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 445.220 |
| scalar | 5000000 | dirty_scattered | default | 64MB | range_random | gist | 10 | 4.897 | 4.810–5.059 | 5.291 | 3.9% | 73.40 | Index Only Scan | 0.061 | 4.954 |
| scalar | 5000000 | dirty_scattered | default | 64MB | range_random | hash (partial) | 10 | 731.024 | 566.537–834.841 | 891.621 | 19.9% | 0.49 | Seq Scan (fallback) | 0.037 | 731.058 |
| scalar | 5000000 | dirty_scattered | default | 64MB | range_random | roaring | 10 | 500.936 | 422.367–539.315 | 554.561 | 12.1% | 0.72 | Seq Scan (fallback) | 0.040 | 500.973 |
| scalar | 5000000 | dirty_scattered | default | 64MB | range_random | roaring_bitmap | 10 | 538.804 | 496.120–626.130 | 685.273 | 17.3% | 0.67 | Seq Scan (fallback) | 0.063 | 538.869 |
| scalar | 5000000 | dirty_scattered | default | 64MB | range_random | seq | 10 | 359.440 | 354.353–513.583 | 745.643 | 37.8% | 1.00 | Seq Scan | 0.046 | 359.486 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and2 | brin | 10 | 567.888 | 562.951–573.193 | 586.335 | 1.9% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.085 | 568.199 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and2 | btree | 10 | 21.001 | 15.111–230.708 | 244.555 | 108.3% | 15.45 | Bitmap Heap Scan, Bitmap Index Scan | 0.043 | 21.066 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and2 | btree_tuned | 10 | 9.104 | 3.675–11.747 | 12.817 | 47.8% | 35.63 | Index Only Scan | 0.068 | 9.170 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and2 | gin | 10 | 187.143 | 185.016–305.651 | 322.474 | 28.3% | 1.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 187.203 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and2 | gist | 10 | 205.843 | 18.056–207.748 | 209.106 | 75.3% | 1.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 205.900 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and2 | hash (partial) | 10 | 19.817 | 17.022–51.808 | 174.799 | 152.4% | 16.37 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 19.870 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and2 | roaring | 10 | 4.130 | 3.148–5.284 | 6.096 | 32.5% | 78.55 | RoaringCount | 0.075 | 4.189 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and2 | roaring_bitmap | 10 | 49.263 | 40.233–160.849 | 180.775 | 75.4% | 6.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 49.317 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and2 | seq | 10 | 324.383 | 318.698–476.248 | 715.522 | 41.9% | 1.00 | Seq Scan | 0.046 | 324.430 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and3 | brin | 10 | 571.161 | 560.263–577.623 | 583.469 | 2.9% | 0.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.203 | 571.484 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and3 | btree | 10 | 16.267 | 13.089–23.235 | 30.593 | 36.8% | 19.73 | Bitmap Heap Scan, Bitmap Index Scan | 0.051 | 16.330 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and3 | btree_tuned | 10 | 0.228 | 0.191–0.432 | 0.731 | 68.2% | 1404.60 | Index Only Scan | 0.054 | 0.299 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and3 | gin | 10 | 35.373 | 32.502–42.368 | 45.219 | 15.6% | 9.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 35.436 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and3 | gist | 10 | 35.188 | 27.917–37.781 | 39.648 | 22.0% | 9.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 35.267 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and3 | hash (partial) | 10 | 18.950 | 17.406–89.826 | 170.291 | 132.4% | 16.94 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 19.018 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and3 | roaring | 10 | 3.468 | 1.864–3.936 | 4.070 | 36.5% | 92.55 | RoaringCount | 0.069 | 3.521 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and3 | roaring_bitmap | 10 | 19.198 | 12.831–27.131 | 31.633 | 40.4% | 16.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 19.259 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | and3 | seq | 10 | 320.951 | 312.460–430.197 | 661.505 | 39.1% | 1.00 | Seq Scan | 0.050 | 320.999 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | brin | 10 | 572.786 | 555.640–581.239 | 596.679 | 3.3% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.078 | 572.860 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | btree | 10 | 0.040 | 0.036–0.053 | 0.101 | 64.7% | 8652.91 | Index Only Scan | 0.062 | 0.102 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | btree_tuned | 10 | 0.042 | 0.039–0.052 | 0.059 | 26.9% | 8240.87 | Index Only Scan | 0.038 | 0.086 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | gin | 10 | 0.736 | 0.470–0.802 | 0.823 | 24.6% | 469.95 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 0.794 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | gist | 10 | 0.048 | 0.046–0.061 | 0.075 | 26.6% | 7210.76 | Index Only Scan | 0.034 | 0.082 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | hash (partial) | 10 | 0.171 | 0.040–0.424 | 0.540 | 88.6% | 2024.07 | Index Scan | 0.056 | 0.216 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | roaring | 10 | 0.021 | 0.021–0.026 | 0.034 | 29.9% | 16098.44 | RoaringCount | 0.038 | 0.060 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | roaring_bitmap | 10 | 0.350 | 0.311–0.453 | 0.592 | 43.7% | 988.90 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 0.401 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c1m_12345 | seq | 10 | 346.116 | 332.007–388.198 | 618.973 | 34.5% | 1.00 | Seq Scan | 0.042 | 346.158 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | brin | 10 | 571.918 | 559.987–586.414 | 591.225 | 2.6% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 571.986 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | btree | 10 | 2.131 | 1.984–2.521 | 3.350 | 25.1% | 148.02 | Index Only Scan | 0.055 | 2.196 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | btree_tuned | 10 | 10.413 | 9.229–15.909 | 22.021 | 42.7% | 30.30 | Index Only Scan | 0.044 | 10.480 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | gin | 10 | 39.965 | 19.116–171.937 | 228.956 | 98.1% | 7.89 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 40.052 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | gist | 10 | 3.764 | 3.499–4.314 | 4.324 | 9.4% | 83.82 | Index Only Scan | 0.050 | 3.798 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | hash (partial) | 10 | 21.668 | 19.126–135.861 | 271.172 | 149.3% | 14.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 21.738 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | roaring | 10 | 0.700 | 0.595–2.066 | 3.344 | 85.9% | 451.04 | RoaringCount | 0.042 | 0.738 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | roaring_bitmap | 10 | 23.349 | 17.891–238.266 | 262.305 | 107.1% | 13.51 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 23.383 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c200_17 | seq | 10 | 315.501 | 314.397–469.554 | 704.738 | 41.8% | 1.00 | Seq Scan | 0.042 | 315.543 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | brin | 10 | 578.551 | 562.224–593.853 | 607.447 | 3.1% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.075 | 578.629 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | btree | 10 | 456.890 | 399.463–599.985 | 662.024 | 23.1% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 456.961 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | btree_tuned | 10 | 459.707 | 400.805–633.400 | 961.739 | 42.7% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 459.776 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | gin | 10 | 496.982 | 437.264–530.040 | 597.232 | 15.0% | 0.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 497.304 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | gist | 10 | 388.960 | 380.677–465.684 | 469.319 | 9.9% | 0.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 389.043 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | hash (partial) | 10 | 793.958 | 523.964–849.528 | 876.711 | 23.3% | 0.40 | Seq Scan (fallback) | 0.053 | 794.007 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | roaring | 10 | 390.447 | 382.316–456.746 | 533.308 | 14.9% | 0.82 | Bitmap Heap Scan, Bitmap Index Scan | 0.041 | 390.500 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | roaring_bitmap | 10 | 458.466 | 394.813–498.501 | 567.006 | 15.7% | 0.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.040 | 458.533 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20_3 | seq | 10 | 320.034 | 316.445–392.060 | 633.681 | 37.5% | 1.00 | Seq Scan | 0.043 | 320.077 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | brin | 10 | 575.635 | 566.398–581.956 | 594.551 | 2.9% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.072 | 575.700 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | btree | 10 | 0.095 | 0.055–0.294 | 0.585 | 105.6% | 3450.76 | Index Only Scan | 0.065 | 0.145 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | btree_tuned | 10 | 0.191 | 0.114–0.274 | 0.283 | 38.4% | 1711.80 | Index Only Scan | 0.040 | 0.243 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | gin | 10 | 2.792 | 2.466–3.363 | 4.037 | 22.3% | 116.80 | Bitmap Heap Scan, Bitmap Index Scan | 0.071 | 2.867 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | gist | 10 | 0.106 | 0.081–0.117 | 0.574 | 106.8% | 3061.94 | Index Only Scan | 0.062 | 0.168 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | hash (partial) | 10 | 2.058 | 0.701–2.701 | 2.753 | 57.5% | 158.41 | Bitmap Heap Scan, Bitmap Index Scan | 0.045 | 2.095 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | roaring | 10 | 0.056 | 0.043–0.077 | 0.473 | 179.1% | 5875.62 | RoaringCount | 0.056 | 0.112 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | roaring_bitmap | 10 | 2.397 | 1.641–2.824 | 3.009 | 43.4% | 136.02 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 2.461 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c20k_123 | seq | 10 | 326.097 | 319.918–426.145 | 661.504 | 38.1% | 1.00 | Seq Scan | 0.042 | 326.139 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | brin | 10 | 695.329 | 683.537–705.055 | 715.512 | 1.9% | 0.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 695.500 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | btree | 10 | 697.029 | 548.785–832.783 | 880.958 | 20.1% | 0.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.035 | 697.068 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | btree_tuned | 10 | 683.986 | 566.437–789.092 | 1036.500 | 27.6% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 684.042 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | gin | 10 | 859.104 | 654.867–893.746 | 907.268 | 14.7% | 0.48 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 859.186 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | gist | 10 | 630.330 | 593.640–760.859 | 870.981 | 16.9% | 0.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.059 | 630.395 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | hash (partial) | 10 | 754.615 | 643.368–936.600 | 953.662 | 19.4% | 0.55 | Seq Scan (fallback) | 0.049 | 754.668 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | roaring | 10 | 526.618 | 505.578–661.065 | 672.822 | 13.5% | 0.78 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 526.658 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | roaring_bitmap | 10 | 638.416 | 567.829–759.779 | 787.268 | 15.3% | 0.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 638.478 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_c2_0 | seq | 10 | 411.821 | 409.287–558.348 | 788.458 | 32.9% | 1.00 | Seq Scan | 0.043 | 411.863 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | brin | 10 | 21.651 | 20.830–22.712 | 23.321 | 5.1% | 16.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 21.725 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | btree | 10 | 1.602 | 1.546–1.852 | 2.359 | 20.4% | 216.69 | Index Only Scan | 0.048 | 1.655 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | btree_tuned | 10 | 2.577 | 2.173–2.825 | 3.281 | 17.7% | 134.66 | Index Only Scan | 0.042 | 2.619 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | gin | 10 | 6.585 | 5.582–7.093 | 7.358 | 17.0% | 52.70 | Bitmap Heap Scan, Bitmap Index Scan | 0.097 | 6.646 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | gist | 10 | 3.540 | 3.431–3.670 | 3.749 | 3.9% | 98.02 | Index Only Scan | 0.041 | 3.590 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | hash (partial) | 10 | 6.710 | 5.279–7.092 | 7.440 | 21.5% | 51.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.057 | 6.755 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | roaring | 10 | 0.019 | 0.018–0.020 | 0.022 | 13.8% | 18264.68 | RoaringCount | 0.039 | 0.059 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | roaring_bitmap | 10 | 4.598 | 3.622–5.271 | 6.262 | 27.5% | 75.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 4.661 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_clustered_17 | seq | 10 | 347.029 | 343.327–426.526 | 652.944 | 34.3% | 1.00 | Seq Scan | 0.043 | 347.072 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | brin | 10 | 614.870 | 607.710–622.836 | 637.513 | 2.2% | 0.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.075 | 614.936 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | btree | 10 | 2.109 | 2.004–2.224 | 4.320 | 37.8% | 173.08 | Index Only Scan | 0.037 | 2.143 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | btree_tuned | 10 | 18.712 | 11.541–20.713 | 21.862 | 33.8% | 19.51 | Index Only Scan | 0.049 | 18.751 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | gin | 10 | 231.429 | 221.636–231.869 | 237.290 | 32.4% | 1.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 231.478 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | gist | 10 | 3.951 | 3.864–4.247 | 4.584 | 7.3% | 92.39 | Index Only Scan | 0.050 | 3.997 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | hash (partial) | 10 | 122.453 | 27.381–226.001 | 230.638 | 82.0% | 2.98 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 122.508 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | roaring | 10 | 1.849 | 0.655–3.050 | 3.598 | 67.1% | 197.42 | RoaringCount | 0.042 | 1.904 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | roaring_bitmap | 10 | 230.548 | 222.050–242.710 | 248.011 | 5.1% | 1.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 230.608 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_nullable_17 | seq | 10 | 365.032 | 357.400–417.335 | 664.287 | 35.1% | 1.00 | Seq Scan | 0.042 | 365.072 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | brin | 10 | 785.665 | 776.769–799.585 | 810.601 | 2.2% | 0.64 | Bitmap Heap Scan, Bitmap Index Scan | 0.076 | 785.837 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | btree | 10 | 311.755 | 301.815–322.460 | 332.208 | 4.2% | 1.61 | Index Only Scan | 0.046 | 311.808 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | btree_tuned | 10 | 523.552 | 502.897–536.964 | 548.662 | 7.3% | 0.96 | Index Only Scan | 0.040 | 523.590 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | gin | 10 | 1025.898 | 955.651–1068.423 | 1135.314 | 7.8% | 0.49 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 1025.961 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | gist | 10 | 832.379 | 824.012–900.619 | 915.810 | 5.0% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.062 | 832.443 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | hash (partial) | 10 | 836.972 | 718.692–1018.855 | 1043.470 | 17.6% | 0.60 | Seq Scan (fallback) | 0.035 | 837.000 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | roaring | 10 | 668.896 | 656.755–791.147 | 815.291 | 10.2% | 0.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.039 | 668.951 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | roaring_bitmap | 10 | 842.390 | 775.311–891.054 | 942.393 | 10.2% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.061 | 842.447 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | eq_skew_0 | seq | 10 | 501.948 | 497.616–675.164 | 905.384 | 29.4% | 1.00 | Seq Scan | 0.042 | 501.990 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | brin | 10 | 569.452 | 565.053–588.390 | 590.823 | 2.3% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.076 | 569.756 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | btree | 10 | 20.602 | 17.364–250.239 | 268.751 | 108.5% | 15.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.058 | 20.648 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | btree_tuned | 10 | 11.323 | 7.841–17.466 | 20.587 | 42.8% | 28.66 | Index Only Scan | 0.045 | 11.382 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | gin | 10 | 196.488 | 21.860–251.085 | 280.152 | 68.9% | 1.65 | Bitmap Heap Scan, Bitmap Index Scan | 0.052 | 196.544 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | gist | 10 | 215.960 | 214.885–218.291 | 219.555 | 32.3% | 1.50 | Bitmap Heap Scan, Bitmap Index Scan | 0.055 | 216.015 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | hash (partial) | 10 | 21.408 | 18.788–23.938 | 58.436 | 75.7% | 15.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.060 | 21.476 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | roaring | 10 | 250.928 | 131.054–256.888 | 261.023 | 47.3% | 1.29 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 251.000 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | roaring_bitmap | 10 | 87.920 | 24.906–256.198 | 287.932 | 90.7% | 3.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 87.970 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | fetch_medium | seq | 10 | 324.566 | 313.190–381.099 | 626.206 | 38.1% | 1.00 | Seq Scan | 0.045 | 324.611 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c2 | brin | 10 | 735.990 | 730.571–745.702 | 758.111 | 1.7% | 0.99 | Seq Scan (fallback) | 0.061 | 736.050 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c2 | btree | 10 | 451.793 | 439.062–457.788 | 463.035 | 2.1% | 1.61 | Index Only Scan | 0.041 | 451.857 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c2 | btree_tuned | 10 | 1215.487 | 1182.223–1441.591 | 1561.585 | 12.5% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 1215.548 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c2 | gin | 10 | 949.831 | 806.357–1030.649 | 1067.688 | 12.4% | 0.76 | Seq Scan (fallback) | 0.059 | 949.869 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c2 | gist | 10 | 1176.987 | 1137.806–1243.245 | 1295.286 | 5.4% | 0.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.036 | 1177.026 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c2 | hash (partial) | 10 | 1184.432 | 920.739–1233.822 | 1268.267 | 13.8% | 0.61 | Seq Scan (fallback) | 0.045 | 1184.510 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c2 | roaring | 10 | 32.737 | 28.530–35.441 | 36.791 | 13.6% | 22.15 | RoaringCount | 0.042 | 32.790 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c2 | roaring_bitmap | 10 | 952.150 | 919.055–1030.577 | 1121.745 | 10.9% | 0.76 | Seq Scan (fallback) | 0.054 | 952.184 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c2 | seq | 10 | 725.200 | 714.427–815.791 | 1017.982 | 16.6% | 1.00 | Seq Scan | 0.044 | 725.245 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c200 | brin | 10 | 833.041 | 829.521–847.360 | 852.235 | 1.2% | 1.00 | Seq Scan (fallback) | 0.060 | 833.101 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c200 | btree | 10 | 533.456 | 516.741–538.111 | 539.492 | 2.1% | 1.56 | Index Only Scan | 0.051 | 533.495 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c200 | btree_tuned | 10 | 1895.381 | 1878.769–1914.327 | 1933.162 | 1.3% | 0.44 | Index Only Scan | 0.051 | 1895.430 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c200 | gin | 10 | 1094.126 | 987.549–1142.091 | 1198.811 | 8.6% | 0.76 | Seq Scan (fallback) | 0.059 | 1094.186 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c200 | gist | 10 | 1403.517 | 1347.253–1440.524 | 1480.807 | 4.3% | 0.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 1403.553 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c200 | hash (partial) | 10 | 1331.175 | 1084.478–1378.724 | 1410.091 | 12.1% | 0.63 | Seq Scan (fallback) | 0.036 | 1331.206 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c200 | roaring | 10 | 132.675 | 126.582–141.914 | 147.238 | 7.0% | 6.28 | RoaringCount | 0.036 | 132.724 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c200 | roaring_bitmap | 10 | 1037.812 | 978.543–1137.208 | 1247.078 | 10.3% | 0.80 | Seq Scan (fallback) | 0.058 | 1037.892 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_c200 | seq | 10 | 833.481 | 821.659–923.583 | 1153.929 | 16.3% | 1.00 | Seq Scan | 0.043 | 833.525 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_filtered | brin | 10 | 575.915 | 559.119–594.509 | 604.733 | 3.8% | 0.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 576.000 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_filtered | btree | 10 | 21.040 | 17.627–230.590 | 246.618 | 124.7% | 15.56 | Bitmap Heap Scan, Bitmap Index Scan | 0.066 | 21.119 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_filtered | btree_tuned | 10 | 11.238 | 8.777–17.814 | 19.558 | 37.8% | 29.13 | Index Only Scan | 0.058 | 11.329 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_filtered | gin | 10 | 205.267 | 22.220–242.797 | 266.753 | 63.8% | 1.59 | Bitmap Heap Scan, Bitmap Index Scan | 0.076 | 205.343 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_filtered | gist | 10 | 208.324 | 20.710–218.686 | 221.557 | 63.6% | 1.57 | Bitmap Heap Scan, Bitmap Index Scan | 0.047 | 208.371 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_filtered | hash (partial) | 10 | 20.663 | 17.976–22.682 | 23.237 | 11.3% | 15.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 20.726 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_filtered | roaring | 10 | 17.376 | 16.720–18.224 | 19.347 | 6.5% | 18.84 | RoaringCount | 0.079 | 17.455 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_filtered | roaring_bitmap | 10 | 187.196 | 22.913–248.450 | 260.016 | 77.3% | 1.75 | Bitmap Heap Scan, Bitmap Index Scan | 0.046 | 187.256 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | group_filtered | seq | 10 | 327.350 | 315.320–511.880 | 715.284 | 40.2% | 1.00 | Seq Scan | 0.051 | 327.400 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_and | brin | 10 | 700.358 | 687.665–714.196 | 718.231 | 2.1% | 0.62 | Bitmap Heap Scan, Bitmap Index Scan | 0.089 | 700.540 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_and | btree | 10 | 132.940 | 100.783–155.021 | 173.694 | 31.9% | 3.27 | Bitmap Heap Scan, Bitmap Index Scan | 0.073 | 132.990 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_and | btree_tuned | 10 | 3.715 | 3.518–9.475 | 11.304 | 58.1% | 117.04 | Index Only Scan | 0.056 | 3.771 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_and | gin | 10 | 175.748 | 162.247–194.842 | 200.552 | 19.2% | 2.47 | Bitmap Heap Scan, Bitmap Index Scan | 0.090 | 175.822 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_and | gist | 10 | 159.853 | 105.057–176.247 | 180.021 | 32.8% | 2.72 | Bitmap Heap Scan, Bitmap Index Scan | 0.072 | 159.929 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_and | hash (partial) | 10 | 533.605 | 68.520–589.824 | 613.703 | 65.6% | 0.81 | Bitmap Heap Scan, Bitmap Index Scan | 0.068 | 533.659 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_and | roaring | 10 | 11.091 | 10.484–12.887 | 13.708 | 12.3% | 39.20 | RoaringCount | 0.077 | 11.160 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_and | roaring_bitmap | 10 | 148.765 | 130.401–155.736 | 164.876 | 24.6% | 2.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 148.830 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_and | seq | 10 | 434.760 | 427.836–495.661 | 728.485 | 28.3% | 1.00 | Seq Scan | 0.052 | 434.812 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | brin | 10 | 401.960 | 395.174–408.882 | 410.229 | 2.0% | 1.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.108 | 402.166 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | btree | 10 | 0.563 | 0.420–0.870 | 1.140 | 48.3% | 763.72 | Index Only Scan | 0.045 | 0.622 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | btree_tuned | 10 | 2.079 | 1.563–2.489 | 2.707 | 31.0% | 207.00 | Index Only Scan | 0.048 | 2.126 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | gin | 10 | 30.062 | 17.440–31.729 | 32.745 | 39.8% | 14.32 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 30.137 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | gist | 10 | 25.905 | 23.743–27.426 | 27.993 | 33.1% | 16.61 | Bitmap Heap Scan, Bitmap Index Scan | 0.070 | 25.975 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | hash (partial) | 10 | 23.855 | 7.494–27.126 | 29.712 | 60.3% | 18.04 | Bitmap Heap Scan, Bitmap Index Scan | 0.054 | 23.907 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | roaring | 10 | 0.615 | 0.493–0.754 | 0.975 | 31.1% | 700.34 | RoaringCount | 0.062 | 0.693 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | roaring_bitmap | 10 | 28.323 | 14.881–30.754 | 36.517 | 50.6% | 15.19 | Bitmap Heap Scan, Bitmap Index Scan | 0.067 | 28.393 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_10 | seq | 10 | 430.356 | 416.925–555.072 | 741.302 | 26.8% | 1.00 | Seq Scan | 0.050 | 430.405 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | brin | 10 | 3977.021 | 3942.253–3995.276 | 4008.948 | 0.7% | 0.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.500 | 3977.710 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | btree | 10 | 413.674 | 392.324–573.152 | 663.726 | 23.9% | 1.13 | Bitmap Heap Scan, Bitmap Index Scan | 0.464 | 414.112 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | btree_tuned | 10 | 514.529 | 402.764–586.045 | 727.613 | 25.9% | 0.91 | Bitmap Heap Scan, Bitmap Index Scan | 0.633 | 515.166 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | gin | 10 | 961.662 | 924.919–1024.597 | 1104.901 | 7.9% | 0.49 | Bitmap Heap Scan, Bitmap Index Scan | 0.625 | 962.270 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | gist | 10 | 399.654 | 393.016–466.617 | 527.902 | 13.2% | 1.17 | Bitmap Heap Scan, Bitmap Index Scan | 0.469 | 400.159 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | hash (partial) | 10 | 559.321 | 520.128–639.305 | 738.435 | 15.7% | 0.83 | Bitmap Heap Scan, Bitmap Index Scan | 0.445 | 559.888 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | roaring | 10 | 400.858 | 388.474–436.584 | 464.756 | 7.5% | 1.16 | Bitmap Heap Scan, Bitmap Index Scan | 0.800 | 401.633 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | roaring_bitmap | 10 | 468.003 | 413.578–541.532 | 622.516 | 18.4% | 1.00 | Bitmap Heap Scan, Bitmap Index Scan | 0.465 | 468.463 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | in_c20k_1000 | seq | 10 | 466.538 | 462.245–520.703 | 725.422 | 23.7% | 1.00 | Seq Scan | 0.431 | 466.963 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | is_null | brin | 10 | 621.601 | 614.465–630.225 | 639.531 | 2.6% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.091 | 621.793 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | is_null | btree | 10 | 396.684 | 353.401–471.365 | 523.252 | 17.3% | 0.95 | Bitmap Heap Scan, Bitmap Index Scan | 0.056 | 396.740 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | is_null | btree_tuned | 10 | 496.937 | 377.634–588.773 | 979.860 | 48.7% | 0.76 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 496.977 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | is_null | gin | 10 | 624.413 | 581.818–678.280 | 736.416 | 12.8% | 0.60 | Seq Scan (fallback) | 0.052 | 624.454 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | is_null | gist | 10 | 541.751 | 457.216–561.427 | 595.935 | 11.8% | 0.69 | Bitmap Heap Scan, Bitmap Index Scan | 0.034 | 541.794 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | is_null | hash (partial) | 10 | 801.659 | 606.017–868.941 | 911.385 | 18.7% | 0.47 | Seq Scan (fallback) | 0.046 | 801.694 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | is_null | roaring | 10 | 345.070 | 334.727–353.462 | 436.164 | 14.0% | 1.09 | Bitmap Heap Scan, Bitmap Index Scan | 0.049 | 345.113 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | is_null | roaring_bitmap | 10 | 527.860 | 463.506–607.440 | 672.575 | 20.1% | 0.71 | Bitmap Heap Scan, Bitmap Index Scan | 0.053 | 527.900 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | is_null | seq | 10 | 375.351 | 373.326–441.271 | 677.958 | 32.5% | 1.00 | Seq Scan | 0.036 | 375.386 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | range_random | brin | 10 | 607.155 | 593.729–629.077 | 632.631 | 3.2% | 0.58 | Bitmap Heap Scan, Bitmap Index Scan | 0.078 | 607.229 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | range_random | btree | 10 | 3.534 | 2.601–4.609 | 4.999 | 31.3% | 100.28 | Index Only Scan | 0.102 | 3.628 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | range_random | btree_tuned | 10 | 21.580 | 15.917–23.177 | 26.434 | 30.3% | 16.43 | Index Only Scan | 0.095 | 21.777 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | range_random | gin | 10 | 446.481 | 316.106–457.367 | 476.694 | 27.9% | 0.79 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 446.611 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | range_random | gist | 10 | 4.864 | 4.778–5.085 | 5.414 | 6.6% | 72.87 | Index Only Scan | 0.054 | 4.910 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | range_random | hash (partial) | 10 | 803.807 | 623.215–852.947 | 883.085 | 16.4% | 0.44 | Seq Scan (fallback) | 0.057 | 803.855 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | range_random | roaring | 10 | 446.713 | 377.649–533.672 | 556.630 | 17.4% | 0.79 | Seq Scan (fallback) | 0.046 | 446.768 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | range_random | roaring_bitmap | 10 | 498.820 | 390.266–615.817 | 702.842 | 26.2% | 0.71 | Seq Scan (fallback) | 0.062 | 498.871 |
| scalar | 5000000 | dirty_scattered | prefer_index | 64MB | range_random | seq | 10 | 354.452 | 346.919–537.466 | 748.784 | 38.9% | 1.00 | Seq Scan | 0.047 | 354.501 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | brin | 10 | 671.910 | 667.558–683.810 | 696.486 | 1.8% | 0.60 | Bitmap Heap Scan, Bitmap Index Scan | 0.074 | 671.986 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | btree | 10 | 153.434 | 151.792–157.373 | 172.569 | 6.0% | 2.62 | Index Only Scan | 0.041 | 153.483 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | btree_tuned | 10 | 155.929 | 153.888–159.650 | 168.465 | 4.3% | 2.58 | Index Only Scan | 0.040 | 155.968 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | gin | 10 | 924.778 | 811.439–1080.301 | 1087.861 | 13.1% | 0.44 | Bitmap Heap Scan, Bitmap Index Scan | 0.077 | 925.346 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | gist | 10 | 348.200 | 343.221–353.273 | 365.750 | 3.0% | 1.16 | Index Only Scan | 0.064 | 348.264 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | hash (partial) | 10 | 597.259 | 547.225–633.512 | 651.799 | 8.6% | 0.67 | Seq Scan (fallback) | 0.053 | 597.308 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | roaring | 10 | 2.022 | 2.010–2.046 | 2.118 | 2.7% | 199.06 | RoaringCount | 0.042 | 2.073 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | roaring_bitmap | 10 | 770.019 | 710.751–836.585 | 883.503 | 9.7% | 0.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.064 | 770.083 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | eq_c2_0 | seq | 10 | 402.492 | 396.353–407.641 | 420.248 | 2.5% | 1.00 | Seq Scan | 0.042 | 402.535 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | fetch_medium | brin | 10 | 556.366 | 551.843–567.018 | 572.462 | 1.6% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.085 | 556.583 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | fetch_medium | btree | 10 | 12.755 | 11.665–13.076 | 13.510 | 13.4% | 24.15 | Index Scan | 0.045 | 12.819 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | fetch_medium | btree_tuned | 10 | 2.798 | 2.747–2.853 | 2.955 | 3.1% | 110.09 | Index Only Scan | 0.065 | 2.861 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | fetch_medium | gin | 10 | 273.923 | 89.683–283.195 | 288.954 | 48.9% | 1.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.085 | 274.016 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | fetch_medium | gist | 10 | 13.183 | 13.009–13.578 | 15.227 | 7.6% | 23.37 | Index Scan | 0.070 | 13.257 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | fetch_medium | hash (partial) | 10 | 35.181 | 19.104–39.353 | 43.439 | 37.7% | 8.76 | Index Scan | 0.062 | 35.248 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | fetch_medium | roaring | 10 | 86.650 | 84.054–90.335 | 93.046 | 4.0% | 3.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.042 | 86.694 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | fetch_medium | roaring_bitmap | 10 | 300.053 | 290.055–316.547 | 333.156 | 5.6% | 1.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.069 | 300.120 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | fetch_medium | seq | 10 | 308.029 | 299.758–311.953 | 314.030 | 2.0% | 1.00 | Seq Scan | 0.045 | 308.076 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | group_c200 | brin | 10 | 857.294 | 850.551–872.698 | 877.156 | 1.4% | 0.96 | Seq Scan (fallback) | 0.061 | 857.361 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | group_c200 | btree | 10 | 409.976 | 403.125–413.156 | 419.155 | 1.8% | 2.01 | Index Only Scan | 0.042 | 410.034 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | group_c200 | btree_tuned | 10 | 410.913 | 405.770–429.008 | 435.227 | 3.1% | 2.01 | Index Only Scan | 0.046 | 410.961 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | group_c200 | gin | 10 | 948.096 | 934.441–1043.801 | 1086.799 | 8.6% | 0.87 | Seq Scan (fallback) | 0.060 | 948.155 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | group_c200 | gist | 10 | 944.582 | 933.491–957.597 | 975.552 | 1.9% | 0.87 | Index Only Scan | 0.056 | 944.621 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | group_c200 | hash (partial) | 10 | 1032.351 | 979.756–1049.704 | 1059.701 | 4.2% | 0.80 | Seq Scan (fallback) | 0.054 | 1032.394 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | group_c200 | roaring | 10 | 18.239 | 18.061–19.100 | 20.445 | 5.1% | 45.18 | RoaringCount | 0.040 | 18.281 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | group_c200 | roaring_bitmap | 10 | 1005.402 | 893.574–1030.175 | 1042.629 | 7.5% | 0.82 | Seq Scan (fallback) | 0.059 | 1005.464 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | group_c200 | seq | 10 | 824.062 | 809.756–843.264 | 862.149 | 2.6% | 1.00 | Seq Scan | 0.044 | 824.106 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | brin | 10 | 3726.525 | 3707.249–3767.427 | 3809.555 | 1.2% | 0.12 | Bitmap Heap Scan, Bitmap Index Scan | 0.500 | 3727.147 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | btree | 10 | 15.405 | 15.151–16.550 | 18.322 | 8.0% | 28.86 | Index Only Scan | 0.472 | 15.875 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | btree_tuned | 10 | 15.808 | 15.457–16.060 | 17.932 | 7.3% | 28.12 | Index Only Scan | 0.447 | 16.256 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | gin | 10 | 813.300 | 794.596–850.598 | 906.127 | 6.3% | 0.55 | Bitmap Heap Scan, Bitmap Index Scan | 0.655 | 813.959 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | gist | 10 | 574.605 | 565.318–578.355 | 581.522 | 1.4% | 0.77 | Index Only Scan | 0.466 | 575.053 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | hash (partial) | 10 | 862.145 | 820.443–891.346 | 904.973 | 4.4% | 0.52 | Bitmap Heap Scan, Bitmap Index Scan | 0.448 | 862.607 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | roaring | 10 | 69.596 | 67.839–72.416 | 74.007 | 4.0% | 6.39 | RoaringCount | 0.804 | 70.359 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | roaring_bitmap | 10 | 883.438 | 823.278–906.495 | 924.797 | 5.8% | 0.50 | Bitmap Heap Scan, Bitmap Index Scan | 0.480 | 883.929 |
| scalar | 5000000 | low_work_mem | prefer_index | 64kB | in_c20k_1000 | seq | 10 | 444.582 | 439.827–459.867 | 463.215 | 2.4% | 1.00 | Seq Scan | 0.459 | 445.032 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | brin | 3 | 409.153 | 400.814–423.717 | 422.261 | 2.8% | 1.01 | Seq Scan (fallback) | 0.692 | 410.144 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | btree | 3 | 1.721 | 1.714–1.733 | 1.732 | 0.6% | 239.63 | Index Only Scan | 0.632 | 2.365 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | btree_tuned | 3 | 1.814 | 1.790–1.876 | 1.870 | 2.4% | 227.34 | Index Only Scan | 0.695 | 2.493 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | gin | 3 | 102.376 | 100.020–104.172 | 103.992 | 2.0% | 4.03 | Bitmap Heap Scan, Bitmap Index Scan | 0.702 | 103.101 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | gist | 3 | 4.042 | 3.973–4.103 | 4.097 | 1.6% | 102.03 | Index Only Scan | 0.585 | 4.617 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | hash (partial) | 3 | 105.187 | 104.040–108.033 | 107.748 | 1.9% | 3.92 | Bitmap Heap Scan, Bitmap Index Scan | 0.554 | 106.076 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | roaring | 3 | 0.240 | 0.239–0.245 | 0.244 | 1.3% | 1718.33 | RoaringCount | 0.595 | 0.834 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | roaring_bitmap | 3 | 110.269 | 105.142–114.480 | 114.059 | 4.3% | 3.74 | Bitmap Heap Scan, Bitmap Index Scan | 0.513 | 110.793 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | eq_c200_17 | seq | 3 | 412.400 | 409.639–414.282 | 414.094 | 0.6% | 1.00 | Seq Scan | 0.352 | 412.752 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | fetch_medium | brin | 3 | 421.202 | 420.777–439.408 | 437.587 | 2.5% | 0.99 | Seq Scan (fallback) | 0.804 | 422.039 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | fetch_medium | btree | 3 | 102.778 | 101.005–103.555 | 103.477 | 1.3% | 4.07 | Bitmap Heap Scan, Bitmap Index Scan | 0.772 | 103.492 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | fetch_medium | btree_tuned | 3 | 5.894 | 5.371–5.999 | 5.988 | 5.8% | 70.91 | Index Only Scan | 0.891 | 6.844 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | fetch_medium | gin | 3 | 100.832 | 98.928–103.513 | 103.245 | 2.3% | 4.15 | Bitmap Heap Scan, Bitmap Index Scan | 0.896 | 101.753 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | fetch_medium | gist | 3 | 100.022 | 99.318–100.783 | 100.707 | 0.7% | 4.18 | Bitmap Heap Scan, Bitmap Index Scan | 0.716 | 100.769 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | fetch_medium | hash (partial) | 3 | 103.582 | 103.224–104.986 | 104.846 | 0.9% | 4.04 | Bitmap Heap Scan, Bitmap Index Scan | 0.628 | 104.421 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | fetch_medium | roaring | 3 | 108.949 | 105.867–110.572 | 110.410 | 2.2% | 3.84 | Bitmap Heap Scan, Bitmap Index Scan | 0.801 | 109.802 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | fetch_medium | roaring_bitmap | 3 | 105.310 | 105.086–106.698 | 106.559 | 0.8% | 3.97 | Bitmap Heap Scan, Bitmap Index Scan | 0.736 | 106.046 |
| scalar | 5000000 | shared_buffers_cold | default | 64MB | fetch_medium | seq | 3 | 417.968 | 413.545–428.335 | 427.298 | 1.8% | 1.00 | Seq Scan | 0.513 | 418.503 |

## Errors

```json
[
  {
    "kind": "build",
    "status": "error",
    "error": "ERROR:  canceling statement due to statement timeout\n",
    "elapsed_ms": 60009.31949703954,
    "wal_bytes": 65883088,
    "suite": "scalar",
    "family": "hash",
    "rows": 1000000,
    "repeat": 0,
    "index": "ix_c2"
  },
  {
    "kind": "build",
    "status": "error",
    "error": "ERROR:  canceling statement due to statement timeout\n",
    "elapsed_ms": 59371.84368999442,
    "wal_bytes": 51799024,
    "suite": "scalar",
    "family": "hash",
    "rows": 1000000,
    "repeat": 0,
    "index": "ix_skew"
  },
  {
    "kind": "build",
    "status": "error",
    "error": "ERROR:  canceling statement due to statement timeout\n",
    "elapsed_ms": 57988.63874102244,
    "wal_bytes": 58188656,
    "suite": "scalar",
    "family": "hash",
    "rows": 5000000,
    "repeat": 0,
    "index": "ix_c2"
  },
  {
    "kind": "build",
    "status": "error",
    "error": "ERROR:  canceling statement due to statement timeout\n",
    "elapsed_ms": 59987.54895100137,
    "wal_bytes": 144207648,
    "suite": "scalar",
    "family": "hash",
    "rows": 5000000,
    "repeat": 0,
    "index": "ix_c20"
  },
  {
    "kind": "build",
    "status": "error",
    "error": "ERROR:  canceling statement due to statement timeout\n",
    "elapsed_ms": 60024.864400038496,
    "wal_bytes": 46522496,
    "suite": "scalar",
    "family": "hash",
    "rows": 5000000,
    "repeat": 0,
    "index": "ix_skew"
  },
  {
    "kind": "reindex",
    "status": "error",
    "error": "ERROR:  canceling statement due to statement timeout\n",
    "elapsed_ms": 58909.48826901149,
    "wal_bytes": 816064984,
    "suite": "scalar",
    "rows": 5000000,
    "family": "hash"
  }
]
```

## Explicitly unmeasured configurations

```json
[
  {
    "kind": "skipped_configuration",
    "suite": "scalar",
    "rows": 5000000,
    "variant": "hash",
    "phase": "after_maintenance",
    "mode": "default",
    "memory": "64MB",
    "case": "eq_c200_17",
    "reason": "Prior reindex failed; read matrix retained on resume"
  },
  {
    "kind": "skipped_configuration",
    "suite": "scalar",
    "rows": 5000000,
    "variant": "hash",
    "phase": "after_maintenance",
    "mode": "default",
    "memory": "64MB",
    "case": "and2",
    "reason": "Prior reindex failed; read matrix retained on resume"
  },
  {
    "kind": "skipped_configuration",
    "suite": "scalar",
    "rows": 5000000,
    "variant": "hash",
    "phase": "after_maintenance",
    "mode": "default",
    "memory": "64MB",
    "case": "is_null",
    "reason": "Prior reindex failed; read matrix retained on resume"
  },
  {
    "kind": "skipped_configuration",
    "suite": "scalar",
    "rows": 5000000,
    "variant": "hash",
    "phase": "after_maintenance",
    "mode": "default",
    "memory": "64MB",
    "case": "group_c200",
    "reason": "Prior reindex failed; read matrix retained on resume"
  }
]
```
